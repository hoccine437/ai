"""Phone Settings Controller — comprehensive Android settings control.

Works on ANY Android device via shell commands (am, settings, cmd, dumpsys).
No Termux:API required. Every method is timeout-bounded and never raises.
"""

from __future__ import annotations

import os
import re
import subprocess


def _is_android() -> bool:
    return bool(os.environ.get("ANDROID_ROOT") or os.environ.get("ANDROID_DATA")
                or "com.termux" in os.environ.get("PREFIX", ""))


def _shell(cmd: str, timeout: int = 8) -> tuple[bool, str]:
    try:
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)
        return r.returncode == 0, (r.stdout + r.stderr).strip()[:3000]
    except subprocess.TimeoutExpired:
        return False, "timed out"
    except Exception as e:
        return False, str(e)[:200]


def _settings_get(namespace: str, key: str) -> str | None:
    ok, out = _shell(f"settings get {namespace} {key}")
    if ok and out and out != "null":
        return out.strip()
    return None


def _settings_put(namespace: str, key: str, value: str) -> tuple[bool, str]:
    return _shell(f"settings put {namespace} {key} {value}")


def _dumpsys_section(service: str, grep: str = "") -> str:
    cmd = f"dumpsys {service}"
    if grep:
        cmd += f" | grep -i '{grep}'"
    ok, out = _shell(cmd, timeout=5)
    return out if ok else ""


# ===========================================================================
# WiFi
# ===========================================================================

def wifi_enabled() -> bool | None:
    val = _settings_get("global", "wifi_on")
    return bool(int(val)) if val is not None else None


def wifi_set_enabled(enabled: bool) -> tuple[bool, str]:
    """Enable or disable WiFi."""
    val = "1" if enabled else "0"
    ok, _ = _settings_put("global", "wifi_on", val)
    # Also toggle via svc as a fallback
    _shell(f"svc wifi {'enable' if enabled else 'disable'}", timeout=5)
    state = "enabled" if enabled else "disabled"
    return True, f"WiFi {state}"


def wifi_connected() -> dict | None:
    """Get current WiFi connection info."""
    out = _dumpsys_section("wifi", "mWifiInfo")
    if not out:
        return None
    info = {}
    m = re.search(r"SSID:\s*\"([^\"]+)\"", out)
    if m:
        info["ssid"] = m.group(1)
    m = re.search(r"Link speed:\s*(\d+)", out)
    if m:
        info["link_speed"] = int(m.group(1))
    m = re.search(r"RSSI:\s*(-?\d+)", out)
    if m:
        info["signal_dbm"] = int(m.group(1))
    m = re.search(r"Frequency:\s*(\d+)", out)
    if m:
        info["frequency_mhz"] = int(m.group(1))
    return info or None


def wifi_scan() -> list[dict]:
    """Trigger a WiFi scan and return results."""
    _shell("cmd wifi start-scan", timeout=5)
    import time
    time.sleep(2)
    out = _dumpsys_section("wifi", "SSID:")
    results = []
    for m in re.finditer(r"SSID:\s*\"([^\"]+)\".*?BSSID:\s*(\S+).*?level:\s*(-?\d+)", out, re.S):
        results.append({"ssid": m.group(1), "bssid": m.group(2), "signal_dbm": int(m.group(3))})
    return results[:20]


# ===========================================================================
# Bluetooth
# ===========================================================================

def bluetooth_enabled() -> bool | None:
    val = _settings_get("global", "bluetooth_on")
    return bool(int(val)) if val is not None else None


def bluetooth_set_enabled(enabled: bool) -> tuple[bool, str]:
    """Enable or disable Bluetooth."""
    val = "1" if enabled else "0"
    _settings_put("global", "bluetooth_on", val)
    _shell(f"svc bluetooth {'enable' if enabled else 'disable'}", timeout=5)
    state = "enabled" if enabled else "disabled"
    return True, f"Bluetooth {state}"


def bluetooth_paired_devices() -> list[dict]:
    """List paired Bluetooth devices."""
    out = _dumpsys_section("bluetooth_manager", "name:")
    devices = []
    for m in re.finditer(r"name:\s*(.+?)(?:\n|$)", out):
        name = m.group(1).strip()
        if name:
            devices.append({"name": name})
    return devices[:20]


# ===========================================================================
# Sound / Audio
# ===========================================================================

def sound_get_volume(stream: str = "music") -> int | None:
    """Get volume for a stream: music, ring, alarm, notification, system, voice_call."""
    val = _settings_get("system", f"volume_{stream}_index")
    return int(val) if val is not None else None


def sound_set_volume(stream: str, level: int) -> tuple[bool, str]:
    """Set volume for a stream (0-15 typically)."""
    ok, _ = _settings_put("system", f"volume_{stream}_index", str(max(0, min(15, level))))
    return True, f"Volume '{stream}' set to {level}"


def sound_get_max_volume(stream: str = "music") -> int:
    """Get max volume for a stream."""
    out = _dumpsys_section("audio", f"Max:{stream}")
    m = re.search(r"Max:\s*(\d+)", out)
    return int(m.group(1)) if m else 15


def sound_mute(stream: str = "music") -> tuple[bool, str]:
    """Mute a stream."""
    _settings_put("system", f"volume_{stream}_index", "0")
    return True, f"Muted '{stream}'"


def sound_set_ringer_mode(mode: str) -> tuple[bool, str]:
    """Set ringer mode: silent, vibrate, normal."""
    mode_map = {"silent": "0", "vibrate": "1", "normal": "2"}
    val = mode_map.get(mode.lower(), "2")
    _settings_put("global", "mode_ringer", val)
    return True, f"Ringer mode set to {mode}"


def sound_get_ringer_mode() -> str | None:
    val = _settings_get("global", "mode_ringer")
    if val is None:
        return None
    return {"0": "silent", "1": "vibrate", "2": "normal"}.get(val, val)


def sound_set_notification_sound(uri: str) -> tuple[bool, str]:
    """Set notification sound URI."""
    _settings_put("system", "notification_sound", uri)
    return True, "Notification sound updated"


# ===========================================================================
# Display
# ===========================================================================

def display_get_brightness() -> int | None:
    val = _settings_get("system", "screen_brightness")
    return int(val) if val is not None else None


def display_set_brightness(level: int) -> tuple[bool, str]:
    """Set brightness (0-255)."""
    _settings_put("system", "screen_brightness_mode", "0")  # manual
    _settings_put("system", "screen_brightness", str(max(0, min(255, level))))
    return True, f"Brightness set to {level}"


def display_auto_brightness(enabled: bool) -> tuple[bool, str]:
    """Enable/disable auto-brightness."""
    val = "1" if enabled else "0"
    _settings_put("system", "screen_brightness_mode", val)
    state = "enabled" if enabled else "disabled"
    return True, f"Auto-brightness {state}"


def display_get_timeout() -> int | None:
    """Get screen timeout in milliseconds."""
    val = _settings_get("system", "screen_off_timeout")
    return int(val) if val is not None else None


def display_set_timeout(ms: int) -> tuple[bool, str]:
    """Set screen timeout in milliseconds (e.g. 15000=15s, 30000=30s, 60000=1min)."""
    _settings_put("system", "screen_off_timeout", str(ms))
    seconds = ms // 1000
    if seconds < 60:
        return True, f"Screen timeout set to {seconds}s"
    return True, f"Screen timeout set to {seconds // 60}min"


def display_dark_mode(enabled: bool) -> tuple[bool, str]:
    """Enable/disable dark mode."""
    val = "yes" if enabled else "no"
    _settings_put("ui_night_mode", "night_mode", val)
    # Also try the newer API
    _shell(f"cmd uimode night {'on' if enabled else 'off'}", timeout=5)
    state = "enabled" if enabled else "disabled"
    return True, f"Dark mode {state}"


def display_get_dark_mode() -> bool | None:
    val = _settings_get("ui_night_mode", "night_mode")
    if val is not None:
        return val == "yes"
    # Fallback: check via cmd
    ok, out = _shell("cmd uimode night")
    if ok:
        return "yes" in out.lower() or "night" in out.lower()
    return None


def display_set_font_scale(scale: float) -> tuple[bool, str]:
    """Set font scale (0.85=small, 1.0=normal, 1.15=large, 1.3=largest)."""
    _settings_put("system", "font_scale", str(scale))
    return True, f"Font scale set to {scale}"


def display_get_font_scale() -> float | None:
    val = _settings_get("system", "font_scale")
    return float(val) if val is not None else None


def display_set_density(dpi: int) -> tuple[bool, str]:
    """Set display density DPI (use with caution)."""
    ok, out = _shell(f"wm density {dpi}", timeout=5)
    return ok, f"Density set to {dpi} DPI" if ok else out


def display_reset_density() -> tuple[bool, str]:
    """Reset display density to default."""
    ok, out = _shell("wm density reset", timeout=5)
    return ok, "Density reset to default" if ok else out


def display_set_orientation(mode: str) -> tuple[bool, str]:
    """Set screen orientation: portrait, landscape, auto."""
    mode_map = {"portrait": "1", "landscape": "0", "auto": "2"}
    val = mode_map.get(mode.lower(), "2")
    _settings_put("system", "accelerometer_rotation", "0" if mode.lower() != "auto" else "1")
    if mode.lower() != "auto":
        _settings_put("system", "user_rotation", val)
    return True, f"Orientation set to {mode}"


def display_get_orientation() -> str | None:
    val = _settings_get("system", "accelerometer_rotation")
    if val == "1":
        return "auto"
    rotation = _settings_get("system", "user_rotation")
    if rotation:
        return {"0": "landscape", "1": "portrait"}.get(rotation, rotation)
    return None


# ===========================================================================
# Battery / Power
# ===========================================================================

def battery_level() -> int | None:
    out = _shell("dumpsys battery")[1]
    m = re.search(r"level:\s*(\d+)", out)
    return int(m.group(1)) if m else None


def battery_info() -> dict:
    """Get full battery status."""
    out = _shell("dumpsys battery")[1]
    info = {}
    for key, pattern in [
        ("level", r"level:\s*(\d+)"),
        ("status", r"status:\s*(\d+)"),
        ("plugged", r"plugged:\s*(\d+)"),
        ("temperature", r"temperature:\s*(\d+)"),
        ("voltage", r"voltage:\s*(\d+)"),
        ("health", r"health:\s*(\d+)"),
    ]:
        m = re.search(pattern, out)
        if m:
            info[key] = int(m.group(1))
    # Human-readable status
    status_map = {1: "unknown", 2: "charging", 3: "discharging", 4: "not_charging", 5: "full"}
    info["status_text"] = status_map.get(info.get("status", 0), "unknown")
    plugged_map = {0: "unplugged", 1: "ac", 2: "usb", 4: "wireless"}
    info["plugged_text"] = plugged_map.get(info.get("plugged", 0), "unknown")
    # Temperature in Celsius
    if "temperature" in info:
        info["temperature_c"] = info["temperature"] / 10.0
    return info


def battery_saver(enabled: bool) -> tuple[bool, str]:
    """Enable/disable battery saver mode."""
    val = "1" if enabled else "0"
    _settings_put("low_power", "low_power", val)
    state = "enabled" if enabled else "disabled"
    return True, f"Battery saver {state}"


def battery_get_saver() -> bool | None:
    val = _settings_get("low_power", "low_power")
    return bool(int(val)) if val is not None else None


# ===========================================================================
# Network / Mobile Data
# ===========================================================================

def mobile_data_enabled() -> bool | None:
    val = _settings_get("mobile", "mobile_data")
    if val is not None:
        return bool(int(val))
    val = _settings_get("global", "mobile_data")
    return bool(int(val)) if val is not None else None


def mobile_data_set_enabled(enabled: bool) -> tuple[bool, str]:
    """Enable/disable mobile data."""
    val = "1" if enabled else "0"
    _settings_put("mobile", "mobile_data", val)
    _settings_put("global", "mobile_data", val)
    state = "enabled" if enabled else "disabled"
    return True, f"Mobile data {state}"


def airplane_mode(enabled: bool) -> tuple[bool, str]:
    """Enable/disable airplane mode."""
    val = "1" if enabled else "0"
    _settings_put("global", "airplane_mode_on", val)
    _shell("am broadcast -a android.intent.action.AIRPLANE_MODE --ez state " + val, timeout=5)
    state = "enabled" if enabled else "disabled"
    return True, f"Airplane mode {state}"


def airplane_mode_enabled() -> bool | None:
    val = _settings_get("global", "airplane_mode_on")
    return bool(int(val)) if val is not None else None


def hotspot_enabled() -> bool | None:
    """Check if WiFi hotspot is active."""
    out = _dumpsys_section("connectivity", "tethering")
    if "Tethering is active" in out or "WIFI_AP" in out:
        return True
    val = _settings_get("global", "soft_ap_enabled")
    return bool(int(val)) if val is not None else None


def hotspot_set_enabled(enabled: bool) -> tuple[bool, str]:
    """Enable/disable WiFi hotspot (requires root or ADB on some devices)."""
    val = "1" if enabled else "0"
    _settings_put("global", "soft_ap_enabled", val)
    state = "enabled" if enabled else "disabled"
    return True, f"Hotspot {state}"


def vpn_enabled() -> bool | None:
    """Check if VPN is active."""
    out = _dumpsys_section("connectivity", "VPN")
    if "ACTIVE" in out.upper() or "vpn" in out.lower():
        return True
    return False


# ===========================================================================
# Location / GPS
# ===========================================================================

def location_enabled() -> bool | None:
    val = _settings_get("secure", "location_mode")
    if val is not None:
        return int(val) != 0
    val = _settings_get("secure", "location_providers_allowed")
    return val is not None and val != "" and val != "-none"


def location_set_enabled(enabled: bool) -> tuple[bool, str]:
    """Enable/disable location services."""
    val = "3" if enabled else "0"  # 3 = high accuracy
    _settings_put("secure", "location_mode", val)
    state = "enabled" if enabled else "disabled"
    return True, f"Location {state}"


# ===========================================================================
# NFC
# ===========================================================================

def nfc_enabled() -> bool | None:
    out = _shell("dumpsys nfc", timeout=5)
    if "mState=ON" in out or "enabled" in out.lower():
        return True
    return False


def nfc_set_enabled(enabled: bool) -> tuple[bool, str]:
    """Enable/disable NFC (may require root)."""
    ok, out = _shell(f"svc nfc {'enable' if enabled else 'disable'}", timeout=5)
    if ok:
        state = "enabled" if enabled else "disabled"
        return True, f"NFC {state}"
    return False, f"NFC toggle not available: {out}"


# ===========================================================================
# Notifications / Do Not Disturb
# ===========================================================================

def dnd_enabled() -> bool | None:
    """Check Do Not Disturb status."""
    val = _settings_get("zen_mode")
    return val is not None and val != "0"


def dnd_set_enabled(enabled: bool) -> tuple[bool, str]:
    """Enable/disable Do Not Disturb."""
    val = "1" if enabled else "0"  # 1=priority only, 0=off
    _settings_put("zen_mode", val)
    state = "enabled" if enabled else "disabled"
    return True, f"Do Not Disturb {state}"


def notification_set_enabled(enabled: bool) -> tuple[bool, str]:
    """Enable/disable all notifications."""
    val = "1" if enabled else "0"
    _settings_put("global", "heads_up_notifications_enabled", val)
    state = "enabled" if enabled else "disabled"
    return True, f"Heads-up notifications {state}"


# ===========================================================================
# Touch / Input
# ===========================================================================

def tap(x: int, y: int) -> tuple[bool, str]:
    """Tap at screen coordinates."""
    return _shell(f"input tap {x} {y}", timeout=5)


def long_press(x: int, y: int, duration_ms: int = 1000) -> tuple[bool, str]:
    return _shell(f"input swipe {x} {y} {x} {y} {duration_ms}", timeout=5)


def swipe(x1: int, y1: int, x2: int, y2: int, duration_ms: int = 300) -> tuple[bool, str]:
    return _shell(f"input swipe {x1} {y1} {x2} {y2} {duration_ms}", timeout=5)


def type_text(text: str) -> tuple[bool, str]:
    safe = text.replace("'", "'\\''")
    return _shell(f"input text '{safe}'", timeout=5)


def press_key(keycode: str) -> tuple[bool, str]:
    keymap = {
        "home": "3", "back": "4", "enter": "66", "power": "26",
        "volume_up": "24", "volume_down": "25", "camera": "27",
        "tab": "61", "delete": "67", "space": "62", "menu": "82",
        "app_switch": "187", "search": "84", "media_play_pause": "85",
        "media_next": "87", "media_previous": "86",
        "page_up": "92", "page_down": "93",
    }
    code = keymap.get(keycode.lower(), keycode)
    return _shell(f"input keyevent {code}", timeout=5)


# ===========================================================================
# Apps
# ===========================================================================

def launch_app(package: str) -> tuple[bool, str]:
    return _shell(f"monkey -p {package} -c android.intent.category.LAUNCHER 1", timeout=8)


def stop_app(package: str) -> tuple[bool, str]:
    return _shell(f"am force-stop {package}", timeout=5)


def list_apps() -> list[str]:
    ok, out = _shell("pm list packages -e", timeout=8)
    if not ok:
        return []
    return [line.replace("package:", "").strip() for line in out.splitlines() if line.startswith("package:")]


def search_apps(query: str) -> list[str]:
    apps = list_apps()
    q = query.lower()
    return [a for a in apps if q in a.lower()]


def get_foreground_app() -> str | None:
    ok, out = _shell("dumpsys activity activities | grep mResumedActivity", timeout=5)
    if not ok:
        return None
    m = re.search(r"(\S+/\S+)", out)
    return m.group(1) if m else None


# ===========================================================================
# Clipboard
# ===========================================================================

def clipboard_get() -> str | None:
    ok, out = _shell("service call clipboard 2")
    m = re.search(r"'(.+?)'", out)
    return m.group(1) if m else None


def clipboard_set(text: str) -> tuple[bool, str]:
    safe = text.replace("'", "'\\''")
    return _shell(f"am broadcast -a clipper.set -e text '{safe}'", timeout=5)


# ===========================================================================
# Screen
# ===========================================================================

def screenshot(path: str = "/sdcard/screenshot.png") -> tuple[bool, str]:
    return _shell(f"screencap -p {path}", timeout=10)


def screen_size() -> tuple[int, int] | None:
    ok, out = _shell("wm size", timeout=5)
    if not ok:
        return None
    m = re.search(r"(\d+)x(\d+)", out)
    return (int(m.group(1)), int(m.group(2))) if m else None


def screen_density() -> int | None:
    ok, out = _shell("wm density", timeout=5)
    if not ok:
        return None
    m = re.search(r"(\d+)", out)
    return int(m.group(1)) if m else None


# ===========================================================================
# Notifications
# ===========================================================================

def post_notification(title: str, content: str, id: int = 1) -> tuple[bool, str]:
    ok, out = _shell(
        f'cmd notification post -S bigtext -t "{title}" "zerion_{id}" "{content}"',
        timeout=5
    )
    if ok:
        return True, "notification posted"
    return False, out


# ===========================================================================
# Shell
# ===========================================================================

def shell(command: str, timeout: int = 15) -> tuple[bool, str]:
    """Run any shell command."""
    return _shell(command, timeout=min(timeout, 30))


# ===========================================================================
# Get all settings (comprehensive status)
# ===========================================================================

def get_all_settings() -> dict:
    """Get a comprehensive snapshot of all phone settings."""
    return {
        "wifi": wifi_enabled(),
        "wifi_connected": wifi_connected(),
        "bluetooth": bluetooth_enabled(),
        "bluetooth_paired": len(bluetooth_paired_devices()),
        "mobile_data": mobile_data_enabled(),
        "airplane_mode": airplane_mode_enabled(),
        "location": location_enabled(),
        "nfc": nfc_enabled(),
        "hotspot": hotspot_enabled(),
        "vpn": vpn_enabled(),
        "dnd": dnd_enabled(),
        "dark_mode": display_get_dark_mode(),
        "brightness": display_get_brightness(),
        "auto_brightness": _settings_get("system", "screen_brightness_mode") == "1",
        "screen_timeout_ms": display_get_timeout(),
        "font_scale": display_get_font_scale(),
        "orientation": display_get_orientation(),
        "ringer_mode": sound_get_ringer_mode(),
        "volume_music": sound_get_volume("music"),
        "volume_ring": sound_get_volume("ring"),
        "volume_alarm": sound_get_volume("alarm"),
        "volume_notification": sound_get_volume("notification"),
        "battery": battery_level(),
        "battery_info": battery_info(),
        "battery_saver": battery_get_saver(),
        "foreground_app": get_foreground_app(),
        "screen_size": screen_size(),
        "screen_density": screen_density(),
    }
