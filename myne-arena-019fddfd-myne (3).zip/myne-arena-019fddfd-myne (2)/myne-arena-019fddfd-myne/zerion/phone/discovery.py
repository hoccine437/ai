"""Capability discovery — combines Termux:API + native Android shell commands.

Discovers what Zerion can actually do on THIS device, regardless of whether
Termux:API is installed. Native Android commands (am, pm, input, dumpsys,
settings, etc.) are available on EVERY Android device.
"""
from __future__ import annotations

from .adapter import TermuxAdapter
from .models import Capability, DeviceState

# Termux:API binary commands (require Termux:API package)
_TERMUX_COMMANDS = {
    'clipboard_read': 'termux-clipboard-get',
    'clipboard_write': 'termux-clipboard-set',
    'open_url': 'termux-open-url',
    'battery_state': 'termux-battery-status',
    'notification': 'termux-notification',
    'media': 'termux-media-player',
    'camera': 'termux-camera-photo',
    'torch': 'termux-torch',
    'wifi': 'termux-wifi-connectioninfo',
    'telephony': 'termux-telephony-call',
    'sms': 'termux-sms-send',
    'share': 'termux-share',
    'volume': 'termux-volume',
}

# Native Android shell commands (available on ANY Android device)
_NATIVE_COMMANDS = {
    'app_launch': 'am',
    'app_manage': 'pm',
    'input_tap': 'input',
    'input_type': 'input',
    'screen_info': 'dumpsys',
    'settings_read': 'settings',
    'screenshot': 'screencap',
    'battery_read': 'dumpsys',
    'wifi_read': 'dumpsys',
    'notification_post': 'cmd',
    'shell_exec': 'sh',
    'ui_dump': 'uiautomator',
    'key_event': 'input',
}


class CapabilityDiscovery:
    def __init__(self, adapter=None):
        self.adapter = adapter or TermuxAdapter()

    def capabilities(self):
        caps = []
        # Termux:API capabilities
        for name, cmd in _TERMUX_COMMANDS.items():
            caps.append(Capability(
                name=f"termux_{name}",
                available=self.adapter.has(cmd),
                permission='Termux:API package',
                description=f'Uses {cmd} (Termux:API)',
            ))
        # Native Android capabilities (useful on ANY Android)
        import shutil
        for name, cmd in _NATIVE_COMMANDS.items():
            available = shutil.which(cmd) is not None
            caps.append(Capability(
                name=f"native_{name}",
                available=available,
                permission='Built-in Android shell',
                description=f'Uses {cmd} (native Android)',
            ))
        return caps

    def has_capability(self, name: str) -> bool:
        """Check if a specific capability is available."""
        for cap in self.capabilities():
            if cap.name == name:
                return cap.available
        return False

    def available_native(self) -> list[str]:
        """List available native Android capabilities."""
        return [c.name for c in self.capabilities()
                if c.available and c.name.startswith("native_")]

    def available_termux(self) -> list[str]:
        """List available Termux:API capabilities."""
        return [c.name for c in self.capabilities()
                if c.available and c.name.startswith("termux_")]

    def state(self):
        available = tuple(c.name for c in self.capabilities() if c.available)
        battery = 'unavailable'
        network = 'unavailable'
        try:
            from .android_native import get_battery_level, get_wifi_info
            bl = get_battery_level()
            if bl is not None:
                battery = f'{bl}%'
            wi = get_wifi_info()
            if wi:
                network = wi.get('ssid', 'connected')
        except Exception:
            pass
        return DeviceState(
            battery=battery[:500],
            network=network[:500],
            capabilities=available,
        )
