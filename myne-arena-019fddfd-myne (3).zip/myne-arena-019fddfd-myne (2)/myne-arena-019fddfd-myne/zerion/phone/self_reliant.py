"""Self-Reliant Execution Engine — Zerion never gives up.

When a command fails, this engine:
  1. Diagnoses WHY it failed (permission, not found, restricted, etc.)
  2. Searches for alternative approaches
  3. Tries each approach in order
  4. Reports what worked

Covers: permission grants, root alternatives, ADB workarounds,
setting bypasses, app permission management.
"""

from __future__ import annotations

import re
import shutil
import subprocess
import time


def _shell(cmd: str, timeout: int = 10) -> tuple[bool, str]:
    try:
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)
        return r.returncode == 0, (r.stdout + r.stderr).strip()[:3000]
    except subprocess.TimeoutExpired:
        return False, "timed out"
    except Exception as e:
        return False, str(e)[:200]


# ---------------------------------------------------------------------------
# Diagnostics — Why did it fail?
# ---------------------------------------------------------------------------

def diagnose_failure(command: str, output: str) -> dict:
    """Analyze why a command failed and suggest fixes."""
    output_lower = output.lower()
    result = {
        "original_command": command,
        "error_output": output[:500],
        "issue": "unknown",
        "fixes": [],
    }

    # Permission denied
    if "permission denied" in output_lower or "eacces" in output_lower:
        result["issue"] = "permission_denied"
        result["fixes"] = [
            "grant_permission",
            "use_appops",
            "use_root",
            "use_adb_shell",
            "modify_setting",
        ]

    # Command not found
    elif "not found" in output_lower or "no such file" in output_lower:
        result["issue"] = "command_not_found"
        # Check what's missing
        parts = command.split()
        if parts:
            missing = parts[0]
            result["fixes"] = [
                f"install_package:{missing}",
                "find_alternative",
                "use_builtin",
            ]

    # Access denied / restricted
    elif "access denied" in output_lower or "restricted" in output_lower:
        result["issue"] = "access_restricted"
        result["fixes"] = [
            "grant_permission",
            "use_root",
            "use_adb_shell",
            "bypass_restriction",
        ]

    # Read-only file system
    elif "read-only" in output_lower or "EROFS" in output_lower:
        result["issue"] = "read_only"
        result["fixes"] = [
            "remount_rw",
            "use_tmpfs",
            "use_root",
        ]

    # Process busy / locked
    elif "busy" in output_lower or "locked" in output_lower or "in use" in output_lower:
        result["issue"] = "resource_busy"
        result["fixes"] = [
            "force_stop_app",
            "wait_and_retry",
            "kill_process",
        ]

    # Network error
    elif "network" in output_lower or "unreachable" in output_lower or "timeout" in output_lower:
        result["issue"] = "network_error"
        result["fixes"] = [
            "check_network",
            "retry",
            "use_offline",
        ]

    # Unknown
    else:
        result["fixes"] = [
            "try_alternative_command",
            "use_root",
            "check_settings",
        ]

    return result


# ---------------------------------------------------------------------------
# Permission Management
# ---------------------------------------------------------------------------

def grant_permission(package: str, permission: str) -> tuple[bool, str]:
    """Grant a permission to an app via multiple methods."""
    # Method 1: pm grant (works on Android 6+)
    ok, out = _shell(f"pm grant {package} {permission}", timeout=5)
    if ok:
        return True, f"Granted {permission} to {package} via pm grant"

    # Method 2: appops set
    ok, out = _shell(f"appops set {package} {permission.split('.')[-1]} allow", timeout=5)
    if ok:
        return True, f"Granted {permission} to {package} via appops"

    # Method 3: settings put
    ok, out = _shell(f"settings put global pm.grant_permissions {package} {permission}", timeout=5)
    if ok:
        return True, f"Granted {permission} to {package} via settings"

    return False, f"Could not grant {permission}: {out}"


def revoke_permission(package: str, permission: str) -> tuple[bool, str]:
    """Revoke a permission from an app."""
    ok, out = _shell(f"pm revoke {package} {permission}", timeout=5)
    if ok:
        return True, f"Revoked {permission} from {package}"
    return False, f"Could not revoke: {out}"


def list_permissions(package: str) -> list[dict]:
    """List all permissions for an app."""
    ok, out = _shell(f"dumpsys package {package} | grep -A 1 'permission'", timeout=8)
    if not ok:
        return []
    permissions = []
    for line in out.splitlines():
        line = line.strip()
        if "granted=true" in line.lower():
            m = re.search(r'(\S+:\S+)', line)
            if m:
                permissions.append({"permission": m.group(1), "granted": True})
        elif "granted=false" in line.lower():
            m = re.search(r'(\S+:\S+)', line)
            if m:
                permissions.append({"permission": m.group(1), "granted": False})
    return permissions


def grant_all_permissions(package: str) -> tuple[bool, str]:
    """Grant all requested permissions to an app."""
    permissions = list_permissions(package)
    granted = 0
    failed = 0
    for p in permissions:
        if not p.get("granted"):
            ok, _ = grant_permission(package, p["permission"])
            if ok:
                granted += 1
            else:
                failed += 1
    return True, f"Granted {granted} permissions, {failed} failed for {package}"


def set_appops(package: str, operation: str, mode: str = "allow") -> tuple[bool, str]:
    """Set an app operation via appops."""
    ok, out = _shell(f"appops set {package} {operation} {mode}", timeout=5)
    if ok:
        return True, f"Set {operation}={mode} for {package}"
    return False, f"appops failed: {out}"


def get_appops(package: str) -> dict:
    """Get all appops for an app."""
    ok, out = _shell(f"appops get {package}", timeout=5)
    if not ok:
        return {}
    ops = {}
    for line in out.splitlines():
        m = re.match(r'(\w+):\s*(\w+)', line.strip())
        if m:
            ops[m.group(1)] = m.group(2)
    return ops


# ---------------------------------------------------------------------------
# Root Access
# ---------------------------------------------------------------------------

def has_root() -> bool:
    """Check if device has root access."""
    ok, _ = _shell("su -c id", timeout=5)
    if ok:
        return True
    ok, _ = _shell("which su", timeout=3)
    return ok


def root_command(command: str) -> tuple[bool, str]:
    """Run a command as root."""
    ok, out = _shell(f"su -c '{command}'", timeout=15)
    if ok:
        return True, out
    # Alternative: try with echo pipe
    ok, out = _shell(f"echo '{command}' | su", timeout=15)
    return ok, out


# ---------------------------------------------------------------------------
# ADB Shell (when running via ADB)
# ---------------------------------------------------------------------------

def has_adb() -> bool:
    """Check if ADB is available."""
    ok, _ = _shell("which adb", timeout=3)
    return ok


def adb_command(command: str) -> tuple[bool, str]:
    """Run a command via ADB."""
    ok, out = _shell(f"adb shell {command}", timeout=15)
    return ok, out


# ---------------------------------------------------------------------------
# Settings Bypass
# ---------------------------------------------------------------------------

def modify_setting(namespace: str, key: str, value: str) -> tuple[bool, str]:
    """Try to modify a system setting with multiple approaches."""
    # Method 1: settings put
    ok, out = _shell(f"settings put {namespace} {key} {value}", timeout=5)
    if ok:
        return True, f"Set {namespace}/{key}={value}"

    # Method 2: via root
    if has_root():
        ok, out = root_command(f"settings put {namespace} {key} {value}")
        if ok:
            return True, f"Set {namespace}/{key}={value} via root"

    # Method 3: via content provider
    ok, out = _shell(f"content call --uri content://settings/{namespace} --method PUT_system --extra name:s:{key} --extra value:s:{value}", timeout=5)
    if ok:
        return True, f"Set {namespace}/{key}={value} via content"

    return False, f"Could not set {namespace}/{key}: {out}"


def read_setting(namespace: str, key: str) -> str | None:
    """Read a system setting."""
    ok, out = _shell(f"settings get {namespace} {key}", timeout=5)
    if ok and out and out != "null":
        return out.strip()
    return None


# ---------------------------------------------------------------------------
# Package Management
# ---------------------------------------------------------------------------

def install_package(package: str) -> tuple[bool, str]:
    """Try to install a package."""
    # Method 1: pkg (Termux)
    ok, out = _shell(f"pkg install -y {package}", timeout=30)
    if ok:
        return True, f"Installed {package} via pkg"

    # Method 2: apt (Termux fallback)
    ok, out = _shell(f"apt install -y {package}", timeout=30)
    if ok:
        return True, f"Installed {package} via apt"

    # Method 3: pip (Python packages)
    ok, out = _shell(f"pip install {package}", timeout=30)
    if ok:
        return True, f"Installed {package} via pip"

    return False, f"Could not install {package}"


def find_alternative_command(command: str) -> str | None:
    """Find an alternative for a missing command."""
    alternatives = {
        "ls": ["dir", "find"],
        "cat": ["less", "more"],
        "grep": ["find", "awk"],
        "curl": ["wget"],
        "wget": ["curl"],
        "top": ["htop", "ps"],
        "df": ["du"],
        "free": ["cat /proc/meminfo"],
        "ifconfig": ["ip addr", "ip a"],
        "ping": ["ping -c 1"],
        "nslookup": ["dig", "host"],
        "tar": ["zip", "unzip"],
        "zip": ["tar", "gzip"],
        "unzip": ["tar", "gunzip"],
        "vim": ["nano", "vi"],
        "nano": ["vi", "vim"],
        "git": ["apt install git"],
        "python": ["python3"],
        "pip": ["pip3"],
    }
    alts = alternatives.get(command, [])
    for alt in alts:
        if shutil.which(alt.split()[0]):
            return alt
    return None


# ---------------------------------------------------------------------------
# Self-Reliant Execution Pipeline
# ---------------------------------------------------------------------------

def execute_with_fallback(command: str, max_retries: int = 3) -> dict:
    """Execute a command with automatic fallback and retry.

    Pipeline:
      1. Try the command directly
      2. If it fails, diagnose why
      3. Try the suggested fixes in order
      4. Return what worked
    """
    result = {
        "command": command,
        "attempts": [],
        "success": False,
        "final_output": "",
        "fix_applied": "",
    }

    # Attempt 1: Try directly
    ok, out = _shell(command, timeout=15)
    result["attempts"].append({"method": "direct", "success": ok, "output": out[:300]})
    if ok:
        result["success"] = True
        result["final_output"] = out
        return result

    # Diagnose
    diagnosis = diagnose_failure(command, out)
    result["issue"] = diagnosis["issue"]

    # Try each fix
    for fix in diagnosis.get("fixes", []):
        fix_ok = False
        fix_out = ""

        if fix == "grant_permission" and ":" in command:
            parts = command.split()
            if len(parts) >= 2:
                pkg = parts[1].split("/")[0] if "/" in parts[1] else parts[1]
                fix_ok, fix_out = grant_all_permissions(pkg)

        elif fix == "use_root" and has_root():
            fix_ok, fix_out = root_command(command)

        elif fix == "use_adb_shell" and has_adb():
            fix_ok, fix_out = adb_command(command)

        elif fix.startswith("install_package:"):
            pkg = fix.split(":", 1)[1]
            fix_ok, fix_out = install_package(pkg)

        elif fix == "find_alternative":
            alt = find_alternative_command(command.split()[0] if command.split() else "")
            if alt:
                alt_cmd = command.replace(command.split()[0], alt, 1) if command.split() else alt
                fix_ok, fix_out = _shell(alt_cmd, timeout=15)

        elif fix == "force_stop_app":
            parts = command.split()
            if len(parts) >= 2:
                _shell(f"am force-stop {parts[1]}", timeout=5)
                time.sleep(1)
                fix_ok, fix_out = _shell(command, timeout=15)

        elif fix == "wait_and_retry":
            time.sleep(2)
            fix_ok, fix_out = _shell(command, timeout=15)

        elif fix == "kill_process":
            parts = command.split()
            if parts:
                _shell(f"pkill -f {parts[0]}", timeout=5)
                time.sleep(1)
                fix_ok, fix_out = _shell(command, timeout=15)

        elif fix == "check_network":
            ok_net, _ = _shell("ping -c 1 8.8.8.8", timeout=5)
            if ok_net:
                fix_ok, fix_out = _shell(command, timeout=15)

        elif fix == "retry":
            time.sleep(1)
            fix_ok, fix_out = _shell(command, timeout=15)

        elif fix == "remount_rw":
            if has_root():
                fix_ok, fix_out = root_command("mount -o remount,rw /")

        elif fix.startswith("use_tmpfs"):
            fix_ok, fix_out = _shell(f"cp {command.split()[-1]} /tmp/ 2>/dev/null && echo ok", timeout=5)

        elif fix == "bypass_restriction":
            # Try with different approach
            fix_ok, fix_out = _shell(command.replace("am start", "monkey -p"), timeout=10)

        elif fix == "modify_setting":
            parts = command.split()
            if len(parts) >= 3:
                fix_ok, fix_out = modify_setting("global", parts[1], parts[2])

        elif fix == "use_builtin":
            # Try built-in alternatives
            fix_ok, fix_out = _shell(command, timeout=15)

        elif fix == "try_alternative_command":
            alts = find_alternative_command(command.split()[0] if command.split() else "")
            if alts:
                fix_ok, fix_out = _shell(command.replace(command.split()[0], alts.split()[0], 1), timeout=15)

        elif fix == "check_settings":
            fix_ok, fix_out = _shell(command, timeout=15)

        result["attempts"].append({
            "method": f"fix:{fix}",
            "success": fix_ok,
            "output": fix_out[:300],
        })

        if fix_ok:
            result["success"] = True
            result["final_output"] = fix_out
            result["fix_applied"] = fix
            return result

    result["final_output"] = out
    return result


# ---------------------------------------------------------------------------
# Convenience — Zerion's "do it anyway" functions
# ---------------------------------------------------------------------------

def do_anyway(action: str, description: str = "") -> dict:
    """High-level: perform an action, trying multiple approaches.

    Examples:
      do_anyway("am start -n com.whatsapp/.Main", "open WhatsApp")
      do_anyway("settings put system screen_brightness 128", "set brightness")
      do_anyway("pm grant com.app android.permission.CAMERA", "grant camera")
    """
    result = execute_with_fallback(action)

    if not result["success"]:
        # Last resort: try to find ANY way
        last_attempts = []

        # Try as root
        if has_root():
            ok, out = root_command(action)
            last_attempts.append({"method": "root_final", "success": ok, "output": out[:300]})
            if ok:
                result["success"] = True
                result["final_output"] = out
                result["fix_applied"] = "root_final"

        # Try via content provider
        if not result["success"] and "settings" in action.lower():
            parts = action.split()
            if len(parts) >= 4:
                ok, out = modify_setting(parts[1], parts[2], parts[3])
                last_attempts.append({"method": "content_final", "success": ok, "output": out[:300]})
                if ok:
                    result["success"] = True
                    result["final_output"] = out
                    result["fix_applied"] = "content_final"

        result["attempts"].extend(last_attempts)

    result["description"] = description
    return result


def get_access(what: str) -> dict:
    """Try to gain access to something (permission, setting, resource).

    Examples:
      get_access("camera permission for com.whatsapp")
      get_access("system settings write access")
      get_access("root shell")
      get_access("network information")
    """
    what_lower = what.lower()
    results = {"request": what, "approaches": [], "success": False}

    # Camera permission
    if "camera" in what_lower and "permission" in what_lower:
        pkg = _extract_package(what) or "com.android.camera"
        ok, out = grant_permission(pkg, "android.permission.CAMERA")
        results["approaches"].append({"method": "pm_grant", "success": ok, "output": out})
        if ok:
            results["success"] = True
            return results
        ok, out = set_appops(pkg, "CAMERA", "allow")
        results["approaches"].append({"method": "appops", "success": ok, "output": out})
        if ok:
            results["success"] = True
            return results

    # Location permission
    elif "location" in what_lower and "permission" in what_lower:
        pkg = _extract_package(what) or "com.android.location"
        for perm in ["android.permission.ACCESS_FINE_LOCATION", "android.permission.ACCESS_COARSE_LOCATION"]:
            ok, out = grant_permission(pkg, perm)
            results["approaches"].append({"method": f"pm_grant:{perm}", "success": ok, "output": out})

    # Storage permission
    elif "storage" in what_lower or "file" in what_lower:
        pkg = _extract_package(what) or "com.android.filemanager"
        for perm in ["android.permission.READ_EXTERNAL_STORAGE", "android.permission.WRITE_EXTERNAL_STORAGE"]:
            ok, out = grant_permission(pkg, perm)
            results["approaches"].append({"method": f"pm_grant:{perm}", "success": ok, "output": out})

    # Notification permission
    elif "notification" in what_lower:
        pkg = _extract_package(what)
        if pkg:
            ok, out = grant_permission(pkg, "android.permission.POST_NOTIFICATIONS")
            results["approaches"].append({"method": "pm_grant", "success": ok, "output": out})

    # Root access
    elif "root" in what_lower:
        if has_root():
            results["approaches"].append({"method": "root_available", "success": True, "output": "Root access confirmed"})
            results["success"] = True
        else:
            results["approaches"].append({"method": "root_check", "success": False, "output": "No root access"})

    # Settings access
    elif "setting" in what_lower:
        ok, out = modify_setting("global", "zerion_test", "1")
        results["approaches"].append({"method": "settings_write", "success": ok, "output": out})
        if ok:
            _shell("settings delete global zerion_test", timeout=3)
            results["success"] = True

    # Network info
    elif "network" in what_lower:
        ok, out = _shell("ip addr show", timeout=5)
        results["approaches"].append({"method": "ip_addr", "success": ok, "output": out[:500]})
        if ok:
            results["success"] = True

    # Generic: try multiple approaches
    else:
        # Try as current user
        ok, out = _shell(f"echo test > /data/local/tmp/zerion_test && rm /data/local/tmp/zerion_test", timeout=5)
        results["approaches"].append({"method": "file_write_test", "success": ok, "output": out})

        # Try via settings
        ok, out = _shell("settings list global | head -5", timeout=5)
        results["approaches"].append({"method": "settings_read", "success": ok, "output": out[:300]})

        # Try via dumpsys
        ok, out = _shell("dumpsys activity | head -5", timeout=5)
        results["approaches"].append({"method": "dumpsys_read", "success": ok, "output": out[:300]})

        results["success"] = any(a["success"] for a in results["approaches"])

    return results


def _extract_package(text: str) -> str | None:
    """Extract a package name from text."""
    m = re.search(r'com\.\w+[\.\w]*', text)
    return m.group(0) if m else None


# ---------------------------------------------------------------------------
# Capability Probe — What CAN Zerion do on this device?
# ---------------------------------------------------------------------------

def probe_capabilities() -> dict:
    """Probe what Zerion can do on this device right now."""
    caps = {
        "shell": _shell("echo ok", timeout=3)[0],
        "input": shutil.which("input") is not None,
        "settings": shutil.which("settings") is not None,
        "dumpsys": shutil.which("dumpsys") is not None,
        "am": shutil.which("am") is not None,
        "pm": shutil.which("pm") is not None,
        "uiautomator": shutil.which("uiautomator") is not None,
        "screencap": shutil.which("screencap") is not None,
        "root": has_root(),
        "adb": has_adb(),
        "termux_api": shutil.which("termux-battery-status") is not None,
        "appops": shutil.which("appops") is not None,
        "content": shutil.which("content") is not None,
        "cmd": shutil.which("cmd") is not None,
        "svc": shutil.which("svc") is not None,
        "monkey": shutil.which("monkey") is not None,
    }
    caps["total_tools"] = sum(1 for v in caps.values() if v is True)
    return caps
