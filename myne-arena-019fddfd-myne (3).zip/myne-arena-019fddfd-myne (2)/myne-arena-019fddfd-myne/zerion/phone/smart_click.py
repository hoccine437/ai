"""Smart Click — intelligent UI element detection and tapping.

Pipeline:
  1. Dump UI hierarchy (uiautomator or accessibility)
  2. Parse all clickable/tappable elements with bounds
  3. Match user intent (text, description, resource-id, or semantic)
  4. Calculate center coordinates and tap
  5. Fallback: screenshot + OCR if uiautomator unavailable

Works on ANY Android device. No Termux:API required.
"""

from __future__ import annotations

import re
import subprocess
from dataclasses import dataclass


def _shell(cmd: str, timeout: int = 10) -> tuple[bool, str]:
    try:
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)
        return r.returncode == 0, (r.stdout + r.stderr).strip()[:5000]
    except subprocess.TimeoutExpired:
        return False, "timed out"
    except Exception as e:
        return False, str(e)[:200]


@dataclass
class UIElement:
    """A detected UI element on screen."""
    text: str = ""
    resource_id: str = ""
    content_desc: str = ""
    class_name: str = ""
    package: str = ""
    clickable: bool = False
    scrollable: bool = False
    enabled: bool = True
    focused: bool = False
    selected: bool = False
    bounds: tuple[int, int, int, int] = (0, 0, 0, 0)  # x1, y1, x2, y2

    @property
    def center(self) -> tuple[int, int]:
        x1, y1, x2, y2 = self.bounds
        return ((x1 + x2) // 2, (y1 + y2) // 2)

    @property
    def width(self) -> int:
        return self.bounds[2] - self.bounds[0]

    @property
    def height(self) -> int:
        return self.bounds[3] - self.bounds[1]

    @property
    def area(self) -> int:
        return self.width * self.height

    @property
    def label(self) -> str:
        """Best human-readable label for this element."""
        return self.text or self.content_desc or self.resource_id or self.class_name.split(".")[-1]

    def to_dict(self) -> dict:
        return {
            "text": self.text, "resource_id": self.resource_id,
            "content_desc": self.content_desc, "class": self.class_name,
            "package": self.package, "clickable": self.clickable,
            "bounds": list(self.bounds), "center": list(self.center),
            "label": self.label,
        }


# ---------------------------------------------------------------------------
# UI Hierarchy Dump & Parse
# ---------------------------------------------------------------------------

def dump_hierarchy() -> str | None:
    """Dump the current UI XML hierarchy. Tries multiple methods."""
    # Method 1: uiautomator dump to file
    ok, out = _shell("uiautomator dump /sdcard/ui_dump.xml", timeout=8)
    if ok:
        ok2, xml = _shell("cat /sdcard/ui_dump.xml", timeout=5)
        if ok2 and xml and "<node" in xml:
            return xml
    # Method 2: uiautomator dump to stdout
    ok, out = _shell("uiautomator dump /dev/tty", timeout=8)
    if ok and out and "<node" in out:
        return out
    # Method 3: accessibility dump (requires accessibility service)
    ok, out = _shell("dumpsys accessibility | grep -A 1000 'Window'", timeout=8)
    if ok and out and "bounds=" in out:
        return out
    return None


def parse_hierarchy(xml: str) -> list[UIElement]:
    """Parse UI hierarchy XML into UIElement objects."""
    elements = []
    # Match all <node> elements with their attributes
    pattern = (
        r'<node\s+([^>]*?)/?>'
    )
    for m in re.finditer(pattern, xml, re.S):
        attrs_str = m.group(1)
        elem = UIElement()

        # Extract attributes
        for attr_match in re.finditer(r'(\w[\w-]*)="([^"]*)"', attrs_str):
            key, val = attr_match.group(1), attr_match.group(2)
            if key == "text":
                elem.text = val
            elif key == "resource-id":
                elem.resource_id = val
            elif key == "content-desc":
                elem.content_desc = val
            elif key == "class":
                elem.class_name = val
            elif key == "package":
                elem.package = val
            elif key == "clickable":
                elem.clickable = val.lower() == "true"
            elif key == "scrollable":
                elem.scrollable = val.lower() == "true"
            elif key == "enabled":
                elem.enabled = val.lower() == "true"
            elif key == "focused":
                elem.focused = val.lower() == "true"
            elif key == "selected":
                elem.selected = val.lower() == "true"
            elif key == "bounds":
                # Format: [x1,y1][x2,y2]
                bm = re.match(r'\[(\d+),(\d+)\]\[(\d+),(\d+)\]', val)
                if bm:
                    elem.bounds = (int(bm.group(1)), int(bm.group(2)),
                                   int(bm.group(3)), int(bm.group(4)))

        elements.append(elem)
    return elements


# ---------------------------------------------------------------------------
# Element Search / Match
# ---------------------------------------------------------------------------

def find_elements(
    text: str = "",
    resource_id: str = "",
    content_desc: str = "",
    class_name: str = "",
    clickable_only: bool = True,
    package: str = "",
    min_area: int = 100,
    max_results: int = 10,
) -> list[UIElement]:
    """Find UI elements matching criteria. Smart matching with fuzzy text."""
    xml = dump_hierarchy()
    if not xml:
        return []

    elements = parse_hierarchy(xml)

    # Filter
    results = []
    for elem in elements:
        if clickable_only and not elem.clickable:
            continue
        if not elem.enabled:
            continue
        if elem.area < min_area:
            continue
        if package and elem.package and package not in elem.package:
            continue

        # Match criteria
        score = 0
        if text:
            t = text.lower()
            if t in elem.text.lower():
                score += 10
            elif t in elem.content_desc.lower():
                score += 8
            elif t in elem.resource_id.lower():
                score += 6
            # Fuzzy: check if all words appear
            words = t.split()
            if all(w in elem.text.lower() for w in words):
                score += 7
            elif all(w in elem.content_desc.lower() for w in words):
                score += 5
            if score == 0:
                continue

        if resource_id:
            if resource_id.lower() in elem.resource_id.lower():
                score += 10
            else:
                continue

        if content_desc:
            if content_desc.lower() in elem.content_desc.lower():
                score += 10
            elif content_desc.lower() in elem.text.lower():
                score += 8
            else:
                continue

        if class_name:
            if class_name.lower() in elem.class_name.lower():
                score += 5
            else:
                continue

        if score > 0:
            results.append((score, elem))

    # Sort by score (best first), then by area (larger = more prominent)
    results.sort(key=lambda x: (-x[0], -x[1].area))
    return [elem for _, elem in results[:max_results]]


def find_best_match(description: str) -> UIElement | None:
    """Find the single best matching element for a natural language description."""
    elements = find_elements(text=description, clickable_only=True, max_results=5)
    if elements:
        return elements[0]

    # Try with content_desc
    elements = find_elements(content_desc=description, clickable_only=True, max_results=5)
    if elements:
        return elements[0]

    # Try partial matches
    words = description.lower().split()
    for word in words:
        if len(word) > 2:
            elements = find_elements(text=word, clickable_only=True, max_results=3)
            if elements:
                return elements[0]

    return None


# ---------------------------------------------------------------------------
# Smart Click Actions
# ---------------------------------------------------------------------------

def smart_click(description: str) -> tuple[bool, str, UIElement | None]:
    """Find and tap an element by description. Returns (success, message, element)."""
    elem = find_best_match(description)
    if not elem:
        return False, f"Could not find element matching '{description}' on screen", None

    cx, cy = elem.center
    ok, out = _shell(f"input tap {cx} {cy}", timeout=5)
    if ok:
        return True, f"Tapped '{elem.label}' at ({cx}, {cy})", elem
    return False, f"Tap failed: {out}", elem


def smart_long_press(description: str, duration_ms: int = 1000) -> tuple[bool, str, UIElement | None]:
    """Find and long-press an element."""
    elem = find_best_match(description)
    if not elem:
        return False, f"Could not find element matching '{description}'", None

    cx, cy = elem.center
    ok, out = _shell(f"input swipe {cx} {cy} {cx} {cy} {duration_ms}", timeout=5)
    if ok:
        return True, f"Long-pressed '{elem.label}' at ({cx}, {cy})", elem
    return False, f"Long-press failed: {out}", elem


def smart_swipe(description: str, direction: str = "up",
                distance: int = 500) -> tuple[bool, str, UIElement | None]:
    """Find an element and swipe from it in a direction."""
    elem = find_best_match(description)
    if not elem:
        # Swipe from center of screen
        size = _get_screen_size()
        if size:
            cx, cy = size[0] // 2, size[1] // 2
        else:
            return False, "Could not determine screen size", None
    else:
        cx, cy = elem.center

    dx, dy = 0, 0
    if direction == "up":
        dy = -distance
    elif direction == "down":
        dy = distance
    elif direction == "left":
        dx = -distance
    elif direction == "right":
        dx = distance

    ok, out = _shell(f"input swipe {cx} {cy} {cx + dx} {cy + dy} 300", timeout=5)
    if ok:
        label = elem.label if elem else "center"
        return True, f"Swiped {direction} from '{label}'", elem
    return False, f"Swipe failed: {out}", elem


def scroll_down(times: int = 1) -> tuple[bool, str]:
    """Scroll down on the screen."""
    size = _get_screen_size()
    if not size:
        return False, "Could not determine screen size"
    cx = size[0] // 2
    y_start = size[1] * 2 // 3
    y_end = size[1] // 3
    for _ in range(times):
        _shell(f"input swipe {cx} {y_start} {cx} {y_end} 300", timeout=5)
    return True, f"Scrolled down {times} time(s)"


def scroll_up(times: int = 1) -> tuple[bool, str]:
    """Scroll up on the screen."""
    size = _get_screen_size()
    if not size:
        return False, "Could not determine screen size"
    cx = size[0] // 2
    y_start = size[1] // 3
    y_end = size[1] * 2 // 3
    for _ in range(times):
        _shell(f"input swipe {cx} {y_start} {cx} {y_end} 300", timeout=5)
    return True, f"Scrolled up {times} time(s)"


# ---------------------------------------------------------------------------
# Screen Analysis
# ---------------------------------------------------------------------------

def _get_screen_size() -> tuple[int, int] | None:
    ok, out = _shell("wm size", timeout=5)
    if not ok:
        return None
    m = re.search(r"(\d+)x(\d+)", out)
    return (int(m.group(1)), int(m.group(2))) if m else None


def screenshot_and_analyze() -> dict:
    """Take a screenshot and analyze what's on screen."""
    path = "/sdcard/zerion_smart_click.png"
    _shell(f"screencap -p {path}", timeout=10)

    xml = dump_hierarchy()
    elements = parse_hierarchy(xml) if xml else []

    # Get screen info
    size = _get_screen_size()
    fg = _shell("dumpsys activity activities | grep mResumedActivity", timeout=5)[1]
    fg_match = re.search(r"(\S+/\S+)", fg)
    foreground = fg_match.group(1) if fg_match else "unknown"

    # Count elements
    clickable = [e for e in elements if e.clickable and e.enabled]
    texts = [e.text for e in elements if e.text.strip()]

    return {
        "screenshot": path,
        "foreground_app": foreground,
        "screen_size": size,
        "total_elements": len(elements),
        "clickable_elements": len(clickable),
        "visible_texts": texts[:20],
        "elements": [e.to_dict() for e in clickable[:30]],
    }


def list_clickable() -> list[dict]:
    """List all currently clickable elements on screen."""
    xml = dump_hierarchy()
    if not xml:
        return []
    elements = parse_hierarchy(xml)
    clickable = [e for e in elements if e.clickable and e.enabled and e.area > 100]
    return [e.to_dict() for e in clickable[:50]]


def tap_element_at(x: int, y: int) -> tuple[bool, str]:
    """Tap at raw coordinates (no element detection)."""
    ok, out = _shell(f"input tap {x} {y}", timeout=5)
    return (True, f"Tapped at ({x}, {y})") if ok else (False, out)


def double_tap(description: str) -> tuple[bool, str, UIElement | None]:
    """Double-tap an element."""
    elem = find_best_match(description)
    if not elem:
        return False, f"Could not find '{description}'", None
    cx, cy = elem.center
    _shell(f"input tap {cx} {cy}", timeout=3)
    import time
    time.sleep(0.1)
    ok, out = _shell(f"input tap {cx} {cy}", timeout=3)
    if ok:
        return True, f"Double-tapped '{elem.label}' at ({cx}, {cy})", elem
    return False, f"Double-tap failed: {out}", elem
