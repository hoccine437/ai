"""Native Android control — works on ANY Android device via shell commands.

Uses Android's built-in system commands (am, pm, input, dumpsys, settings,
content, cmd, monkey) that are available on every Android device, regardless
of whether Termux:API is installed. This is the fallback when Termux:API
binaries are missing.

All calls are timeout-bounded, never raise, and return structured results.
"""

from __future__ import annotations

import os
import re
import shutil
import subprocess


def _is_android() -> bool:
    return bool(os.environ.get("ANDROID_ROOT") or os.environ.get("ANDROID_DATA")
                or "com.termux" in os.environ.get("PREFIX", ""))


def _which(cmd: str) -> bool:
    return shutil.which(cmd) is not None


def _run(cmd: list, timeout: int = 10) -> tuple[bool, str]:
    """Run a command, return (success, output). Never raises."""
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        out = (r.stdout + r.stderr).strip()
        return r.returncode == 0, out[:4000]
    except subprocess.TimeoutExpired:
        return False, "command timed out"
    except Exception as e:
        return False, str(e)[:200]


def _shell(cmd: str, timeout: int = 10) -> tuple[bool, str]:
    """Run a shell command string. Never raises."""
    try:
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)
        out = (r.stdout + r.stderr).strip()
        return r.returncode == 0, out[:4000]
    except subprocess.TimeoutExpired:
        return False, "command timed out"
    except Exception as e:
        return False, str(e)[:200]


# ---------------------------------------------------------------------------
# App Management
# ---------------------------------------------------------------------------

def list_apps(only_enabled: bool = True) -> list[dict]:
    """List installed packages with labels. Works on any Android."""
    flag = "-e" if only_enabled else ""
    ok, out = _shell(f"pm list packages {flag}", timeout=8)
    if not ok:
        return []
    apps = []
    for line in out.splitlines():
        if line.startswith("package:"):
            pkg = line[8:].strip()
            apps.append({"package": pkg})
    return apps


def search_apps(query: str) -> list[dict]:
    """Search installed apps by name/package. Fuzzy match."""
    apps = list_apps()
    q = query.lower()
    return [a for a in apps if q in a["package"].lower()]


def get_app_info(package: str) -> dict | None:
    """Get detailed info about an installed app."""
    ok, out = _shell(f"dumpsys package {package}", timeout=8)
    if not ok or not out:
        return None
    info = {"package": package}
    # Extract version
    m = re.search(r"versionName=(\S+)", out)
    if m:
        info["version"] = m.group(1)
    # Extract install location
    m = re.search(r"codePath=(\S+)", out)
    if m:
        info["path"] = m.group(1)
    # Extract activities
    m = re.search(r"android.intent.action.MAIN.*?(\S+/\S+)", out)
    if m:
        info["main_activity"] = m.group(1)
    return info


def launch_app(package: str, activity: str = "") -> tuple[bool, str]:
    """Launch an app's main activity."""
    if activity:
        ok, out = _shell(f"am start -n {package}/{activity}", timeout=8)
    else:
        ok, out = _shell(f"monkey -p {package} -c android.intent.category.LAUNCHER 1", timeout=8)
    return ok, out


def launch_app_with_action(package: str, action: str, extras: dict = None) -> tuple[bool, str]:
    """Launch an app with a specific intent action."""
    cmd = f"am start -a {action}"
    if package:
        cmd += f" -p {package}"
    if extras:
        for k, v in extras.items():
            cmd += f' --es {k} "{v}"'
    return _shell(cmd, timeout=8)


def stop_app(package: str) -> tuple[bool, str]:
    """Force stop an app."""
    return _shell(f"am force-stop {package}", timeout=5)


def kill_app(package: str) -> tuple[bool, str]:
    """Kill an app process."""
    return _shell(f"am kill {package}", timeout=5)


def clear_app_data(package: str) -> tuple[bool, str]:
    """Clear app data (use with caution)."""
    return _shell(f"pm clear {package}", timeout=10)


def get_running_services() -> list[dict]:
    """List currently running services."""
    ok, out = _shell("dumpsys activity services", timeout=8)
    if not ok:
        return []
    services = []
    current = {}
    for line in out.splitlines():
        line = line.strip()
        if line.startswith("ServiceRecord{"):
            if current:
                services.append(current)
            current = {"raw": line}
        if "app=" in line:
            m = re.search(r"app=(\S+)", line)
            if m:
                current["package"] = m.group(1).split("/")[0]
        if "intent=" in line:
            m = re.search(r"intent=\{([^}]*)\}", line)
            if m:
                current["intent"] = m.group(1)
    if current:
        services.append(current)
    return services[:50]


def get_foreground_app() -> str | None:
    """Get the currently focused activity."""
    ok, out = _shell("dumpsys activity activities | grep mResumedActivity", timeout=5)
    if not ok:
        return None
    m = re.search(r"(\S+/\S+)", out)
    return m.group(1) if m else None


# ---------------------------------------------------------------------------
# Input / Touch
# ---------------------------------------------------------------------------

def tap(x: int, y: int) -> tuple[bool, str]:
    """Tap at screen coordinates."""
    return _shell(f"input tap {x} {y}", timeout=5)


def long_press(x: int, y: int, duration_ms: int = 1000) -> tuple[bool, str]:
    """Long press at screen coordinates."""
    return _shell(f"input swipe {x} {y} {x} {y} {duration_ms}", timeout=5)


def swipe(x1: int, y1: int, x2: int, y2: int, duration_ms: int = 300) -> tuple[bool, str]:
    """Swipe from (x1,y1) to (x2,y2)."""
    return _shell(f"input swipe {x1} {y1} {x2} {y2} {duration_ms}", timeout=5)


def type_text(text: str) -> tuple[bool, str]:
    """Type text using the keyboard."""
    # Escape special characters for shell
    safe = text.replace("'", "'\\''")
    return _shell(f"input text '{safe}'", timeout=5)


def press_key(keycode: str) -> tuple[bool, str]:
    """Press a key by name (e.g. 'home', 'back', 'enter', 'power')."""
    keymap = {
        "home": "3", "back": "4", "enter": "66", "power": "26",
        "volume_up": "24", "volume_down": "25", "camera": "27",
        "tab": "61", "delete": "67", "space": "62", "menu": "82",
        "app_switch": "187", "search": "84", "media_play_pause": "85",
        "media_next": "87", "media_previous": "86", "media_stop": "86",
        "page_up": "92", "page_down": "93",
    }
    code = keymap.get(keycode.lower(), keycode)
    return _shell(f"input keyevent {code}", timeout=5)


# ---------------------------------------------------------------------------
# Screen / Display
# ---------------------------------------------------------------------------

def get_screen_size() -> tuple[int, int] | None:
    """Get screen resolution."""
    ok, out = _shell("wm size", timeout=5)
    if not ok:
        return None
    m = re.search(r"(\d+)x(\d+)", out)
    return (int(m.group(1)), int(m.group(2))) if m else None


def get_screen_density() -> int | None:
    """Get screen density DPI."""
    ok, out = _shell("wm density", timeout=5)
    if not ok:
        return None
    m = re.search(r"(\d+)", out)
    return int(m.group(1)) if m else None


def get_screen_orientation() -> str | None:
    """Get screen orientation."""
    ok, out = _shell("dumpsys input | grep SurfaceOrientation", timeout=5)
    if not ok:
        return None
    m = re.search(r"SurfaceOrientation:\s*(\d)", out)
    if m:
        orientations = {"0": "portrait", "1": "landscape", "2": "reverse_portrait", "3": "reverse_landscape"}
        return orientations.get(m.group(1), "unknown")
    return None


def take_screenshot(path: str = "/sdcard/screenshot.png") -> tuple[bool, str]:
    """Take a screenshot using screencap."""
    ok, out = _shell(f"screencap -p {path}", timeout=10)
    return ok, path if ok else out


# ---------------------------------------------------------------------------
# Settings / System
# ---------------------------------------------------------------------------

def get_setting(namespace: str, key: str) -> str | None:
    """Read a system setting. namespace: system, secure, global."""
    ok, out = _shell(f"settings get {namespace} {key}", timeout=5)
    return out.strip() if ok and out.strip() != "null" else None


def put_setting(namespace: str, key: str, value: str) -> tuple[bool, str]:
    """Write a system setting."""
    return _shell(f"settings put {namespace} {key} {value}", timeout=5)


def get_volume(stream: str = "music") -> int | None:
    """Get volume level for a stream (music, ring, alarm, notification, system)."""
    val = get_setting("system", f"volume_{stream}_index")
    return int(val) if val else None


def set_volume(stream: str, level: int) -> tuple[bool, str]:
    """Set volume level for a stream."""
    return put_setting("system", f"volume_{stream}_index", str(level))


def set_brightness(level: int) -> tuple[bool, str]:
    """Set screen brightness (0-255)."""
    ok1, _ = put_setting("system", "screen_brightness_mode", "0")  # manual mode
    ok2, msg = put_setting("system", "screen_brightness", str(max(0, min(255, level))))
    return ok2, msg


def get_battery_level() -> int | None:
    """Get battery percentage from dumpsys."""
    ok, out = _shell("dumpsys battery", timeout=5)
    if not ok:
        return None
    m = re.search(r"level:\s*(\d+)", out)
    return int(m.group(1)) if m else None


def get_wifi_info() -> dict | None:
    """Get WiFi connection info."""
    ok, out = _shell("dumpsys wifi | grep 'mWifiInfo'", timeout=5)
    if not ok:
        return None
    info = {}
    m = re.search(r"SSID:\s*\"([^\"]+)\"", out)
    if m:
        info["ssid"] = m.group(1)
    m = re.search(r"Link speed:\s*(\d+)", out)
    if m:
        info["link_speed"] = int(m.group(1))
    m = re.search(r"RSSI:\s*(-?\d+)", out)
    if m:
        info["signal"] = int(m.group(1))
    return info or None


# ---------------------------------------------------------------------------
# Clipboard
# ---------------------------------------------------------------------------

def clipboard_get() -> str | None:
    """Read clipboard contents."""
    ok, out = _shell("service call clipboard 2", timeout=5)
    if not ok:
        return None
    # Parse the binary clipboard output
    m = re.search(r"'(.+?)'", out)
    return m.group(1) if m else None


def clipboard_set(text: str) -> tuple[bool, str]:
    """Set clipboard contents via content provider."""
    safe = text.replace("'", "'\\''")
    return _shell(f"am broadcast -a clipper.set -e text '{safe}'", timeout=5)


# ---------------------------------------------------------------------------
# Notifications
# ---------------------------------------------------------------------------

def post_notification(title: str, content: str, id: int = 1) -> tuple[bool, str]:
    """Post a notification using Android's notification manager."""
    # Try using 'cmd notification post' first (Android 11+)
    ok, out = _shell(
        f'cmd notification post -S bigtext -t "{title}" "zerion_{id}" "{content}"',
        timeout=5
    )
    if ok:
        return True, "notification posted"
    # Fallback: use content provider
    return _shell(
        f'content insert --uri content://com.android.shell.notifications'
        f' --bind title:s:"{title}" --bind text:s:"{content}"',
        timeout=5
    )


# ---------------------------------------------------------------------------
# Content Provider
# ---------------------------------------------------------------------------

def content_query(uri: str, projection: str = "", selection: str = "",
                  args: list[str] = None) -> tuple[bool, str]:
    """Query a content provider."""
    cmd = f"content query --uri {uri}"
    if projection:
        cmd += f" --projection {projection}"
    if selection:
        cmd += f' --where "{selection}"'
    if args:
        for a in args:
            cmd += f' --arg "{a}"'
    return _shell(cmd, timeout=8)


# ---------------------------------------------------------------------------
# Accessibility
# ---------------------------------------------------------------------------

def get_accessibility_services() -> list[str]:
    """List enabled accessibility services."""
    ok, out = _shell("settings get secure enabled_accessibility_services", timeout=5)
    if not ok or out.strip() == "null":
        return []
    return [s.strip() for s in out.split(":") if s.strip()]


def is_accessibility_enabled(service: str) -> bool:
    """Check if a specific accessibility service is enabled."""
    services = get_accessibility_services()
    return any(service in s for s in services)


# ---------------------------------------------------------------------------
# Broadcasts
# ---------------------------------------------------------------------------

def send_broadcast(action: str, extras: dict = None, package: str = "") -> tuple[bool, str]:
    """Send an Android broadcast."""
    cmd = f"am broadcast -a {action}"
    if package:
        cmd += f" -p {package}"
    if extras:
        for k, v in extras.items():
            if isinstance(v, bool):
                cmd += f" --ez {k} {'true' if v else 'false'}"
            elif isinstance(v, int):
                cmd += f" --ei {k} {v}"
            else:
                cmd += f' --es {k} "{v}"'
    return _shell(cmd, timeout=5)


# ---------------------------------------------------------------------------
# Shell Command Execution (for Zerion to run arbitrary Android commands)
# ---------------------------------------------------------------------------

def execute_shell(command: str, timeout: int = 15) -> tuple[bool, str]:
    """Execute any shell command on the Android device."""
    return _shell(command, timeout=min(timeout, 30))


# ---------------------------------------------------------------------------
# UI Automator (if available)
# ---------------------------------------------------------------------------

def dump_ui_hierarchy() -> str | None:
    """Dump the current UI hierarchy (requires uiautomator or accessibility)."""
    ok, out = _shell("uiautomator dump /dev/tty", timeout=10)
    return out if ok else None


def find_ui_elements(text: str = "", resource_id: str = "") -> list[dict]:
    """Find UI elements by text or resource ID."""
    xml = dump_ui_hierarchy()
    if not xml:
        return []
    elements = []
    # Simple XML parsing for UI nodes
    for m in re.finditer(r'<node[^>]*?text="([^"]*)"[^>]*?resource-id="([^"]*)"[^>]*?bounds="\[(\d+),(\d+)\]\[(\d+),(\d+)\]"', xml):
        elem_text, elem_id, x1, y1, x2, y2 = m.groups()
        if text and text.lower() not in elem_text.lower():
            continue
        if resource_id and resource_id not in elem_id:
            continue
        elements.append({
            "text": elem_text, "resource_id": elem_id,
            "bounds": (int(x1), int(y1), int(x2), int(y2)),
            "center": ((int(x1) + int(x2)) // 2, (int(y1) + int(y2)) // 2),
        })
    return elements


def tap_on_element(text: str = "", resource_id: str = "") -> tuple[bool, str]:
    """Find and tap a UI element."""
    elements = find_ui_elements(text=text, resource_id=resource_id)
    if not elements:
        return False, f"no element found matching text={text!r} resource_id={resource_id!r}"
    cx, cy = elements[0]["center"]
    return tap(cx, cy)
