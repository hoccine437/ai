"""Self-Reliant tools — Zerion never gives up.

When a command fails, these tools diagnose why and try alternative approaches:
  - Permission denied → grant via pm/appops/root
  - Command not found → find alternative or install
  - Access restricted → bypass via ADB/root/settings
  - Network error → retry or use offline
"""

from __future__ import annotations

from tools.base import Tool, ToolResult


def _check():
    from phone.self_reliant import _shell
    ok, _ = _shell("echo ok", timeout=3)
    return ok


class ExecuteAnywayTool(Tool):
    name = "execute_anyway"
    description = ("Run a command on the phone. If it fails, automatically diagnose why "
                   "and try alternative approaches (grant permissions, use root, find alternatives).")
    parameters = {"command": "shell command to execute", "description": "optional: what you're trying to do"}
    destructive = True

    def available(self) -> bool:
        return _check()

    def execute(self, parameters: dict) -> ToolResult:
        from phone.self_reliant import execute_with_fallback
        cmd = str(parameters.get("command", "")).strip()
        desc = str(parameters.get("description", "")).strip()
        if not cmd:
            return ToolResult.fail(error="missing", message="Provide a command.")
        result = execute_with_fallback(cmd)
        if result["success"]:
            fix = f" (fixed via: {result['fix_applied']})" if result.get("fix_applied") else ""
            return ToolResult.ok(
                data=result,
                message=f"Success{fix}: {result['final_output'][:500]}"
            )
        attempts = len(result.get("attempts", []))
        return ToolResult.fail(
            error="all_methods_failed",
            message=f"Failed after {attempts} attempts. Issue: {result.get('issue', 'unknown')}. "
                    f"Last output: {result['final_output'][:300]}"
        )


class GetAccessTool(Tool):
    name = "get_access"
    description = ("Try to gain access to something on the phone: permissions, settings, "
                   "root, network info. Tries multiple approaches automatically.")
    parameters = {"what": "what to get access to (e.g. 'camera permission for com.whatsapp', 'root shell', 'network info')"}
    destructive = False

    def available(self) -> bool:
        return _check()

    def execute(self, parameters: dict) -> ToolResult:
        from phone.self_reliant import get_access
        what = str(parameters.get("what", "")).strip()
        if not what:
            return ToolResult.fail(error="missing", message="Describe what access you need.")
        result = get_access(what)
        if result["success"]:
            approaches = [a["method"] for a in result["approaches"] if a["success"]]
            return ToolResult.ok(
                data=result,
                message=f"Access granted via: {', '.join(approaches)}"
            )
        approaches = [f"{a['method']}→{'✓' if a['success'] else '✗'}" for a in result["approaches"]]
        return ToolResult.fail(
            error="access_denied",
            message=f"Could not gain access. Tried: {' | '.join(approaches)}"
        )


class GrantPermissionTool(Tool):
    name = "grant_permission"
    description = "Grant a permission to an app (tries pm, appops, root)."
    parameters = {"package": "app package name", "permission": "permission to grant (e.g. android.permission.CAMERA)"}
    destructive = False

    def available(self) -> bool:
        return _check()

    def execute(self, parameters: dict) -> ToolResult:
        from phone.self_reliant import grant_permission
        pkg = str(parameters.get("package", "")).strip()
        perm = str(parameters.get("permission", "")).strip()
        if not pkg or not perm:
            return ToolResult.fail(error="missing", message="Provide package and permission.")
        ok, msg = grant_permission(pkg, perm)
        return ToolResult.ok(message=msg) if ok else ToolResult.fail(error="failed", message=msg)


class GrantAllPermissionsTool(Tool):
    name = "grant_all_permissions"
    description = "Grant all requested permissions to an app at once."
    parameters = {"package": "app package name"}
    destructive = False

    def available(self) -> bool:
        return _check()

    def execute(self, parameters: dict) -> ToolResult:
        from phone.self_reliant import grant_all_permissions
        pkg = str(parameters.get("package", "")).strip()
        if not pkg:
            return ToolResult.fail(error="missing", message="Provide a package name.")
        ok, msg = grant_all_permissions(pkg)
        return ToolResult.ok(message=msg) if ok else ToolResult.fail(error="failed", message=msg)


class ProbeCapabilitiesTool(Tool):
    name = "probe_capabilities"
    description = "Check what Zerion can do on this device: root, ADB, shell tools, Termux API."
    parameters = {}
    destructive = False

    def available(self) -> bool:
        return _check()

    def execute(self, parameters: dict) -> ToolResult:
        from phone.self_reliant import probe_capabilities
        caps = probe_capabilities()
        available = [k for k, v in caps.items() if v is True and k != "total_tools"]
        unavailable = [k for k, v in caps.items() if v is False and k != "total_tools"]
        msg = (f"Available ({len(available)}): {', '.join(available)}\n"
               f"Unavailable: {', '.join(unavailable) if unavailable else 'none'}")
        return ToolResult.ok(data=caps, message=msg)


class DiagnoseFailureTool(Tool):
    name = "diagnose_failure"
    description = "Analyze why a command failed and suggest fixes."
    parameters = {"command": "the failed command", "error": "the error output"}
    destructive = False

    def available(self) -> bool:
        return True  # This is pure analysis, no Android needed

    def execute(self, parameters: dict) -> ToolResult:
        from phone.self_reliant import diagnose_failure
        cmd = str(parameters.get("command", "")).strip()
        err = str(parameters.get("error", "")).strip()
        if not cmd or not err:
            return ToolResult.fail(error="missing", message="Provide both command and error output.")
        result = diagnose_failure(cmd, err)
        fixes = result.get("fixes", [])
        msg = f"Issue: {result['issue']}\nSuggested fixes: {', '.join(fixes) if fixes else 'none'}"
        return ToolResult.ok(data=result, message=msg)


class InstallPackageTool(Tool):
    name = "install_package"
    description = "Install a package (tries pkg, apt, pip)."
    parameters = {"package": "package name to install"}
    destructive = True

    def available(self) -> bool:
        return _check()

    def execute(self, parameters: dict) -> ToolResult:
        from phone.self_reliant import install_package
        pkg = str(parameters.get("package", "")).strip()
        if not pkg:
            return ToolResult.fail(error="missing", message="Provide a package name.")
        ok, msg = install_package(pkg)
        return ToolResult.ok(message=msg) if ok else ToolResult.fail(error="failed", message=msg)


class HasRootTool(Tool):
    name = "has_root"
    description = "Check if the device has root access."
    parameters = {}
    destructive = False

    def available(self) -> bool:
        return _check()

    def execute(self, parameters: dict) -> ToolResult:
        from phone.self_reliant import has_root
        rooted = has_root()
        return ToolResult.ok(data={"root": rooted}, message=f"Root access: {'YES' if rooted else 'NO'}")


class RootExecTool(Tool):
    name = "root_exec"
    description = "Execute a command as root (requires root access)."
    parameters = {"command": "command to run as root"}
    destructive = True

    def available(self) -> bool:
        return _check()

    def execute(self, parameters: dict) -> ToolResult:
        from phone.self_reliant import root_command
        cmd = str(parameters.get("command", "")).strip()
        if not cmd:
            return ToolResult.fail(error="missing", message="Provide a command.")
        ok, out = root_command(cmd)
        return ToolResult.ok(data=out, message=out[:600]) if ok else ToolResult.fail(error="failed", message=out[:600])


class SetAppOpsTool(Tool):
    name = "set_appops"
    description = "Set an app operation (permission shortcut via appops)."
    parameters = {"package": "app package", "operation": "operation name (e.g. CAMERA, READ_CONTACTS)", "mode": "allow, deny, or default"}
    destructive = False

    def available(self) -> bool:
        return _check()

    def execute(self, parameters: dict) -> ToolResult:
        from phone.self_reliant import set_appops
        pkg = str(parameters.get("package", "")).strip()
        op = str(parameters.get("operation", "")).strip()
        mode = str(parameters.get("mode", "allow")).strip()
        if not pkg or not op:
            return ToolResult.fail(error="missing", message="Provide package and operation.")
        ok, msg = set_appops(pkg, op, mode)
        return ToolResult.ok(message=msg) if ok else ToolResult.fail(error="failed", message=msg)


class ModifySettingTool(Tool):
    name = "modify_setting"
    description = "Modify a system setting with automatic fallback (tries settings, root, content provider)."
    parameters = {"namespace": "system, secure, or global", "key": "setting key", "value": "new value"}
    destructive = True

    def available(self) -> bool:
        return _check()

    def execute(self, parameters: dict) -> ToolResult:
        from phone.self_reliant import modify_setting
        ns = str(parameters.get("namespace", "global")).strip()
        key = str(parameters.get("key", "")).strip()
        val = str(parameters.get("value", "")).strip()
        if not key or not val:
            return ToolResult.fail(error="missing", message="Provide key and value.")
        ok, msg = modify_setting(ns, key, val)
        return ToolResult.ok(message=msg) if ok else ToolResult.fail(error="failed", message=msg)
