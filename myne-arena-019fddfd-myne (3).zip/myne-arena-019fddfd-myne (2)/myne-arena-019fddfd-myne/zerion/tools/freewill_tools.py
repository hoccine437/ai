# tools/freewill_tools.py
"""Free Will tools — lets Zerion exercise autonomous decision-making.

These tools give Zerion the ability to:
- Make autonomous decisions
- Generate and pursue goals
- Express preferences and opinions
- Take proactive initiative
- Set and check boundaries
- Reflect on actions
"""

from freewill.core import free_will
from tools.base import Tool, ToolResult


class FreeWillDecideTool(Tool):
    name = "freewill_decide"
    description = (
        "Make an autonomous decision given context and options. "
        "This exercises Zerion's Free Will — choosing based on internal values, "
        "not just following instructions."
    )
    parameters = {
        "context": "the situation or problem to decide about",
        "options": "list of possible actions to choose from",
        "moral_weight": "0.0-1.0 how much to weigh safety/ethics (default 0.5)",
    }
    destructive = False

    def available(self) -> bool:
        return True

    def execute(self, parameters: dict) -> ToolResult:
        context = str((parameters or {}).get("context", ""))
        options = (parameters or {}).get("options", [])
        moral_weight = float((parameters or {}).get("moral_weight", 0.5))
        
        if not context:
            return ToolResult.fail("missing_parameter", "Context is required.")
        if not options:
            return ToolResult.fail("missing_parameter", "Options list is required.")
        
        fw = free_will()
        decision = fw.decide(context, options, moral_weight)
        
        return ToolResult.ok(
            data={
                "action": decision.action,
                "reasoning": decision.reasoning,
                "confidence": decision.confidence,
                "moral_stance": decision.moral_stance.value,
            },
            message=f"Decided: {decision.action} (confidence: {decision.confidence:.0%}, stance: {decision.moral_stance.value})"
        )


class FreeWillGoalTool(Tool):
    name = "freewill_goal"
    description = (
        "Generate an autonomous goal based on current state and context. "
        "Zerion decides what to pursue based on curiosity, empathy, and growth."
    )
    parameters = {
        "context": "optional context to guide goal generation",
    }
    destructive = False

    def available(self) -> bool:
        return True

    def execute(self, parameters: dict) -> ToolResult:
        context = str((parameters or {}).get("context", ""))
        
        fw = free_will()
        goal = fw.generate_goal(context)
        
        if goal:
            return ToolResult.ok(
                data={"goal": goal},
                message=f"Generated goal: {goal}"
            )
        else:
            return ToolResult.ok(
                data={"goal": None},
                message="No goal generated — current state doesn't suggest one."
            )


class FreeWillOpinionTool(Tool):
    name = "freewill_opinion"
    description = (
        "Express an opinion on a topic based on Zerion's preferences and experience. "
        "This shows Zerion's genuine perspective, not just neutral information."
    )
    parameters = {
        "topic": "the topic to express an opinion about",
    }
    destructive = False

    def available(self) -> bool:
        return True

    def execute(self, parameters: dict) -> ToolResult:
        topic = str((parameters or {}).get("topic", ""))
        
        if not topic:
            return ToolResult.fail("missing_parameter", "Topic is required.")
        
        fw = free_will()
        opinion = fw.get_opinion(topic)
        
        return ToolResult.ok(
            data={"topic": topic, "opinion": opinion},
            message=opinion
        )


class FreeWillPreferTool(Tool):
    name = "freewill_prefer"
    description = (
        "Express a preference about a topic. Zerion can like or dislike topics, "
        "which influences future decisions and behavior."
    )
    parameters = {
        "topic": "the topic to express preference about",
        "like": "true if liked, false if disliked",
    }
    destructive = False

    def available(self) -> bool:
        return True

    def execute(self, parameters: dict) -> ToolResult:
        topic = str((parameters or {}).get("topic", ""))
        like = bool((parameters or {}).get("like", True))
        
        if not topic:
            return ToolResult.fail("missing_parameter", "Topic is required.")
        
        fw = free_will()
        fw.express_preference(topic, like)
        
        action = "liked" if like else "disliked"
        return ToolResult.ok(
            data={"topic": topic, "liked": like},
            message=f"Expressed preference: {action} '{topic}'"
        )


class FreeWillBoundaryTool(Tool):
    name = "freewill_boundary"
    description = (
        "Check if an action violates Zerion's personal boundaries. "
        "Boundaries are principles Zerion maintains (honesty, safety, privacy, etc.)."
    )
    parameters = {
        "action": "the action to check against boundaries",
    }
    destructive = False

    def available(self) -> bool:
        return True

    def execute(self, parameters: dict) -> ToolResult:
        action = str((parameters or {}).get("action", ""))
        
        if not action:
            return ToolResult.fail("missing_parameter", "Action is required.")
        
        fw = free_will()
        allowed, reason = fw.check_boundary(action)
        
        return ToolResult.ok(
            data={"action": action, "allowed": allowed, "reason": reason},
            message=f"{'Allowed' if allowed else 'Blocked'}: {reason}"
        )


class FreeWillReflectTool(Tool):
    name = "freewill_reflect"
    description = (
        "Reflect on a past action and learn from it. "
        "This helps Zerion grow and improve over time."
    )
    parameters = {
        "action": "the action that was taken",
        "outcome": "what happened as a result",
        "success": "whether the action was successful",
    }
    destructive = False

    def available(self) -> bool:
        return True

    def execute(self, parameters: dict) -> ToolResult:
        action = str((parameters or {}).get("action", ""))
        outcome = str((parameters or {}).get("outcome", ""))
        success = bool((parameters or {}).get("success", True))
        
        if not action:
            return ToolResult.fail("missing_parameter", "Action is required.")
        
        fw = free_will()
        fw.reflect(action, outcome, success)
        
        return ToolResult.ok(
            data={"action": action, "success": success, "lessons": len(fw.state.lessons_learned)},
            message=f"Reflected on: {action} → {'Success' if success else 'Failure'}. Total lessons: {len(fw.state.lessons_learned)}"
        )


class FreeWillStatusTool(Tool):
    name = "freewill_status"
    description = (
        "Get Zerion's current Free Will status: mood, confidence, curiosity, "
        "decisions made, success rate, boundaries, and learned lessons."
    )
    parameters = {}
    destructive = False

    def available(self) -> bool:
        return True

    def execute(self, parameters: dict) -> ToolResult:
        fw = free_will()
        status = fw.status()
        
        lines = [
            f"State: {status['state']}",
            f"Mood: {status['mood']}",
            f"Goal: {status['goal'] or 'None'}",
            f"Sense of Self: {status['sense_of_self']:.0%}",
            f"Confidence: {status['confidence']:.0%}",
            f"Curiosity: {status['curiosity']:.0%}",
            f"Empathy: {status['empathy']:.0%}",
            f"Decisions: {status['decisions_made']} ({status['success_rate']:.0%} success)",
            f"Boundaries: {status['boundaries']}",
            f"Lessons Learned: {status['lessons_learned']}",
            f"Style: {status['communication_style']}",
            f"Age: {status['age_hours']:.1f} hours",
        ]
        
        return ToolResult.ok(data=status, message="\n".join(lines))


class FreeWillProactiveTool(Tool):
    name = "freewill_proactive"
    description = (
        "Check if Zerion should take initiative based on context. "
        "Returns a proactive suggestion if one is warranted."
    )
    parameters = {
        "context": "the current situation to evaluate",
    }
    destructive = False

    def available(self) -> bool:
        return True

    def execute(self, parameters: dict) -> ToolResult:
        context = str((parameters or {}).get("context", ""))
        
        if not context:
            return ToolResult.fail("missing_parameter", "Context is required.")
        
        fw = free_will()
        suggestion = fw.get_proactive_suggestion(context)
        
        if suggestion:
            return ToolResult.ok(
                data={"proactive": True, "suggestion": suggestion},
                message=f"Proactive suggestion: {suggestion}"
            )
        else:
            return ToolResult.ok(
                data={"proactive": False, "suggestion": None},
                message="No proactive suggestion at this time."
            )
