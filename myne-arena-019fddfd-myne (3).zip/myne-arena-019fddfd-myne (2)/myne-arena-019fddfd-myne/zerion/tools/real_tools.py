# tools/real_tools.py
"""Real tool execution logic — tools that actually INTERACT with the system.

Each tool class wraps actual system interactions:
  - RealFileTools: actual file operations with safety checks
  - RealShellTools: actual command execution with sandboxing
  - RealNetworkTools: actual HTTP requests and network operations
  - RealSystemTools: actual system monitoring and management
  - RealDataTools: actual data processing and analysis
  - RealSecurityTools: actual security scanning and auditing
  - RealMemoryTools: actual persistent memory operations
  - RealAgentTools: actual agent spawning and coordination
"""

from __future__ import annotations

import json
import os
import subprocess
import time
import threading
import hashlib
from typing import Any, Optional


class RealTool:
    """Base class for real tools with actual capabilities."""
    
    def __init__(self, name: str, destructive: bool = False):
        self.name = name
        self.destructive = destructive
        self._lock = threading.Lock()
        self._execution_count = 0
        self._last_execution = 0.0
    
    def execute(self, parameters: dict) -> dict:
        """Execute the tool with real logic."""
        with self._lock:
            self._execution_count += 1
            self._last_execution = time.time()
        
        try:
            # Safety check for destructive tools
            if self.destructive:
                confirmation = parameters.get("confirm", False)
                if not confirmation:
                    return {
                        "success": False,
                        "error": "confirmation_required",
                        "message": f"Destructive tool '{self.name}' requires confirm=true"
                    }
            
            return self._do_execute(parameters)
        except Exception as e:
            return {"success": False, "error": str(e), "message": f"Tool execution failed: {e}"}
    
    def _do_execute(self, parameters: dict) -> dict:
        """Override in subclasses to implement actual logic."""
        return {"success": False, "error": "not_implemented", "message": f"Tool '{self.name}' needs implementation"}
    
    def status(self) -> dict:
        """Return tool status."""
        return {
            "name": self.name,
            "destructive": self.destructive,
            "executions": self._execution_count,
            "last_execution": self._last_execution,
        }


class RealFileTools(RealTool):
    """Real file operations with safety checks."""
    
    def __init__(self):
        super().__init__("file_tools")
    
    def _do_execute(self, parameters: dict) -> dict:
        action = parameters.get("action", "")
        path = parameters.get("path", "")
        content = parameters.get("content", "")
        
        if not action:
            return {"success": False, "error": "missing_action", "message": "No action provided"}
        
        # Safety: block dangerous paths
        dangerous_paths = ["/", "/bin", "/sbin", "/usr", "/etc", "/var"]
        if path and any(path.startswith(p) for p in dangerous_paths):
            return {"success": False, "error": "dangerous_path", "message": "Access to system directories blocked"}
        
        try:
            if action == "read":
                if not path:
                    return {"success": False, "error": "missing_path", "message": "No path provided"}
                
                if not os.path.exists(path):
                    return {"success": False, "error": "not_found", "message": f"File not found: {path}"}
                
                with open(path, "r", encoding="utf-8", errors="ignore") as f:
                    content = f.read()
                
                return {
                    "success": True,
                    "content": content,
                    "size": len(content),
                    "message": f"Read {len(content)} chars from {path}"
                }
            
            elif action == "write":
                if not path:
                    return {"success": False, "error": "missing_path", "message": "No path provided"}
                
                # Create directory if needed
                os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
                
                with open(path, "w", encoding="utf-8") as f:
                    f.write(content)
                
                return {
                    "success": True,
                    "size": len(content),
                    "message": f"Wrote {len(content)} chars to {path}"
                }
            
            elif action == "list":
                if not path:
                    path = "."
                
                if not os.path.exists(path):
                    return {"success": False, "error": "not_found", "message": f"Directory not found: {path}"}
                
                if not os.path.isdir(path):
                    return {"success": False, "error": "not_directory", "message": f"Not a directory: {path}"}
                
                items = os.listdir(path)
                return {
                    "success": True,
                    "items": items,
                    "count": len(items),
                    "message": f"Listed {len(items)} items in {path}"
                }
            
            elif action == "exists":
                if not path:
                    return {"success": False, "error": "missing_path", "message": "No path provided"}
                
                exists = os.path.exists(path)
                return {
                    "success": True,
                    "exists": exists,
                    "message": f"{path} {'exists' if exists else 'does not exist'}"
                }
            
            elif action == "delete":
                if not path:
                    return {"success": False, "error": "missing_path", "message": "No path provided"}
                
                if not os.path.exists(path):
                    return {"success": False, "error": "not_found", "message": f"File not found: {path}"}
                
                # Safety: don't delete directories without explicit flag
                if os.path.isdir(path) and not parameters.get("recursive", False):
                    return {"success": False, "error": "is_directory", "message": "Use recursive=true to delete directories"}
                
                if os.path.isdir(path):
                    import shutil
                    shutil.rmtree(path)
                else:
                    os.remove(path)
                
                return {"success": True, "message": f"Deleted {path}"}
            
            elif action == "copy":
                src = path
                dst = parameters.get("destination", "")
                if not src or not dst:
                    return {"success": False, "error": "missing_params", "message": "source and destination required"}
                
                if not os.path.exists(src):
                    return {"success": False, "error": "not_found", "message": f"Source not found: {src}"}
                
                import shutil
                shutil.copy2(src, dst)
                return {"success": True, "message": f"Copied {src} to {dst}"}
            
            elif action == "move":
                src = path
                dst = parameters.get("destination", "")
                if not src or not dst:
                    return {"success": False, "error": "missing_params", "message": "source and destination required"}
                
                if not os.path.exists(src):
                    return {"success": False, "error": "not_found", "message": f"Source not found: {src}"}
                
                import shutil
                shutil.move(src, dst)
                return {"success": True, "message": f"Moved {src} to {dst}"}
            
            else:
                return {"success": False, "error": "unknown_action", "message": f"Unknown action: {action}"}
        
        except Exception as e:
            return {"success": False, "error": str(e), "message": f"File operation failed: {e}"}


class RealShellTools(RealTool):
    """Real command execution with sandboxing."""
    
    def __init__(self):
        super().__init__("shell_tools", destructive=True)
    
    def _do_execute(self, parameters: dict) -> dict:
        command = parameters.get("command", "")
        if not command:
            return {"success": False, "error": "missing_command", "message": "No command provided"}
        
        # Safety: block dangerous commands
        dangerous_commands = [
            "rm -rf /", "mkfs", "dd if=", "> /dev/", "shutdown", "reboot",
            "halt", "init 0", "init 6", ":(){", "fork bomb", "chmod -R 777 /",
        ]
        
        if any(d in command.lower() for d in dangerous_commands):
            return {"success": False, "error": "dangerous_command", "message": "This command is blocked for safety"}
        
        # Safety: timeout
        timeout = min(parameters.get("timeout", 30), 60)  # Max 60 seconds
        
        try:
            result = subprocess.run(
                command,
                shell=True,
                capture_output=True,
                text=True,
                timeout=timeout,
                cwd=os.getcwd()
            )
            
            return {
                "success": result.returncode == 0,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "returncode": result.returncode,
                "message": f"Command completed (exit {result.returncode})"
            }
        except subprocess.TimeoutExpired:
            return {"success": False, "error": "timeout", "message": f"Command timed out ({timeout}s)"}
        except Exception as e:
            return {"success": False, "error": str(e), "message": f"Command failed: {e}"}


class RealNetworkTools(RealTool):
    """Real HTTP requests and network operations."""
    
    def __init__(self):
        super().__init__("network_tools")
    
    def _do_execute(self, parameters: dict) -> dict:
        action = parameters.get("action", "get")
        url = parameters.get("url", "")
        
        if not url:
            return {"success": False, "error": "missing_url", "message": "No URL provided"}
        
        try:
            import urllib.request
            
            method = action.upper()
            headers = parameters.get("headers", {})
            data = parameters.get("data", "")
            
            headers.setdefault("User-Agent", "Zerion/1.0")
            
            if data and method == "POST":
                if isinstance(data, dict):
                    data = json.dumps(data)
                    headers.setdefault("Content-Type", "application/json")
                
                req = urllib.request.Request(
                    url,
                    data=data.encode("utf-8") if isinstance(data, str) else data,
                    headers=headers,
                    method=method
                )
            else:
                req = urllib.request.Request(url, headers=headers, method=method)
            
            with urllib.request.urlopen(req, timeout=15) as response:
                body = response.read().decode("utf-8", errors="ignore")
                
                # Try to parse as JSON
                try:
                    json_body = json.loads(body)
                    return {
                        "success": True,
                        "status": response.status,
                        "json": json_body,
                        "message": f"HTTP {response.status} - JSON response"
                    }
                except json.JSONDecodeError:
                    return {
                        "success": True,
                        "status": response.status,
                        "body": body[:10000],  # Limit response size
                        "message": f"HTTP {response.status} - text response ({len(body)} chars)"
                    }
        except Exception as e:
            return {"success": False, "error": str(e), "message": f"Network request failed: {e}"}


class RealSystemTools(RealTool):
    """Real system monitoring and management."""
    
    def __init__(self):
        super().__init__("system_tools")
    
    def _do_execute(self, parameters: dict) -> dict:
        action = parameters.get("action", "status")
        
        try:
            if action == "status":
                import platform
                return {
                    "success": True,
                    "system": platform.system(),
                    "release": platform.release(),
                    "python": platform.python_version(),
                    "pid": os.getpid(),
                    "cwd": os.getcwd(),
                    "message": f"System: {platform.system()} {platform.release()}"
                }
            
            elif action == "memory":
                try:
                    with open("/proc/meminfo", "r") as f:
                        lines = f.readlines()
                    
                    mem_info = {}
                    for line in lines:
                        parts = line.split()
                        if len(parts) >= 2:
                            key = parts[0].rstrip(":")
                            value = int(parts[1])
                            mem_info[key] = value
                    
                    total = mem_info.get("MemTotal", 0)
                    available = mem_info.get("MemAvailable", 0)
                    
                    return {
                        "success": True,
                        "total_mb": round(total / 1024),
                        "available_mb": round(available / 1024),
                        "used_mb": round((total - available) / 1024),
                        "message": f"Memory: {round((total - available) / 1024)}MB used"
                    }
                except Exception:
                    return {"success": True, "message": "Memory info not available"}
            
            elif action == "disk":
                try:
                    stat = os.statvfs("/")
                    total = stat.f_blocks * stat.f_frsize
                    free = stat.f_bavail * stat.f_frsize
                    used = total - free
                    
                    return {
                        "success": True,
                        "total_gb": round(total / (1024**3), 1),
                        "used_gb": round(used / (1024**3), 1),
                        "free_gb": round(free / (1024**3), 1),
                        "message": f"Disk: {round(used/(1024**3))}GB / {round(total/(1024**3))}GB"
                    }
                except Exception:
                    return {"success": True, "message": "Disk info not available"}
            
            elif action == "processes":
                try:
                    result = subprocess.run(["ps", "aux", "--sort=-pcpu"], capture_output=True, text=True, timeout=5)
                    lines = result.stdout.strip().split("\n")
                    return {
                        "success": True,
                        "process_count": len(lines) - 1,
                        "message": f"Found {len(lines) - 1} processes"
                    }
                except Exception:
                    return {"success": True, "message": "Process listing not available"}
            
            else:
                return {"success": False, "error": "unknown_action", "message": f"Unknown action: {action}"}
        
        except Exception as e:
            return {"success": False, "error": str(e), "message": f"System operation failed: {e}"}


class RealDataTools(RealTool):
    """Real data processing and analysis."""
    
    def __init__(self):
        super().__init__("data_tools")
    
    def _do_execute(self, parameters: dict) -> dict:
        action = parameters.get("action", "")
        data = parameters.get("data", "")
        
        if not action:
            return {"success": False, "error": "missing_action", "message": "No action provided"}
        
        try:
            if action == "json_parse":
                if not data:
                    return {"success": False, "error": "missing_data", "message": "No data to parse"}
                
                try:
                    parsed = json.loads(data)
                    return {"success": True, "data": parsed, "message": f"Parsed JSON ({type(parsed).__name__})"}
                except json.JSONDecodeError as e:
                    return {"success": False, "error": "invalid_json", "message": f"Invalid JSON: {e}"}
            
            elif action == "json_format":
                if not data:
                    return {"success": False, "error": "missing_data", "message": "No data to format"}
                
                try:
                    parsed = json.loads(data)
                    formatted = json.dumps(parsed, indent=2, ensure_ascii=False)
                    return {"success": True, "formatted": formatted, "message": "Formatted JSON"}
                except json.JSONDecodeError as e:
                    return {"success": False, "error": "invalid_json", "message": f"Invalid JSON: {e}"}
            
            elif action == "hash":
                if not data:
                    return {"success": False, "error": "missing_data", "message": "No data to hash"}
                
                algorithm = parameters.get("algorithm", "sha256")
                h = hashlib.new(algorithm)
                h.update(data.encode("utf-8"))
                return {"success": True, "hash": h.hexdigest(), "algorithm": algorithm, "message": f"Computed {algorithm} hash"}
            
            elif action == "base64_encode":
                if not data:
                    return {"success": False, "error": "missing_data", "message": "No data to encode"}
                
                import base64
                encoded = base64.b64encode(data.encode("utf-8")).decode("utf-8")
                return {"success": True, "encoded": encoded, "message": "Base64 encoded"}
            
            elif action == "base64_decode":
                if not data:
                    return {"success": False, "error": "missing_data", "message": "No data to decode"}
                
                import base64
                decoded = base64.b64decode(data.encode("utf-8")).decode("utf-8")
                return {"success": True, "decoded": decoded, "message": "Base64 decoded"}
            
            else:
                return {"success": False, "error": "unknown_action", "message": f"Unknown action: {action}"}
        
        except Exception as e:
            return {"success": False, "error": str(e), "message": f"Data operation failed: {e}"}


class RealSecurityTools(RealTool):
    """Real security scanning and auditing."""
    
    def __init__(self):
        super().__init__("security_tools")
    
    def _do_execute(self, parameters: dict) -> dict:
        action = parameters.get("action", "")
        target = parameters.get("target", "")
        
        if not action:
            return {"success": False, "error": "missing_action", "message": "No action provided"}
        
        try:
            if action == "hash":
                if not target:
                    return {"success": False, "error": "missing_target", "message": "No target to hash"}
                
                algorithm = parameters.get("algorithm", "sha256")
                h = hashlib.new(algorithm)
                h.update(target.encode("utf-8"))
                return {"success": True, "hash": h.hexdigest(), "algorithm": algorithm, "message": f"Computed {algorithm} hash"}
            
            elif action == "check_permissions":
                if not target:
                    return {"success": False, "error": "missing_target", "message": "No path to check"}
                
                if os.path.exists(target):
                    stat = os.stat(target)
                    return {
                        "success": True,
                        "readable": os.access(target, os.R_OK),
                        "writable": os.access(target, os.W_OK),
                        "executable": os.access(target, os.X_OK),
                        "mode": oct(stat.st_mode),
                        "message": f"Permissions for {target}"
                    }
                else:
                    return {"success": False, "error": "not_found", "message": f"Path not found: {target}"}
            
            elif action == "scan_file":
                if not target:
                    return {"success": False, "error": "missing_target", "message": "No file to scan"}
                
                if not os.path.exists(target):
                    return {"success": False, "error": "not_found", "message": f"File not found: {target}"}
                
                # Check for suspicious patterns
                suspicious_patterns = ["eval(", "exec(", "subprocess.call", "os.system", "__import__"]
                findings = []
                
                with open(target, "r", encoding="utf-8", errors="ignore") as f:
                    for i, line in enumerate(f, 1):
                        for pattern in suspicious_patterns:
                            if pattern in line:
                                findings.append(f"Line {i}: {pattern}")
                
                return {
                    "success": True,
                    "findings": findings,
                    "clean": len(findings) == 0,
                    "message": f"Found {len(findings)} suspicious patterns" if findings else "File looks clean"
                }
            
            else:
                return {"success": False, "error": "unknown_action", "message": f"Unknown action: {action}"}
        
        except Exception as e:
            return {"success": False, "error": str(e), "message": f"Security operation failed: {e}"}


class RealMemoryTools(RealTool):
    """Real persistent memory operations."""
    
    def __init__(self):
        super().__init__("memory_tools")
        self._memory_path = os.path.join(os.path.dirname(__file__), "..", "memory", "real_memory.json")
    
    def _do_execute(self, parameters: dict) -> dict:
        action = parameters.get("action", "")
        key = parameters.get("key", "")
        value = parameters.get("value", "")
        
        if not action:
            return {"success": False, "error": "missing_action", "message": "No action provided"}
        
        try:
            # Load existing memory
            memory = {}
            if os.path.exists(self._memory_path):
                with open(self._memory_path, "r", encoding="utf-8") as f:
                    memory = json.load(f)
            
            if action == "store":
                if not key:
                    return {"success": False, "error": "missing_key", "message": "No key provided"}
                
                memory[key] = {
                    "value": value,
                    "timestamp": time.time(),
                    "source": parameters.get("source", "user")
                }
                
                os.makedirs(os.path.dirname(self._memory_path), exist_ok=True)
                with open(self._memory_path, "w", encoding="utf-8") as f:
                    json.dump(memory, f, indent=2, ensure_ascii=False)
                
                return {"success": True, "message": f"Stored key '{key}'"}
            
            elif action == "retrieve":
                if key:
                    if key in memory:
                        return {"success": True, "data": memory[key], "message": f"Retrieved key '{key}'"}
                    else:
                        return {"success": False, "error": "not_found", "message": f"Key '{key}' not found"}
                else:
                    return {"success": True, "keys": list(memory.keys()), "message": f"Found {len(memory)} entries"}
            
            elif action == "search":
                if not key:
                    return {"success": False, "error": "missing_query", "message": "No search query"}
                
                query = key.lower()
                results = []
                for k, v in memory.items():
                    if query in k.lower() or query in str(v.get("value", "")).lower():
                        results.append({"key": k, "data": v})
                
                return {"success": True, "results": results, "message": f"Found {len(results)} matches"}
            
            elif action == "delete":
                if key and key in memory:
                    del memory[key]
                    with open(self._memory_path, "w", encoding="utf-8") as f:
                        json.dump(memory, f, indent=2, ensure_ascii=False)
                    return {"success": True, "message": f"Deleted key '{key}'"}
                else:
                    return {"success": False, "error": "not_found", "message": f"Key '{key}' not found"}
            
            else:
                return {"success": False, "error": "unknown_action", "message": f"Unknown action: {action}"}
        
        except Exception as e:
            return {"success": False, "error": str(e), "message": f"Memory operation failed: {e}"}


class RealAgentTools(RealTool):
    """Real agent spawning and coordination."""
    
    def __init__(self):
        super().__init__("agent_tools")
    
    def _do_execute(self, parameters: dict) -> dict:
        action = parameters.get("action", "")
        agent_type = parameters.get("agent_type", "")
        task = parameters.get("task", {})
        
        if not action:
            return {"success": False, "error": "missing_action", "message": "No action provided"}
        
        try:
            from agents.engine import engine
            from agents.types import AGENT_TYPES
            
            if action == "spawn":
                if not agent_type:
                    return {"success": False, "error": "missing_type", "message": "No agent type provided"}
                
                if agent_type not in AGENT_TYPES:
                    return {
                        "success": False,
                        "error": "invalid_type",
                        "message": f"Unknown type: {agent_type}. Available: {', '.join(AGENT_TYPES.keys())}"
                    }
                
                result = engine.spawn(agent_type, task, wait=True)
                return result
            
            elif action == "status":
                stats = engine.stats()
                return {
                    "success": True,
                    "stats": stats,
                    "message": f"Pool: {stats['capacity']} capacity, {stats['inflight']} running"
                }
            
            elif action == "list_types":
                types = engine.list_types()
                return {"success": True, "types": types, "message": f"Found {len(types)} agent types"}
            
            else:
                return {"success": False, "error": "unknown_action", "message": f"Unknown action: {action}"}
        
        except Exception as e:
            return {"success": False, "error": str(e), "message": f"Agent operation failed: {e}"}


# Global tool instances
REAL_TOOLS = {
    "file": RealFileTools(),
    "shell": RealShellTools(),
    "network": RealNetworkTools(),
    "system": RealSystemTools(),
    "data": RealDataTools(),
    "security": RealSecurityTools(),
    "memory": RealMemoryTools(),
    "agent": RealAgentTools(),
}


def execute_real_tool(name: str, parameters: dict) -> dict:
    """Execute a real tool by name with given parameters."""
    tool = REAL_TOOLS.get(name)
    if not tool:
        return {"success": False, "error": "unknown_tool", "message": f"Unknown tool: {name}"}
    return tool.execute(parameters)


def get_real_tool_status(name: str = "") -> dict:
    """Get status of a specific tool or all tools."""
    if name:
        tool = REAL_TOOLS.get(name)
        if not tool:
            return {"success": False, "error": "unknown_tool", "message": f"Unknown tool: {name}"}
        return {"tool": name, **tool.status()}
    
    return {
        "tools": {
            name: tool.status()
            for name, tool in REAL_TOOLS.items()
        },
        "total": len(REAL_TOOLS)
    }
