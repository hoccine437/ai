"""Smart Click tools — intelligent UI element detection and interaction.

These tools let Zerion understand what's on screen and interact with it
intelligently: find buttons by text, tap them, scroll, swipe, and analyze.
"""

from __future__ import annotations

from tools.base import Tool, ToolResult


def _check():
    from phone.smart_click import _shell
    ok, _ = _shell("which input", timeout=3)
    return ok


class SmartClickTool(Tool):
    name = "smart_click"
    description = ("Find a UI element on screen by its text or description and tap it. "
                   "Examples: 'smart_click(text=Send)', 'smart_click(text=OK)', "
                   "'smart_click(text=Chrome)', 'smart_click(text=Settings)')")
    parameters = {"text": "text or description of the element to find and tap"}
    destructive = False

    def available(self) -> bool:
        return _check()

    def execute(self, parameters: dict) -> ToolResult:
        from phone.smart_click import smart_click
        text = str(parameters.get("text", "")).strip()
        if not text:
            return ToolResult.fail(error="missing_parameter", message="Provide the text to find and tap.")
        ok, msg, elem = smart_click(text)
        data = elem.to_dict() if elem else None
        return ToolResult.ok(data=data, message=msg) if ok else ToolResult.fail(error="not_found", message=msg)


class SmartLongPressTool(Tool):
    name = "smart_long_press"
    description = "Find a UI element and long-press it."
    parameters = {"text": "text or description of the element", "duration_ms": "long press duration in ms (default 1000)"}
    destructive = False

    def available(self) -> bool:
        return _check()

    def execute(self, parameters: dict) -> ToolResult:
        from phone.smart_click import smart_long_press
        text = str(parameters.get("text", "")).strip()
        if not text:
            return ToolResult.fail(error="missing_parameter", message="Provide the text to find.")
        try:
            dur = int(parameters.get("duration_ms", 1000))
        except (ValueError, TypeError):
            dur = 1000
        ok, msg, elem = smart_long_press(text, dur)
        data = elem.to_dict() if elem else None
        return ToolResult.ok(data=data, message=msg) if ok else ToolResult.fail(error="not_found", message=msg)


class SmartSwipeTool(Tool):
    name = "smart_swipe"
    description = "Find an element and swipe from it, or swipe on the screen in a direction."
    parameters = {"direction": "up, down, left, or right", "from_text": "optional: element to swipe from", "distance": "swipe distance in pixels (default 500)"}
    destructive = False

    def available(self) -> bool:
        return _check()

    def execute(self, parameters: dict) -> ToolResult:
        from phone.smart_click import smart_swipe
        direction = str(parameters.get("direction", "up")).strip().lower()
        from_text = str(parameters.get("from_text", "")).strip()
        try:
            distance = int(parameters.get("distance", 500))
        except (ValueError, TypeError):
            distance = 500
        ok, msg, elem = smart_swipe(direction=direction, description=from_text, distance=distance)
        return ToolResult.ok(message=msg) if ok else ToolResult.fail(error="swipe_failed", message=msg)


class ScrollTool(Tool):
    name = "scroll"
    description = "Scroll the screen up or down."
    parameters = {"direction": "up or down", "times": "number of scroll actions (default 1)"}
    destructive = False

    def available(self) -> bool:
        return _check()

    def execute(self, parameters: dict) -> ToolResult:
        from phone.smart_click import scroll_down, scroll_up
        direction = str(parameters.get("direction", "down")).strip().lower()
        try:
            times = int(parameters.get("times", 1))
        except (ValueError, TypeError):
            times = 1
        if direction == "up":
            ok, msg = scroll_up(times)
        else:
            ok, msg = scroll_down(times)
        return ToolResult.ok(message=msg) if ok else ToolResult.fail(error="scroll_failed", message=msg)


class DoubleTapTool(Tool):
    name = "double_tap"
    description = "Double-tap a UI element on screen."
    parameters = {"text": "text or description of the element to double-tap"}
    destructive = False

    def available(self) -> bool:
        return _check()

    def execute(self, parameters: dict) -> ToolResult:
        from phone.smart_click import double_tap
        text = str(parameters.get("text", "")).strip()
        if not text:
            return ToolResult.fail(error="missing_parameter", message="Provide the text to find.")
        ok, msg, elem = double_tap(text)
        data = elem.to_dict() if elem else None
        return ToolResult.ok(data=data, message=msg) if ok else ToolResult.fail(error="not_found", message=msg)


class AnalyzeScreenTool(Tool):
    name = "analyze_screen"
    description = "Take a screenshot and analyze what's on screen: foreground app, clickable elements, visible text."
    parameters = {}
    destructive = False

    def available(self) -> bool:
        return _check()

    def execute(self, parameters: dict) -> ToolResult:
        from phone.smart_click import screenshot_and_analyze
        info = screenshot_and_analyze()
        parts = [
            f"App: {info.get('foreground_app', '?')}",
            f"Screen: {info.get('screen_size', '?')}",
            f"Clickable: {info.get('clickable_elements', 0)} elements",
        ]
        texts = info.get("visible_texts", [])
        if texts:
            parts.append(f"Visible: {', '.join(texts[:10])}")
        return ToolResult.ok(data=info, message=" | ".join(parts))


class ListClickableTool(Tool):
    name = "list_clickable"
    description = "List all clickable elements currently visible on screen with their text and position."
    parameters = {}
    destructive = False

    def available(self) -> bool:
        return _check()

    def execute(self, parameters: dict) -> ToolResult:
        from phone.smart_click import list_clickable
        elements = list_clickable()
        if not elements:
            return ToolResult.ok(message="No clickable elements found on screen.")
        parts = []
        for e in elements[:20]:
            label = e.get("text") or e.get("content_desc") or e.get("resource_id", "?")
            center = e.get("center", [0, 0])
            parts.append(f"  [{center[0]},{center[1]}] {label}")
        return ToolResult.ok(data=elements, message=f"{len(elements)} clickable elements:\n" + "\n".join(parts))


class TapAtTool(Tool):
    name = "tap_at"
    description = "Tap at specific screen coordinates (x, y)."
    parameters = {"x": "horizontal coordinate", "y": "vertical coordinate"}
    destructive = False

    def available(self) -> bool:
        return _check()

    def execute(self, parameters: dict) -> ToolResult:
        from phone.smart_click import tap_element_at
        try:
            x = int(parameters.get("x", 0))
            y = int(parameters.get("y", 0))
        except (ValueError, TypeError):
            return ToolResult.fail(error="invalid", message="x and y must be integers")
        ok, msg = tap_element_at(x, y)
        return ToolResult.ok(message=msg) if ok else ToolResult.fail(error="tap_failed", message=msg)


class SmartTypeTool(Tool):
    name = "smart_type"
    description = "Type text into the currently focused input field."
    parameters = {"text": "text to type"}
    destructive = False

    def available(self) -> bool:
        return _check()

    def execute(self, parameters: dict) -> ToolResult:
        text = str(parameters.get("text", "")).strip()
        if not text:
            return ToolResult.fail(error="missing_parameter", message="Provide text to type.")
        from phone.smart_click import _shell
        safe = text.replace("'", "'\\''")
        ok, out = _shell(f"input text '{safe}'", timeout=5)
        return ToolResult.ok(message=f"Typed: {text}") if ok else ToolResult.fail(error="type_failed", message=out)


class GoBackTool(Tool):
    name = "go_back"
    description = "Press the back button."
    parameters = {}
    destructive = False

    def available(self) -> bool:
        return _check()

    def execute(self, parameters: dict) -> ToolResult:
        from phone.smart_click import _shell
        ok, _ = _shell("input keyevent 4", timeout=3)
        return ToolResult.ok(message="Pressed back") if ok else ToolResult.fail(error="failed", message="Back press failed")


class GoHomeTool(Tool):
    name = "go_home"
    description = "Press the home button."
    parameters = {}
    destructive = False

    def available(self) -> bool:
        return _check()

    def execute(self, parameters: dict) -> ToolResult:
        from phone.smart_click import _shell
        ok, _ = _shell("input keyevent 3", timeout=3)
        return ToolResult.ok(message="Pressed home") if ok else ToolResult.fail(error="failed", message="Home press failed")
