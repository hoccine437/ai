"""Phone settings tools — comprehensive control over all Android settings.

These tools let Zerion control every setting on the phone:
WiFi, Bluetooth, Sound, Display, Battery, Network, Location, NFC,
Airplane mode, Dark mode, Font size, Notifications, and more.
"""

from __future__ import annotations

from tools.base import Tool, ToolResult


def _check():
    from phone.settings import _is_android
    return _is_android()


class WifiToggleTool(Tool):
    name = "wifi_toggle"
    description = "Turn WiFi on or off."
    parameters = {"enabled": "true to turn on, false to turn off"}
    destructive = False
    def available(self): return _check()
    def execute(self, parameters):
        from phone.settings import wifi_set_enabled
        enabled = str(parameters.get("enabled", "")).lower() in ("true", "1", "on", "yes")
        ok, msg = wifi_set_enabled(enabled)
        return ToolResult.ok(message=msg) if ok else ToolResult.fail(error="failed", message=msg)


class WifiStatusTool(Tool):
    name = "wifi_status"
    description = "Get WiFi status: enabled, connected network, signal strength."
    parameters = {}
    destructive = False
    def available(self): return _check()
    def execute(self, parameters):
        from phone.settings import wifi_enabled, wifi_connected
        enabled = wifi_enabled()
        connected = wifi_connected()
        parts = [f"WiFi: {'ON' if enabled else 'OFF'}"]
        if connected:
            parts.append(f"Connected to: {connected.get('ssid', '?')}")
            parts.append(f"Signal: {connected.get('signal_dbm', '?')} dBm")
        return ToolResult.ok(data={"enabled": enabled, "connected": connected}, message=" | ".join(parts))


class BluetoothToggleTool(Tool):
    name = "bluetooth_toggle"
    description = "Turn Bluetooth on or off."
    parameters = {"enabled": "true to turn on, false to turn off"}
    destructive = False
    def available(self): return _check()
    def execute(self, parameters):
        from phone.settings import bluetooth_set_enabled
        enabled = str(parameters.get("enabled", "")).lower() in ("true", "1", "on", "yes")
        ok, msg = bluetooth_set_enabled(enabled)
        return ToolResult.ok(message=msg) if ok else ToolResult.fail(error="failed", message=msg)


class BluetoothStatusTool(Tool):
    name = "bluetooth_status"
    description = "Get Bluetooth status and paired devices."
    parameters = {}
    destructive = False
    def available(self): return _check()
    def execute(self, parameters):
        from phone.settings import bluetooth_enabled, bluetooth_paired_devices
        enabled = bluetooth_enabled()
        devices = bluetooth_paired_devices()
        parts = [f"Bluetooth: {'ON' if enabled else 'OFF'}"]
        if devices:
            parts.append(f"Paired: {len(devices)} devices")
        return ToolResult.ok(data={"enabled": enabled, "devices": devices}, message=" | ".join(parts))


class VolumeTool(Tool):
    name = "set_volume"
    description = "Set volume for a stream: music, ring, alarm, notification, system."
    parameters = {"stream": "music, ring, alarm, notification, or system", "level": "volume level (0-15)"}
    destructive = False
    def available(self): return _check()
    def execute(self, parameters):
        from phone.settings import sound_set_volume
        stream = str(parameters.get("stream", "music")).strip()
        try:
            level = int(parameters.get("level", 8))
        except (ValueError, TypeError):
            return ToolResult.fail(error="invalid", message="level must be a number")
        ok, msg = sound_set_volume(stream, level)
        return ToolResult.ok(message=msg) if ok else ToolResult.fail(error="failed", message=msg)


class GetVolumeTool(Tool):
    name = "get_volume"
    description = "Get volume levels for all streams."
    parameters = {}
    destructive = False
    def available(self): return _check()
    def execute(self, parameters):
        from phone.settings import sound_get_volume
        streams = ["music", "ring", "alarm", "notification", "system"]
        volumes = {s: sound_get_volume(s) for s in streams}
        parts = [f"{s}={v}" for s, v in volumes.items() if v is not None]
        return ToolResult.ok(data=volumes, message="Volume: " + ", ".join(parts))


class MuteTool(Tool):
    name = "mute"
    description = "Mute a specific audio stream."
    parameters = {"stream": "music, ring, alarm, notification, or system"}
    destructive = False
    def available(self): return _check()
    def execute(self, parameters):
        from phone.settings import sound_mute
        stream = str(parameters.get("stream", "music")).strip()
        ok, msg = sound_mute(stream)
        return ToolResult.ok(message=msg) if ok else ToolResult.fail(error="failed", message=msg)


class RingerModeTool(Tool):
    name = "set_ringer_mode"
    description = "Set ringer mode: silent, vibrate, or normal."
    parameters = {"mode": "silent, vibrate, or normal"}
    destructive = False
    def available(self): return _check()
    def execute(self, parameters):
        from phone.settings import sound_set_ringer_mode, sound_get_ringer_mode
        mode = str(parameters.get("mode", "normal")).strip()
        if not mode:
            current = sound_get_ringer_mode()
            return ToolResult.ok(message=f"Current ringer mode: {current}")
        ok, msg = sound_set_ringer_mode(mode)
        return ToolResult.ok(message=msg) if ok else ToolResult.fail(error="failed", message=msg)


class BrightnessTool(Tool):
    name = "set_brightness"
    description = "Set screen brightness (0=dark, 255=max)."
    parameters = {"level": "brightness 0-255"}
    destructive = False
    def available(self): return _check()
    def execute(self, parameters):
        from phone.settings import display_set_brightness
        try:
            level = int(parameters.get("level", 128))
        except (ValueError, TypeError):
            return ToolResult.fail(error="invalid", message="level must be a number")
        ok, msg = display_set_brightness(level)
        return ToolResult.ok(message=msg) if ok else ToolResult.fail(error="failed", message=msg)


class AutoBrightnessTool(Tool):
    name = "auto_brightness"
    description = "Enable or disable auto-brightness."
    parameters = {"enabled": "true to enable, false to disable"}
    destructive = False
    def available(self): return _check()
    def execute(self, parameters):
        from phone.settings import display_auto_brightness
        enabled = str(parameters.get("enabled", "")).lower() in ("true", "1", "on", "yes")
        ok, msg = display_auto_brightness(enabled)
        return ToolResult.ok(message=msg) if ok else ToolResult.fail(error="failed", message=msg)


class ScreenTimeoutTool(Tool):
    name = "screen_timeout"
    description = "Set screen timeout (how long screen stays on)."
    parameters = {"seconds": "timeout in seconds (e.g. 15, 30, 60, 300)"}
    destructive = False
    def available(self): return _check()
    def execute(self, parameters):
        from phone.settings import display_set_timeout
        try:
            seconds = int(parameters.get("seconds", 30))
        except (ValueError, TypeError):
            return ToolResult.fail(error="invalid", message="seconds must be a number")
        ok, msg = display_set_timeout(seconds * 1000)
        return ToolResult.ok(message=msg) if ok else ToolResult.fail(error="failed", message=msg)


class DarkModeTool(Tool):
    name = "dark_mode"
    description = "Enable or disable dark mode."
    parameters = {"enabled": "true to enable dark mode, false for light mode"}
    destructive = False
    def available(self): return _check()
    def execute(self, parameters):
        from phone.settings import display_dark_mode
        enabled = str(parameters.get("enabled", "")).lower() in ("true", "1", "on", "yes")
        ok, msg = display_dark_mode(enabled)
        return ToolResult.ok(message=msg) if ok else ToolResult.fail(error="failed", message=msg)


class GetDarkModeTool(Tool):
    name = "get_dark_mode"
    description = "Check if dark mode is currently enabled."
    parameters = {}
    destructive = False
    def available(self): return _check()
    def execute(self, parameters):
        from phone.settings import display_get_dark_mode
        enabled = display_get_dark_mode()
        return ToolResult.ok(data={"dark_mode": enabled}, message=f"Dark mode: {'ON' if enabled else 'OFF'}")


class FontScaleTool(Tool):
    name = "font_scale"
    description = "Set font size: small (0.85), normal (1.0), large (1.15), largest (1.3)."
    parameters = {"scale": "0.85=small, 1.0=normal, 1.15=large, 1.3=largest"}
    destructive = False
    def available(self): return _check()
    def execute(self, parameters):
        from phone.settings import display_set_font_scale
        try:
            scale = float(parameters.get("scale", 1.0))
        except (ValueError, TypeError):
            return ToolResult.fail(error="invalid", message="scale must be a number")
        ok, msg = display_set_font_scale(scale)
        return ToolResult.ok(message=msg) if ok else ToolResult.fail(error="failed", message=msg)


class ScreenOrientationTool(Tool):
    name = "screen_orientation"
    description = "Set screen orientation: portrait, landscape, or auto."
    parameters = {"mode": "portrait, landscape, or auto"}
    destructive = False
    def available(self): return _check()
    def execute(self, parameters):
        from phone.settings import display_set_orientation
        mode = str(parameters.get("mode", "auto")).strip()
        ok, msg = display_set_orientation(mode)
        return ToolResult.ok(message=msg) if ok else ToolResult.fail(error="failed", message=msg)


class AirplaneModeTool(Tool):
    name = "airplane_mode"
    description = "Enable or disable airplane mode."
    parameters = {"enabled": "true to enable, false to disable"}
    destructive = True
    def available(self): return _check()
    def execute(self, parameters):
        from phone.settings import airplane_mode
        enabled = str(parameters.get("enabled", "")).lower() in ("true", "1", "on", "yes")
        ok, msg = airplane_mode(enabled)
        return ToolResult.ok(message=msg) if ok else ToolResult.fail(error="failed", message=msg)


class MobileDataTool(Tool):
    name = "mobile_data"
    description = "Enable or disable mobile data."
    parameters = {"enabled": "true to enable, false to disable"}
    destructive = True
    def available(self): return _check()
    def execute(self, parameters):
        from phone.settings import mobile_data_set_enabled
        enabled = str(parameters.get("enabled", "")).lower() in ("true", "1", "on", "yes")
        ok, msg = mobile_data_set_enabled(enabled)
        return ToolResult.ok(message=msg) if ok else ToolResult.fail(error="failed", message=msg)


class LocationToggleTool(Tool):
    name = "location_toggle"
    description = "Enable or disable location/GPS."
    parameters = {"enabled": "true to enable, false to disable"}
    destructive = True
    def available(self): return _check()
    def execute(self, parameters):
        from phone.settings import location_set_enabled
        enabled = str(parameters.get("enabled", "")).lower() in ("true", "1", "on", "yes")
        ok, msg = location_set_enabled(enabled)
        return ToolResult.ok(message=msg) if ok else ToolResult.fail(error="failed", message=msg)


class HotspotTool(Tool):
    name = "hotspot_toggle"
    description = "Enable or disable WiFi hotspot."
    parameters = {"enabled": "true to enable, false to disable"}
    destructive = True
    def available(self): return _check()
    def execute(self, parameters):
        from phone.settings import hotspot_set_enabled
        enabled = str(parameters.get("enabled", "")).lower() in ("true", "1", "on", "yes")
        ok, msg = hotspot_set_enabled(enabled)
        return ToolResult.ok(message=msg) if ok else ToolResult.fail(error="failed", message=msg)


class BatterySaverTool(Tool):
    name = "battery_saver"
    description = "Enable or disable battery saver mode."
    parameters = {"enabled": "true to enable, false to disable"}
    destructive = False
    def available(self): return _check()
    def execute(self, parameters):
        from phone.settings import battery_saver
        enabled = str(parameters.get("enabled", "")).lower() in ("true", "1", "on", "yes")
        ok, msg = battery_saver(enabled)
        return ToolResult.ok(message=msg) if ok else ToolResult.fail(error="failed", message=msg)


class DndTool(Tool):
    name = "do_not_disturb"
    description = "Enable or disable Do Not Disturb mode."
    parameters = {"enabled": "true to enable, false to disable"}
    destructive = False
    def available(self): return _check()
    def execute(self, parameters):
        from phone.settings import dnd_set_enabled
        enabled = str(parameters.get("enabled", "")).lower() in ("true", "1", "on", "yes")
        ok, msg = dnd_set_enabled(enabled)
        return ToolResult.ok(message=msg) if ok else ToolResult.fail(error="failed", message=msg)


class PhoneStatusTool(Tool):
    name = "phone_status"
    description = "Get comprehensive phone status: all settings, battery, connectivity."
    parameters = {"section": "optional: wifi, bluetooth, sound, display, battery, network, or all (default: all)"}
    destructive = False
    def available(self): return _check()
    def execute(self, parameters):
        from phone.settings import get_all_settings
        settings = get_all_settings()
        # Build a readable summary
        parts = []
        parts.append(f"WiFi: {'ON' if settings.get('wifi') else 'OFF'}")
        if settings.get('wifi_connected'):
            parts.append(f"Connected: {settings['wifi_connected'].get('ssid', '?')}")
        parts.append(f"Bluetooth: {'ON' if settings.get('bluetooth') else 'OFF'}")
        parts.append(f"Mobile Data: {'ON' if settings.get('mobile_data') else 'OFF'}")
        parts.append(f"Airplane: {'ON' if settings.get('airplane_mode') else 'OFF'}")
        parts.append(f"Location: {'ON' if settings.get('location') else 'OFF'}")
        parts.append(f"NFC: {'ON' if settings.get('nfc') else 'OFF'}")
        parts.append(f"Dark Mode: {'ON' if settings.get('dark_mode') else 'OFF'}")
        parts.append(f"Brightness: {settings.get('brightness', '?')}/255")
        parts.append(f"Battery: {settings.get('battery', '?')}%")
        parts.append(f"Ringer: {settings.get('ringer_mode', '?')}")
        vol = settings.get('volume_music')
        if vol is not None:
            parts.append(f"Volume: {vol}/15")
        return ToolResult.ok(data=settings, message=" | ".join(parts))


class NotificationTool(Tool):
    name = "post_notification"
    description = "Post a notification on the phone."
    parameters = {"title": "notification title", "content": "notification content"}
    destructive = False
    def available(self): return _check()
    def execute(self, parameters):
        from phone.settings import post_notification
        title = str(parameters.get("title", "Zerion")).strip()
        content = str(parameters.get("content", "")).strip()
        if not content:
            return ToolResult.fail(error="missing", message="Provide notification content.")
        ok, msg = post_notification(title, content)
        return ToolResult.ok(message=msg) if ok else ToolResult.fail(error="failed", message=msg)


class LaunchAppTool(Tool):
    name = "open_app"
    description = "Open an Android app by name or package."
    parameters = {"package": "app name or package (e.g. 'chrome' or 'com.android.chrome')"}
    destructive = False
    def available(self): return _check()
    def execute(self, parameters):
        from phone.settings import launch_app, search_apps
        target = str(parameters.get("package", "")).strip()
        if not target:
            return ToolResult.fail(error="missing", message="Provide an app name or package.")
        if "." in target:
            ok, msg = launch_app(target)
            return ToolResult.ok(message=msg) if ok else ToolResult.fail(error="failed", message=msg)
        apps = search_apps(target)
        if not apps:
            return ToolResult.fail(error="not_found", message=f"No app matching '{target}'")
        ok, msg = launch_app(apps[0])
        return ToolResult.ok(data={"package": apps[0]}, message=f"Opened {apps[0]}") if ok else ToolResult.fail(error="failed", message=msg)


class StopAppTool(Tool):
    name = "stop_app"
    description = "Force stop a running app."
    parameters = {"package": "package name to stop"}
    destructive = True
    def available(self): return _check()
    def execute(self, parameters):
        from phone.settings import stop_app
        pkg = str(parameters.get("package", "")).strip()
        if not pkg:
            return ToolResult.fail(error="missing", message="Provide a package name.")
        ok, msg = stop_app(pkg)
        return ToolResult.ok(message=msg) if ok else ToolResult.fail(error="failed", message=msg)


class TapScreenTool(Tool):
    name = "tap_screen"
    description = "Tap at screen coordinates."
    parameters = {"x": "horizontal coordinate", "y": "vertical coordinate"}
    destructive = False
    def available(self): return _check()
    def execute(self, parameters):
        from phone.settings import tap
        try:
            x = int(parameters.get("x", 0))
            y = int(parameters.get("y", 0))
        except (ValueError, TypeError):
            return ToolResult.fail(error="invalid", message="x and y must be integers")
        ok, msg = tap(x, y)
        return ToolResult.ok(message=f"Tapped ({x},{y})") if ok else ToolResult.fail(error="failed", message=msg)


class PressKeyTool(Tool):
    name = "press_key"
    description = "Press a key: home, back, enter, power, volume_up, volume_down, app_switch."
    parameters = {"key": "key name"}
    destructive = False
    def available(self): return _check()
    def execute(self, parameters):
        from phone.settings import press_key
        key = str(parameters.get("key", "home")).strip()
        ok, msg = press_key(key)
        return ToolResult.ok(message=f"Pressed {key}") if ok else ToolResult.fail(error="failed", message=msg)


class TypeTextTool(Tool):
    name = "type_on_phone"
    description = "Type text into the currently focused input field on the phone."
    parameters = {"text": "text to type"}
    destructive = False
    def available(self): return _check()
    def execute(self, parameters):
        from phone.settings import type_text
        text = str(parameters.get("text", "")).strip()
        if not text:
            return ToolResult.fail(error="missing", message="Provide text to type.")
        ok, msg = type_text(text)
        return ToolResult.ok(message=f"Typed: {text}") if ok else ToolResult.fail(error="failed", message=msg)


class SwipeScreenTool(Tool):
    name = "swipe_screen"
    description = "Swipe on the phone screen."
    parameters = {"x1": "start x", "y1": "start y", "x2": "end x", "y2": "end y"}
    destructive = False
    def available(self): return _check()
    def execute(self, parameters):
        from phone.settings import swipe
        try:
            x1, y1 = int(parameters.get("x1", 0)), int(parameters.get("y1", 0))
            x2, y2 = int(parameters.get("x2", 0)), int(parameters.get("y2", 0))
        except (ValueError, TypeError):
            return ToolResult.fail(error="invalid", message="Coordinates must be integers")
        ok, msg = swipe(x1, y1, x2, y2)
        return ToolResult.ok(message=f"Swiped ({x1},{y1})→({x2},{y2})") if ok else ToolResult.fail(error="failed", message=msg)


class ScreenshotTool(Tool):
    name = "take_screenshot"
    description = "Take a screenshot of the phone screen."
    parameters = {"path": "save path (default /sdcard/screenshot.png)"}
    destructive = False
    def available(self): return _check()
    def execute(self, parameters):
        from phone.settings import screenshot
        path = str(parameters.get("path", "/sdcard/screenshot.png")).strip()
        ok, msg = screenshot(path)
        return ToolResult.ok(data=path, message=f"Screenshot saved: {path}") if ok else ToolResult.fail(error="failed", message=msg)


class BatteryTool(Tool):
    name = "battery_info"
    description = "Get detailed battery info: level, status, temperature, charging state."
    parameters = {}
    destructive = False
    def available(self): return _check()
    def execute(self, parameters):
        from phone.settings import battery_info
        info = battery_info()
        msg = f"Battery: {info.get('level', '?')}% | {info.get('status_text', '?')} | {info.get('plugged_text', '?')}"
        if 'temperature_c' in info:
            msg += f" | {info['temperature_c']}°C"
        return ToolResult.ok(data=info, message=msg)


class ClipboardTool(Tool):
    name = "phone_clipboard"
    description = "Read or write the phone clipboard."
    parameters = {"mode": "read or write", "text": "text to write (required if mode=write)"}
    destructive = False
    def available(self): return _check()
    def execute(self, parameters):
        from phone.settings import clipboard_get, clipboard_set
        mode = str(parameters.get("mode", "read")).strip().lower()
        if mode == "read":
            text = clipboard_get()
            return ToolResult.ok(data=text, message=f"Clipboard: {text or '(empty)'}")
        elif mode == "write":
            text = str(parameters.get("text", "")).strip()
            if not text:
                return ToolResult.fail(error="missing", message="Provide text to write.")
            ok, msg = clipboard_set(text)
            return ToolResult.ok(message=f"Clipboard set: {text[:50]}") if ok else ToolResult.fail(error="failed", message=msg)
        return ToolResult.fail(error="invalid", message="mode must be 'read' or 'write'")


class ListAppsTool(Tool):
    name = "list_installed_apps"
    description = "List all installed apps on the phone."
    parameters = {"query": "optional search filter"}
    destructive = False
    def available(self): return _check()
    def execute(self, parameters):
        from phone.settings import list_apps, search_apps
        query = str(parameters.get("query", "")).strip()
        if query:
            apps = search_apps(query)
            msg = f"Found {len(apps)} apps matching '{query}':\n" + "\n".join(f"  {a}" for a in apps[:20])
        else:
            apps = list_apps()
            msg = f"Found {len(apps)} installed apps"
        return ToolResult.ok(data=apps[:50], message=msg)


class GetCurrentAppTool(Tool):
    name = "current_app"
    description = "Get the currently active/foreground app."
    parameters = {}
    destructive = False
    def available(self): return _check()
    def execute(self, parameters):
        from phone.settings import get_foreground_app
        app = get_foreground_app()
        return ToolResult.ok(data=app, message=f"Foreground: {app or 'unknown'}")


class PhoneShellTool(Tool):
    name = "phone_shell"
    description = "Run any shell command on the phone."
    parameters = {"command": "shell command to run", "timeout": "timeout seconds (default 15)"}
    destructive = True
    def available(self): return _check()
    def execute(self, parameters):
        from phone.settings import shell
        cmd = str(parameters.get("command", "")).strip()
        if not cmd:
            return ToolResult.fail(error="missing", message="Provide a command.")
        try:
            timeout = int(parameters.get("timeout", 15))
        except (ValueError, TypeError):
            timeout = 15
        ok, out = shell(cmd, timeout=min(timeout, 30))
        return ToolResult.ok(data=out, message=out[:600]) if ok else ToolResult.fail(error="failed", message=out[:600])
