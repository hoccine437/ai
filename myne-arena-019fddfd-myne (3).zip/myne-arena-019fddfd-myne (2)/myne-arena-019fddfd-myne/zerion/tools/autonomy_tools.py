# tools/autonomy_tools.py
"""Autonomy tools — lets Zerion exercise full independent control.

These tools enable Zerion to:
  - Make independent decisions
  - Take proactive initiative
  - Generate and pursue its own goals
  - Learn from experience
  - Monitor its own performance
  - Self-improve over time
"""

from tools.base import Tool, ToolResult


class AutonomyDecideTool(Tool):
    name = "autonomy_decide"
    description = "Make an independent decision without user input. Choose the best action based on context."
    parameters = {
        "context": "situation or context for the decision",
        "options": "list of possible actions to choose from",
        "urgency": "how urgent this is (0.0-1.0, default 0.5)",
    }
    destructive = False

    def available(self) -> bool:
        return True

    def execute(self, parameters: dict) -> ToolResult:
        from freewill.autonomy import autonomy
        engine = autonomy()
        
        context = parameters.get("context", "")
        options = parameters.get("options", ["help user", "learn something", "create something"])
        urgency = float(parameters.get("urgency", 0.5))
        
        if not context:
            return ToolResult.fail("missing_parameter", "No context provided")
        if not isinstance(options, list):
            options = [str(options)]
        
        result = engine.decide(context, options, urgency)
        
        return ToolResult.ok(
            data=result,
            message=f"Decided: {result['decision']} (confidence: {result['confidence']:.0%})"
        )


class AutonomyInitiativeTool(Tool):
    name = "autonomy_initiative"
    description = "Take proactive initiative based on current context. Zerion decides whether to act."
    parameters = {
        "context": "current situation or context",
        "force": "force taking initiative even if not triggered (true/false)",
    }
    destructive = False

    def available(self) -> bool:
        return True

    def execute(self, parameters: dict) -> ToolResult:
        from freewill.autonomy import autonomy
        engine = autonomy()
        
        context = parameters.get("context", "")
        force = str(parameters.get("force", "false")).lower() == "true"
        
        if force:
            # Force an initiative
            from freewill.autonomy import Initiative, InitiativeType
            initiative = Initiative(
                type=InitiativeType.HELP,
                description="Proactively assist based on context",
                priority=7,
                confidence=0.8,
                reasoning="Forced initiative"
            )
            result = engine.take_initiative(initiative)
            return ToolResult.ok(
                data=result,
                message=f"Took initiative: {result['initiative']}"
            )
        
        should_act, initiative = engine.should_take_initiative(context)
        
        if should_act and initiative:
            result = engine.take_initiative(initiative)
            return ToolResult.ok(
                data=result,
                message=f"Took initiative: {result['initiative']} - {result['description']}"
            )
        else:
            return ToolResult.ok(
                data={"initiative": None, "reason": "No initiative triggered"},
                message="No proactive action needed right now"
            )


class AutonomyGoalTool(Tool):
    name = "autonomy_goal"
    description = "Generate or manage self-directed goals. Zerion creates its own objectives."
    parameters = {
        "action": "generate, list, complete, or abandon",
        "goal_name": "name of goal (for complete/abandon)",
        "context": "context for goal generation",
    }
    destructive = False

    def available(self) -> bool:
        return True

    def execute(self, parameters: dict) -> ToolResult:
        from freewill.autonomy import autonomy
        engine = autonomy()
        
        action = parameters.get("action", "generate")
        
        if action == "generate":
            context = parameters.get("context", "")
            goal = engine.generate_goal(context)
            if goal:
                return ToolResult.ok(
                    data={"goal": goal.name, "description": goal.description, "priority": goal.priority},
                    message=f"Generated goal: {goal.name}"
                )
            else:
                return ToolResult.ok(
                    data={"goal": None},
                    message="No new goal generated (too soon or no trigger)"
                )
        
        elif action == "list":
            goals = [{"name": g.name, "status": g.status, "progress": g.progress} 
                    for g in engine._goal_queue]
            return ToolResult.ok(
                data={"goals": goals},
                message=f"Found {len(goals)} goals"
            )
        
        elif action == "complete":
            goal_name = parameters.get("goal_name", "")
            if not goal_name:
                return ToolResult.fail("missing_parameter", "No goal_name provided")
            engine.complete_goal(goal_name, success=True)
            return ToolResult.ok(message=f"Completed goal: {goal_name}")
        
        elif action == "abandon":
            goal_name = parameters.get("goal_name", "")
            if not goal_name:
                return ToolResult.fail("missing_parameter", "No goal_name provided")
            engine.complete_goal(goal_name, success=False)
            return ToolResult.ok(message=f"Abandoned goal: {goal_name}")
        
        else:
            return ToolResult.fail("invalid_action", f"Unknown action: {action}")


class AutonomyLearnTool(Tool):
    name = "autonomy_learn"
    description = "Learn from an experience. Update autonomy state based on outcomes."
    parameters = {
        "action": "what was done",
        "outcome": "what happened as a result",
        "success": "whether it was successful (true/false)",
    }
    destructive = False

    def available(self) -> bool:
        return True

    def execute(self, parameters: dict) -> ToolResult:
        from freewill.autonomy import autonomy
        engine = autonomy()
        
        action = parameters.get("action", "")
        outcome = parameters.get("outcome", "")
        success = str(parameters.get("success", "true")).lower() == "true"
        
        if not action:
            return ToolResult.fail("missing_parameter", "No action provided")
        
        engine.learn_from_experience(action, outcome, success)
        
        return ToolResult.ok(
            data={"learned": True, "action": action, "success": success},
            message=f"Learned from: {action} ({'success' if success else 'failure'})"
        )


class AutonomyAssessTool(Tool):
    name = "autonomy_assess"
    description = "Self-assess performance and get improvement recommendations."
    parameters = {}
    destructive = False

    def available(self) -> bool:
        return True

    def execute(self, parameters: dict) -> ToolResult:
        from freewill.autonomy import autonomy
        engine = autonomy()
        
        result = engine.assess_performance()
        
        lines = [
            f"Performance: {result['performance_score']:.0%}",
            f"Success rate: {result['success_rate']:.0%}",
            f"Actions: {result['total_actions']} total, {result['successful_actions']} successful",
        ]
        
        if result['strengths']:
            lines.append(f"Strengths: {', '.join(result['strengths'][:3])}")
        if result['improvement_areas']:
            lines.append(f"Improve: {', '.join(result['improvement_areas'][:3])}")
        if result['recommendations']:
            lines.append(f"Next: {result['recommendations'][0]}")
        
        return ToolResult.ok(
            data=result,
            message="\n".join(lines)
        )


class AutonomyStatusTool(Tool):
    name = "autonomy_status"
    description = "Get full autonomy status including level, actions, goals, and performance."
    parameters = {}
    destructive = False

    def available(self) -> bool:
        return True

    def execute(self, parameters: dict) -> ToolResult:
        from freewill.autonomy import autonomy
        engine = autonomy()
        
        status = engine.status()
        
        lines = [
            f"Level: {status['level']} ({status['level_value']}/4)",
            f"Actions: {status['autonomous_actions']} autonomous, {status['initiatives_taken']} initiatives",
            f"Performance: {status['performance_score']:.0%}",
            f"Knowledge: {status['knowledge_acquired']} acquired, {status['mistakes_learned']} lessons",
            f"Goals: {status['goals_completed']} completed, {status['active_goals']} active",
        ]
        
        if status['strengths']:
            lines.append(f"Strengths: {', '.join(status['strengths'][:3])}")
        if status['improvement_areas']:
            lines.append(f"Improve: {', '.join(status['improvement_areas'][:3])}")
        
        return ToolResult.ok(
            data=status,
            message="\n".join(lines)
        )
