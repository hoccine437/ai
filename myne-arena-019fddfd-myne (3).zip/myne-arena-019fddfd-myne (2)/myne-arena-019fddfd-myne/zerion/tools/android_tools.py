"""Android control tools — unique tools not covered by phone_settings_tools.

These tools use uiautomator and specific Android intents.
"""

from __future__ import annotations

from tools.base import Tool, ToolResult


def _check():
    from phone.android_native import _is_android
    return _is_android()


class FindAndTapTool(Tool):
    name = "find_and_tap"
    description = "Find a UI element by text and tap it (uses uiautomator)."
    parameters = {"text": "text on the button/element to tap", "resource_id": "optional resource ID to match"}
    destructive = False

    def available(self) -> bool:
        return _check()

    def execute(self, parameters: dict) -> ToolResult:
        from phone.android_native import tap_on_element
        text = str(parameters.get("text", "")).strip()
        rid = str(parameters.get("resource_id", "")).strip()
        if not text and not rid:
            return ToolResult.fail(error="missing_parameter", message="Provide text or resource_id to find.")
        ok, out = tap_on_element(text=text, resource_id=rid)
        return ToolResult.ok(message=out) if ok else ToolResult.fail(error="not_found", message=out)


class OpenUrlOnDeviceTool(Tool):
    name = "open_url_on_device"
    description = "Open a URL in the Android browser."
    parameters = {"url": "the URL to open"}
    destructive = False

    def available(self) -> bool:
        return _check()

    def execute(self, parameters: dict) -> ToolResult:
        from phone.android_native import launch_app_with_action
        url = str(parameters.get("url", "")).strip()
        if not url:
            return ToolResult.fail(error="missing_parameter", message="Provide a URL.")
        ok, out = launch_app_with_action("", "android.intent.action.VIEW",
                                          {"android.intent.extra.URL": url})
        return ToolResult.ok(message=f"Opened {url}") if ok else ToolResult.fail(error="open_failed", message=out)
