# tools/agent_tools.py
"""Agent delegation tools — lets Zerion spawn any of the 21 specialist agents.

Each tool maps to an agent category. Zerion can:
  - Spawn a single agent: agent_spawn(type, task)
  - Spawn multiple agents: agent_delegate(assignments)
  - Check agent status: agent_status()
  - Query agent types: agent_list_types(category?)
  - Get agent results: agent_collect(ids)
"""

from agents.engine import engine
from agents.types import AGENT_TYPES, all_categories
from tools.base import Tool, ToolResult


# ---------------------------------------------------------------------------
# Core agent spawn tool
# ---------------------------------------------------------------------------

class AgentSpawnTool(Tool):
    name = "agent_spawn"
    description = (
        "Spawn a specialist agent to handle a subtask. Agent types: "
        + ", ".join(sorted(AGENT_TYPES.keys()))
        + ". Task is either {'tool': name, 'parameters': {...}} for tool calls "
        "or {'query': text} for memory search."
    )
    parameters = {
        "agent_type": "agent type name (e.g. core_reasoning, planning, coding)",
        "task": "task dict: {'tool': name, 'parameters': {...}} or {'query': text}",
    }
    destructive = False

    def available(self) -> bool:
        return True

    def execute(self, parameters: dict) -> ToolResult:
        agent_type = str((parameters or {}).get("agent_type", "")).strip().lower()
        task = (parameters or {}).get("task", {})
        if not agent_type:
            return ToolResult.fail("missing_parameter", "No agent_type provided.")
        if agent_type not in AGENT_TYPES:
            return ToolResult.fail(
                "unknown_type",
                f"Unknown agent type: {agent_type}. Available: {', '.join(sorted(AGENT_TYPES.keys()))}"
            )
        if not task:
            return ToolResult.fail("missing_parameter", "No task provided.")
        result = engine.spawn(agent_type, task, wait=True)
        if not result.get("ok"):
            return ToolResult.fail(
                result.get("error", "spawn_failed"),
                result.get("message", "Agent spawn failed.")
            )
        agent = result.get("agent", {})
        status = agent.get("status", "unknown")
        res = agent.get("result", {})
        msg = f"Agent {agent_type} ({agent.get('id', '?')}): {status}"
        if res:
            msg += f"\nResult: {res.get('message', str(res))}"
        return ToolResult.ok(data=result, message=msg)


# ---------------------------------------------------------------------------
# Multi-agent delegate tool
# ---------------------------------------------------------------------------

class AgentDelegateTool(Tool):
    name = "agent_delegate"
    description = (
        "Delegate one bounded subtask to a specialized agent instance. "
        "Types: " + ", ".join(sorted(AGENT_TYPES.keys())) + ". "
        "Subtasks are either {'tool': whitelisted_tool, 'parameters': {...}} "
        "or {'query': text} for memory-capable agents."
    )
    parameters = {
        "agent_type": "agent type name",
        "task": "task dict with 'tool' or 'query' key",
    }
    destructive = False

    def available(self) -> bool:
        return True

    def execute(self, parameters: dict) -> ToolResult:
        agent_type = str((parameters or {}).get("agent_type", "")).strip().lower()
        task = (parameters or {}).get("task", {})
        if not agent_type or not task:
            return ToolResult.fail("missing_parameter", "agent_type and task required.")
        result = engine.spawn(agent_type, task, wait=True)
        if not result.get("ok"):
            return ToolResult.fail(
                result.get("error", "delegate_failed"),
                result.get("message", "Delegation failed.")
            )
        agent = result.get("agent", {})
        res = agent.get("result", {})
        return ToolResult.ok(
            data=result,
            message=f"Delegated to {agent_type}: {res.get('message', str(res))}"
        )


# ---------------------------------------------------------------------------
# Agent status tool
# ---------------------------------------------------------------------------

class AgentStatusTool(Tool):
    name = "agent_status"
    description = "Report live agent instances, capacity, and recent outcomes."
    parameters = {}
    destructive = False

    def available(self) -> bool:
        return True

    def execute(self, parameters: dict) -> ToolResult:
        stats = engine.stats()
        types_count = len(engine._types)
        lines = [
            f"Pool: {stats['capacity']} capacity, {stats['inflight']} running, {stats['tracked']} tracked",
            f"Types registered: {types_count}",
            f"Max pending: {stats['max_pending']}",
        ]
        by_type = stats.get("by_type", {})
        if by_type:
            lines.append("By type:")
            for tname, counts in sorted(by_type.items()):
                parts = ", ".join(f"{s}:{n}" for s, n in sorted(counts.items()))
                lines.append(f"  {tname}: {parts}")
        return ToolResult.ok(data=stats, message="\n".join(lines))


# ---------------------------------------------------------------------------
# Agent list types tool
# ---------------------------------------------------------------------------

class AgentListTypesTool(Tool):
    name = "agent_list_types"
    description = "List all registered agent types with their categories and capabilities."
    parameters = {"category": "optional category filter: cognition, knowledge, quality, execution, phone, business, evolution, observation"}
    destructive = False

    def available(self) -> bool:
        return True

    def execute(self, parameters: dict) -> ToolResult:
        category = str((parameters or {}).get("category", "")).strip().lower()
        types_list = engine.list_types()
        if category:
            types_list = [t for t in types_list if t.get("category") == category or
                          AGENT_TYPES.get(t["name"], None) and AGENT_TYPES[t["name"]].category == category]
        if not types_list:
            cats = all_categories()
            lines = [f"Categories: {', '.join(cats.keys())}"]
            for cat, names in sorted(cats.items()):
                lines.append(f"  {cat}: {', '.join(names)}")
            return ToolResult.ok(data={"categories": cats}, message="\n".join(lines))
        lines = []
        for t in types_list:
            name = t["name"]
            at = AGENT_TYPES.get(name)
            cat = at.category if at else "?"
            lines.append(f"[{cat}] {name}: {t['description'][:80]}")
        return ToolResult.ok(data=types_list, message="\n".join(lines))


# ---------------------------------------------------------------------------
# Categorized spawn shortcuts
# ---------------------------------------------------------------------------

class CognitionAgentTool(Tool):
    name = "agent_cognition"
    description = "Spawn a cognition agent: core_reasoning, planning, decision, prediction, problem_solving"
    parameters = {
        "type": "cognition type: core_reasoning, planning, decision, prediction, problem_solving",
        "task": "task dict: {'tool': name, 'parameters': {...}} or {'query': text}",
    }
    destructive = False

    def available(self) -> bool:
        return True

    def execute(self, parameters: dict) -> ToolResult:
        agent_type = str((parameters or {}).get("type", "core_reasoning")).strip().lower()
        task = (parameters or {}).get("task", {"query": "analyze"})
        valid = ["core_reasoning", "planning", "decision", "prediction", "problem_solving"]
        if agent_type not in valid:
            return ToolResult.fail("invalid_type", f"Valid: {', '.join(valid)}")
        result = engine.spawn(agent_type, task, wait=True)
        if not result.get("ok"):
            return ToolResult.fail(result.get("error"), result.get("message"))
        agent = result.get("agent", {})
        res = agent.get("result", {})
        return ToolResult.ok(data=result, message=f"{agent_type}: {res.get('message', '')}")


class KnowledgeAgentTool(Tool):
    name = "agent_knowledge"
    description = "Spawn a knowledge agent: research, memory, learning, knowledge"
    parameters = {
        "type": "knowledge type: research, memory, learning, knowledge",
        "task": "task dict: {'tool': name, 'parameters': {...}} or {'query': text}",
    }
    destructive = False

    def available(self) -> bool:
        return True

    def execute(self, parameters: dict) -> ToolResult:
        agent_type = str((parameters or {}).get("type", "research")).strip().lower()
        task = (parameters or {}).get("task", {"query": "research"})
        valid = ["research", "memory", "learning", "knowledge"]
        if agent_type not in valid:
            return ToolResult.fail("invalid_type", f"Valid: {', '.join(valid)}")
        result = engine.spawn(agent_type, task, wait=True)
        if not result.get("ok"):
            return ToolResult.fail(result.get("error"), result.get("message"))
        agent = result.get("agent", {})
        res = agent.get("result", {})
        return ToolResult.ok(data=result, message=f"{agent_type}: {res.get('message', '')}")


class QualityAgentTool(Tool):
    name = "agent_quality"
    description = "Spawn a quality agent: self_critic, security, verifier"
    parameters = {
        "type": "quality type: self_critic, security, verifier",
        "task": "task dict: {'tool': name, 'parameters': {...}} or {'query': text}",
    }
    destructive = False

    def available(self) -> bool:
        return True

    def execute(self, parameters: dict) -> ToolResult:
        agent_type = str((parameters or {}).get("type", "self_critic")).strip().lower()
        task = (parameters or {}).get("task", {"query": "review"})
        valid = ["self_critic", "security", "verifier"]
        if agent_type not in valid:
            return ToolResult.fail("invalid_type", f"Valid: {', '.join(valid)}")
        result = engine.spawn(agent_type, task, wait=True)
        if not result.get("ok"):
            return ToolResult.fail(result.get("error"), result.get("message"))
        agent = result.get("agent", {})
        res = agent.get("result", {})
        return ToolResult.ok(data=result, message=f"{agent_type}: {res.get('message', '')}")


class PhoneAgentTool(Tool):
    name = "agent_phone"
    description = "Spawn a phone agent: vision, voice, controller"
    parameters = {
        "type": "phone type: vision, voice, controller",
        "task": "task dict: {'tool': name, 'parameters': {...}} or {'query': text}",
    }
    destructive = False

    def available(self) -> bool:
        return True

    def execute(self, parameters: dict) -> ToolResult:
        agent_type = str((parameters or {}).get("type", "vision")).strip().lower()
        task = (parameters or {}).get("task", {"query": "check device"})
        valid = ["vision", "voice", "controller"]
        if agent_type not in valid:
            return ToolResult.fail("invalid_type", f"Valid: {', '.join(valid)}")
        result = engine.spawn(agent_type, task, wait=True)
        if not result.get("ok"):
            return ToolResult.fail(result.get("error"), result.get("message"))
        agent = result.get("agent", {})
        res = agent.get("result", {})
        return ToolResult.ok(data=result, message=f"{agent_type}: {res.get('message', '')}")


class BusinessAgentTool(Tool):
    name = "agent_business"
    description = "Spawn a business agent: finance, communicator, creative"
    parameters = {
        "type": "business type: finance, communicator, creative",
        "task": "task dict: {'tool': name, 'parameters': {...}} or {'query': text}",
    }
    destructive = False

    def available(self) -> bool:
        return True

    def execute(self, parameters: dict) -> ToolResult:
        agent_type = str((parameters or {}).get("type", "finance")).strip().lower()
        task = (parameters or {}).get("task", {"query": "analyze"})
        valid = ["finance", "communicator", "creative"]
        if agent_type not in valid:
            return ToolResult.fail("invalid_type", f"Valid: {', '.join(valid)}")
        result = engine.spawn(agent_type, task, wait=True)
        if not result.get("ok"):
            return ToolResult.fail(result.get("error"), result.get("message"))
        agent = result.get("agent", {})
        res = agent.get("result", {})
        return ToolResult.ok(data=result, message=f"{agent_type}: {res.get('message', '')}")


class EvolutionAgentTool(Tool):
    name = "agent_evolution"
    description = "Spawn an evolution agent: self_evolution, orchestrator"
    parameters = {
        "type": "evolution type: self_evolution, orchestrator",
        "task": "task dict: {'tool': name, 'parameters': {...}} or {'query': text}",
    }
    destructive = False

    def available(self) -> bool:
        return True

    def execute(self, parameters: dict) -> ToolResult:
        agent_type = str((parameters or {}).get("type", "self_evolution")).strip().lower()
        task = (parameters or {}).get("task", {"query": "evaluate"})
        valid = ["self_evolution", "orchestrator"]
        if agent_type not in valid:
            return ToolResult.fail("invalid_type", f"Valid: {', '.join(valid)}")
        result = engine.spawn(agent_type, task, wait=True)
        if not result.get("ok"):
            return ToolResult.fail(result.get("error"), result.get("message"))
        agent = result.get("agent", {})
        res = agent.get("result", {})
        return ToolResult.ok(data=result, message=f"{agent_type}: {res.get('message', '')}")
