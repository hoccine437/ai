# agents/types.py
"""The 21+ agent TYPES — their contracts, not their instances.

Each type fixes an intent profile and a tool whitelist. Whitelists contain
only NON-destructive tools: anything needing confirmation stays on the
supervised (human-approved) path through the main pipeline.

Agent Categories:
  COGNITION:   core_reasoning, planning, decision, prediction, problem_solving
  KNOWLEDGE:   research, memory, learning, knowledge
  QUALITY:     self_critic, security, verifier
  EXECUTION:   coding, tool, system_control
  PHONE:       vision, voice, controller
  BUSINESS:    finance, communicator, creative
  EVOLUTION:   self_evolution, orchestrator
  OBSERVATION: monitor, architect, tester, data
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class AgentType:
    name: str
    description: str
    #: tools this type may execute through the Tool Manager
    allowed_tools: tuple[str, ...]
    #: whether it may search the knowledge base memory directly
    can_search_memory: bool
    max_parallel: int = 3
    #: category for UI grouping
    category: str = "general"


# ---------------------------------------------------------------------------
# The 21 Core Agents
# ---------------------------------------------------------------------------

AGENT_TYPES: dict[str, AgentType] = {t.name: t for t in (

    # === COGNITION ===

    AgentType(
        "core_reasoning",
        "deep logical reasoning, analysis, inference, and structured thinking",
        allowed_tools=("read_file", "search_files", "calculate", "format_json",
                       "text_stats", "hash_text", "random_number"),
        can_search_memory=True,
        max_parallel=3,
        category="cognition",
    ),
    AgentType(
        "planning",
        "task decomposition, dependency mapping, sequencing, and goal planning",
        allowed_tools=("read_file", "search_files", "list_directory",
                       "calculate", "format_json", "text_stats"),
        can_search_memory=True,
        max_parallel=3,
        category="cognition",
    ),
    AgentType(
        "decision",
        "evaluate options, weigh evidence, make recommendations and trade-offs",
        allowed_tools=("read_file", "search_files", "calculate", "format_json",
                       "text_stats", "http_get"),
        can_search_memory=True,
        max_parallel=3,
        category="cognition",
    ),
    AgentType(
        "prediction",
        "forecast outcomes, trend analysis, probability estimation from data",
        allowed_tools=("read_file", "search_files", "http_get", "calculate",
                       "format_json", "text_stats"),
        can_search_memory=True,
        max_parallel=2,
        category="cognition",
    ),
    AgentType(
        "problem_solving",
        "debug issues, root-cause analysis, systematic troubleshooting",
        allowed_tools=("read_file", "search_files", "list_directory", "calculate",
                       "format_json", "text_stats", "hash_text"),
        can_search_memory=True,
        max_parallel=3,
        category="cognition",
    ),

    # === KNOWLEDGE ===

    AgentType(
        "research",
        "gather and correlate information: read files, search, query memory",
        allowed_tools=("read_file", "search_files", "list_directory", "http_get",
                       "text_stats", "calculate"),
        can_search_memory=True,
        max_parallel=4,
        category="knowledge",
    ),
    AgentType(
        "memory",
        "manage, retrieve, and organize long-term memory and episodic records",
        allowed_tools=("read_file", "search_files", "list_directory",
                       "format_json", "text_stats"),
        can_search_memory=True,
        max_parallel=2,
        category="knowledge",
    ),
    AgentType(
        "learning",
        "acquire new knowledge, practice skills, verify understanding, adapt",
        allowed_tools=("read_file", "search_files", "list_directory",
                       "calculate", "format_json", "text_stats", "hash_text"),
        can_search_memory=True,
        max_parallel=2,
        category="knowledge",
    ),
    AgentType(
        "knowledge",
        "manage the knowledge base: store, retrieve, rank, and curate facts",
        allowed_tools=("read_file", "search_files", "list_directory",
                       "format_json", "text_stats", "hash_text"),
        can_search_memory=True,
        max_parallel=2,
        category="knowledge",
    ),

    # === QUALITY ===

    AgentType(
        "self_critic",
        "review and critique outputs for accuracy, completeness, and safety",
        allowed_tools=("read_file", "search_files", "calculate", "format_json",
                       "text_stats", "hash_text"),
        can_search_memory=True,
        max_parallel=2,
        category="quality",
    ),
    AgentType(
        "security",
        "vuln/secret/permission audit; read-only by constitution — never writes",
        allowed_tools=("read_file", "search_files", "list_directory", "hash_text",
                       "format_json", "text_stats"),
        can_search_memory=False,
        max_parallel=3,
        category="quality",
    ),
    AgentType(
        "verifier",
        "validate claims/results: recompute, cross-check, checksum, parse",
        allowed_tools=("calculate", "format_json", "text_stats", "hash_text",
                       "random_number", "read_file"),
        can_search_memory=True,
        max_parallel=4,
        category="quality",
    ),

    # === EXECUTION ===

    AgentType(
        "coder",
        "inspect and reason about code/files; executes nothing destructive",
        allowed_tools=("read_file", "search_files", "list_directory",
                       "format_json", "text_stats", "hash_text", "calculate"),
        can_search_memory=True,
        max_parallel=3,
        category="execution",
    ),
    AgentType(
        "coding",
        "inspect and reason about code/files; executes nothing destructive",
        allowed_tools=("read_file", "search_files", "list_directory",
                       "format_json", "text_stats", "hash_text", "calculate"),
        can_search_memory=True,
        max_parallel=3,
        category="execution",
    ),
    AgentType(
        "tool",
        "execute and coordinate tool calls, manage tool pipelines and chains",
        allowed_tools=("read_file", "search_files", "list_directory", "http_get",
                       "calculate", "format_json", "text_stats"),
        can_search_memory=True,
        max_parallel=3,
        category="execution",
    ),
    AgentType(
        "system_control",
        "device management, system monitoring, resource tracking, process control",
        allowed_tools=("device_state", "battery_status", "cpu_info", "memory_usage",
                       "network_info", "storage_usage", "system_info", "process_list"),
        can_search_memory=False,
        max_parallel=2,
        category="execution",
    ),

    # === PHONE ===

    AgentType(
        "vision",
        "analyze screenshots, UI hierarchy, visual content, and image data",
        allowed_tools=("read_file", "search_files", "list_directory",
                       "format_json", "text_stats", "device_state"),
        can_search_memory=True,
        max_parallel=2,
        category="phone",
    ),
    AgentType(
        "voice",
        "speech processing, voice commands, audio analysis, TTS coordination",
        allowed_tools=("read_file", "format_json", "text_stats",
                       "device_state"),
        can_search_memory=False,
        max_parallel=2,
        category="phone",
    ),
    AgentType(
        "controller",
        "device-facing actions: status/telemetry only through phone adapter",
        allowed_tools=("device_state", "battery_status", "cpu_info", "memory_usage",
                       "network_info", "storage_usage", "system_info", "process_list"),
        can_search_memory=False,
        max_parallel=2,
        category="phone",
    ),

    # === BUSINESS ===

    AgentType(
        "finance",
        "market analysis from fetched data; never fabricates positions or returns",
        allowed_tools=("http_get", "read_file", "calculate", "format_json",
                       "text_stats", "search_files"),
        can_search_memory=True,
        max_parallel=2,
        category="business",
    ),
    AgentType(
        "communication",
        "communication lanes: inbox reads, contact lookup, draft preparation",
        allowed_tools=("comm_inbox", "comm_draft", "comm_health",
                       "contact_lookup", "calendar_list"),
        can_search_memory=True,
        max_parallel=2,
        category="business",
    ),
    AgentType(
        "communicator",
        "communication lanes: inbox reads, contact lookup, draft preparation",
        allowed_tools=("comm_inbox", "comm_draft", "comm_health",
                       "contact_lookup", "calendar_list"),
        can_search_memory=True,
        max_parallel=2,
        category="business",
    ),
    AgentType(
        "creative",
        "creative writing, brainstorming, content generation, ideation",
        allowed_tools=("read_file", "search_files", "format_json",
                       "text_stats", "calculate", "http_get"),
        can_search_memory=True,
        max_parallel=3,
        category="business",
    ),

    # === EVOLUTION ===

    AgentType(
        "self_evolution",
        "self-improvement: analyze performance, identify gaps, propose upgrades",
        allowed_tools=("read_file", "search_files", "list_directory",
                       "format_json", "text_stats", "calculate"),
        can_search_memory=True,
        max_parallel=2,
        category="evolution",
    ),
    AgentType(
        "orchestrator",
        "coordinate multi-agent workflows, manage lanes, aggregate results",
        allowed_tools=("read_file", "search_files", "list_directory",
                       "format_json", "text_stats"),
        can_search_memory=True,
        max_parallel=2,
        category="evolution",
    ),

    # === OBSERVATION (legacy, kept for backward compatibility) ===

    AgentType(
        "monitor",
        "observe the environment over time; read-only probes and clock tools",
        allowed_tools=("get_time", "get_date", "device_state", "cpu_info",
                       "memory_usage", "network_info", "storage_usage"),
        can_search_memory=False,
        max_parallel=2,
        category="observation",
    ),
    AgentType(
        "architect",
        "repository/dependency analysis, module boundaries, integration planning",
        allowed_tools=("read_file", "search_files", "list_directory", "format_json"),
        can_search_memory=True,
        max_parallel=3,
        category="observation",
    ),
    AgentType(
        "tester",
        "bounded test execution + failure extraction; never unlimited compute",
        allowed_tools=("run_pytest", "read_file", "search_files", "list_directory",
                       "text_stats", "calculate"),
        can_search_memory=True,
        max_parallel=2,
        category="observation",
    ),
    AgentType(
        "data",
        "parse / transform / validate structured data",
        allowed_tools=("calculate", "format_json", "text_stats", "base64_convert",
                       "hash_text", "read_file", "search_files"),
        can_search_memory=True,
        max_parallel=4,
        category="observation",
    ),

    # === BACKWARD COMPAT (alias for researcher) ===

    AgentType(
        "researcher",
        "gather and correlate information: read files, search, query memory",
        allowed_tools=("read_file", "search_files", "list_directory", "http_get",
                       "text_stats", "calculate"),
        can_search_memory=True,
        max_parallel=4,
        category="knowledge",
    ),
)}


# Quick accessors
def get_type(name: str) -> AgentType | None:
    return AGENT_TYPES.get((name or "").strip().lower())


def all_categories() -> dict[str, list[str]]:
    """Group agent names by category for UI/tool display."""
    cats: dict[str, list[str]] = {}
    for name, t in AGENT_TYPES.items():
        cats.setdefault(t.category, []).append(name)
    return cats


def agents_by_category(category: str) -> list[str]:
    return [n for n, t in AGENT_TYPES.items() if t.category == category]
