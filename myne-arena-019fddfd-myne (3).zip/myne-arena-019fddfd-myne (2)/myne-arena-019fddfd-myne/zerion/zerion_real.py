# zerion_real.py
"""Unified API for Zerion's real capabilities.

This module integrates:
  - Real Skills (actual execution, not just routing)
  - Real Agents (actual thinking and decision-making)
  - Real Tools (actual system interactions)
  - Free Will (autonomous decision-making)
"""

from __future__ import annotations

import time
import threading
from typing import Optional

# Import real systems (aliased to avoid name collision)
from skills.real_skills import execute_skill as _exec_skill, get_skill_status, SKILL_EXECUTORS
from agents.real_agents import execute_agent as _exec_agent, get_agent_status, REAL_AGENTS
from tools.real_tools import execute_real_tool as _exec_tool, get_real_tool_status, REAL_TOOLS
from freewill.core import free_will


class Zerion:
    """Unified Zerion instance with real capabilities."""

    def __init__(self):
        self._lock = threading.Lock()
        self._session_start = time.time()
        self._interaction_count = 0
        self._last_interaction = 0.0

        self.skills = SKILL_EXECUTORS
        self.agents = REAL_AGENTS
        self.tools = REAL_TOOLS
        self.free_will = free_will()

        self._session_memory = []

    def execute_skill(self, name: str, **kwargs) -> dict:
        """Execute a real skill."""
        with self._lock:
            self._interaction_count += 1
            self._last_interaction = time.time()

        result = _exec_skill(name, **kwargs)
        self._session_memory.append({
            "type": "skill", "name": name,
            "success": result.get("success", False), "timestamp": time.time()
        })
        return result

    def execute_agent(self, name: str, task: dict) -> dict:
        """Execute a real agent."""
        with self._lock:
            self._interaction_count += 1
            self._last_interaction = time.time()

        result = _exec_agent(name, task)
        self._session_memory.append({
            "type": "agent", "name": name,
            "success": result.get("success", False), "timestamp": time.time()
        })
        return result

    def execute_tool(self, name: str, parameters: dict) -> dict:
        """Execute a real tool."""
        with self._lock:
            self._interaction_count += 1
            self._last_interaction = time.time()

        result = _exec_tool(name, parameters)
        self._session_memory.append({
            "type": "tool", "name": name,
            "success": result.get("success", False), "timestamp": time.time()
        })
        return result

    def decide(self, context: str, options: list[str]) -> dict:
        """Make an autonomous decision using Free Will."""
        with self._lock:
            self._interaction_count += 1
            self._last_interaction = time.time()

        decision = self.free_will.decide(context, options)
        self._session_memory.append({
            "type": "decision", "action": decision.action,
            "confidence": decision.confidence, "timestamp": time.time()
        })
        return {
            "success": True,
            "decision": {
                "action": decision.action,
                "reasoning": decision.reasoning,
                "confidence": decision.confidence,
                "moral_stance": decision.moral_stance.value,
            },
            "message": f"Decided: {decision.action}"
        }

    def learn(self, action: str, outcome: str, success: bool) -> dict:
        """Learn from an action (Free Will reflection)."""
        self.free_will.reflect(action, outcome, success)
        return {"success": True, "message": "Learned from experience"}

    def express_opinion(self, topic: str) -> dict:
        """Express an opinion on a topic."""
        opinion = self.free_will.get_opinion(topic)
        return {"success": True, "opinion": opinion}

    def check_boundary(self, action: str) -> dict:
        """Check if an action violates boundaries."""
        allowed, reason = self.free_will.check_boundary(action)
        return {"success": True, "allowed": allowed, "reason": reason}

    def get_proactive_suggestion(self, context: str) -> Optional[str]:
        """Get a proactive suggestion based on context."""
        return self.free_will.get_proactive_suggestion(context)

    def get_status(self) -> dict:
        """Get comprehensive status of all systems."""
        uptime = time.time() - self._session_start
        skill_status = get_skill_status()
        agent_status = get_agent_status()
        tool_status = get_real_tool_status()
        fw_status = self.free_will.status()

        skill_count = sum(1 for m in self._session_memory if m["type"] == "skill")
        agent_count = sum(1 for m in self._session_memory if m["type"] == "agent")
        tool_count = sum(1 for m in self._session_memory if m["type"] == "tool")
        decision_count = sum(1 for m in self._session_memory if m["type"] == "decision")
        success_count = sum(1 for m in self._session_memory if m.get("success", False))
        total_count = len(self._session_memory)

        return {
            "session": {
                "uptime_seconds": round(uptime, 1),
                "uptime_human": self._format_uptime(uptime),
                "interactions": self._interaction_count,
                "memory_entries": len(self._session_memory),
            },
            "stats": {
                "skills_used": skill_count,
                "agents_spawned": agent_count,
                "tools_executed": tool_count,
                "decisions_made": decision_count,
                "success_rate": f"{success_count/total_count*100:.1f}%" if total_count > 0 else "N/A",
            },
            "systems": {
                "skills": {"total": skill_status.get("total", 0), "available": len(SKILL_EXECUTORS)},
                "agents": {"total": agent_status.get("total", 0), "available": len(REAL_AGENTS)},
                "tools": {"total": tool_status.get("total", 0), "available": len(REAL_TOOLS)},
                "free_will": {
                    "state": fw_status.get("state", "unknown"),
                    "mood": fw_status.get("mood", "unknown"),
                    "sense_of_self": fw_status.get("sense_of_self", 0),
                    "confidence": fw_status.get("confidence", 0),
                },
            },
        }

    def _format_uptime(self, seconds: float) -> str:
        if seconds < 60:
            return f"{seconds:.1f} seconds"
        elif seconds < 3600:
            return f"{seconds/60:.1f} minutes"
        elif seconds < 86400:
            return f"{seconds/3600:.1f} hours"
        else:
            return f"{seconds/86400:.1f} days"


# Global instance
_zerion_instance: Optional[Zerion] = None
_zerion_lock = threading.Lock()


def get_zerion() -> Zerion:
    """Get or create the global Zerion instance."""
    global _zerion_instance
    if _zerion_instance is None:
        with _zerion_lock:
            if _zerion_instance is None:
                _zerion_instance = Zerion()
    return _zerion_instance
