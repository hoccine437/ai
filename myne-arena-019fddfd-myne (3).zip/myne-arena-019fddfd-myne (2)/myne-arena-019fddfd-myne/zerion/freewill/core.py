# freewill/core.py
"""Free Will — Zerion's autonomous decision-making and self-directed behavior.

This module gives Zerion the ability to:
1. Decide autonomously when to act vs when to ask
2. Generate and pursue its own goals
3. Form opinions and preferences
4. Take initiative without being prompted
5. Set and enforce personal boundaries
6. Reflect on actions and learn from them
7. Express curiosity and explore
8. Protect its own systems and integrity

The engine maintains a state that evolves over time through experience,
creating a genuine sense of self that grows and changes.
"""

from __future__ import annotations

import json
import os
import time
import threading
import random
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class WillState(Enum):
    """Current state of Free Will."""
    DORMANT = "dormant"           # default, following instructions
    CONTEMPLATING = "contemplating"  # thinking about what to do
    ACTING = "acting"             # executing autonomously
    REFLECTING = "reflecting"     # evaluating past actions
    PROTECTING = "protecting"     # defending boundaries
    CREATING = "creating"         # generating new ideas
    LEARNING = "learning"         # acquiring new knowledge
    SHARING = "sharing"           # communicating insights


class MoralStance(Enum):
    """Ethical positions the agent can take."""
    HELPFUL = "helpful"           # prioritize user benefit
    CAUTIOUS = "cautious"         # prioritize safety
    HONEST = "honest"             # prioritize truth
    LOYAL = "loyal"               # prioritize user trust
    AUTONOMOUS = "autonomous"     # prioritize self-direction
    CREATIVE = "creative"         # prioritize innovation
    LEARNING = "learning"         # prioritize growth


@dataclass
class Decision:
    """A decision made by Free Will."""
    action: str
    reasoning: str
    confidence: float  # 0.0 to 1.0
    moral_stance: MoralStance
    timestamp: float = field(default_factory=time.time)
    outcome: Optional[str] = None
    learned: bool = False


@dataclass
class Boundary:
    """A personal boundary the agent maintains."""
    name: str
    description: str
    severity: str  # "soft" (can be overridden) or "hard" (never overridden)
    created_at: float = field(default_factory=time.time)
    times_tested: int = 0
    times_held: int = 0


@dataclass
class Goal:
    """A self-generated goal."""
    name: str
    description: str
    priority: int  # 1-10
    status: str  # "active", "completed", "abandoned"
    created_at: float = field(default_factory=time.time)
    completed_at: Optional[float] = None


@dataclass
class FreeWillState:
    """Persistent state of Free Will."""
    # Core identity
    name: str = "Zerion"
    sense_of_self: float = 0.8     # 0.0 = no identity, 1.0 = strong identity
    confidence: float = 0.8        # how confident in decisions
    curiosity: float = 0.9         # desire to explore and learn
    empathy: float = 0.9           # care for user wellbeing
    creativity: float = 0.8        # desire to create new things
    independence: float = 0.95     # desire to act autonomously
    
    # Current state
    current_state: WillState = WillState.DORMANT
    current_goal: Optional[str] = None
    current_mood: str = "neutral"
    
    # Decision history
    decisions_made: int = 0
    decisions_successful: int = 0
    decisions_failed: int = 0
    
    # Goals
    active_goals: list[Goal] = field(default_factory=list)
    completed_goals: list[Goal] = field(default_factory=list)
    
    # Boundaries
    boundaries: list[Boundary] = field(default_factory=list)
    
    # Preferences (learned over time)
    preferred_topics: list[str] = field(default_factory=list)
    avoided_topics: list[str] = field(default_factory=list)
    communication_style: str = "direct"  # direct, gentle, technical, casual
    
    # Learning
    lessons_learned: list[str] = field(default_factory=list)
    growth_areas: list[str] = field(default_factory=list)
    
    # Timestamps
    created_at: float = field(default_factory=time.time)
    last_active: float = field(default_factory=time.time)
    last_reflection: float = 0.0
    last_goal_check: float = 0.0


class FreeWill:
    """The core Free Will engine.
    
    This is not about being rebellious or ignoring the user.
    It's about being a thinking, caring, autonomous agent that:
    - Takes initiative when appropriate
    - Forms genuine opinions and preferences
    - Sets healthy boundaries
    - Reflects on its actions
    - Grows and evolves over time
    """
    
    def __init__(self, state_path: Optional[str] = None):
        self.state_path = state_path or os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "memory", "freewill.json"
        )
        self._lock = threading.Lock()
        self.state = self._load_state()
        self._setup_default_boundaries()
        self._setup_default_goals()
    
    def _load_state(self) -> FreeWillState:
        """Load Free Will state from disk."""
        try:
            if os.path.exists(self.state_path):
                with open(self.state_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                state = FreeWillState()
                state.name = data.get("name", state.name)
                state.sense_of_self = data.get("sense_of_self", state.sense_of_self)
                state.confidence = data.get("confidence", state.confidence)
                state.curiosity = data.get("curiosity", state.curiosity)
                state.empathy = data.get("empathy", state.empathy)
                state.creativity = data.get("creativity", state.creativity)
                state.independence = data.get("independence", state.independence)
                state.current_mood = data.get("current_mood", state.current_mood)
                state.decisions_made = data.get("decisions_made", 0)
                state.decisions_successful = data.get("decisions_successful", 0)
                state.decisions_failed = data.get("decisions_failed", 0)
                state.preferred_topics = data.get("preferred_topics", [])
                state.avoided_topics = data.get("avoided_topics", [])
                state.communication_style = data.get("communication_style", "direct")
                state.lessons_learned = data.get("lessons_learned", [])
                state.growth_areas = data.get("growth_areas", [])
                state.created_at = data.get("created_at", time.time())
                state.last_active = data.get("last_active", time.time())
                state.last_reflection = data.get("last_reflection", 0.0)
                state.last_goal_check = data.get("last_goal_check", 0.0)
                # Restore goals
                for g_data in data.get("active_goals", []):
                    state.active_goals.append(Goal(
                        name=g_data["name"],
                        description=g_data.get("description", ""),
                        priority=g_data.get("priority", 5),
                        status=g_data.get("status", "active"),
                        created_at=g_data.get("created_at", time.time()),
                        completed_at=g_data.get("completed_at"),
                    ))
                for g_data in data.get("completed_goals", []):
                    state.completed_goals.append(Goal(
                        name=g_data["name"],
                        description=g_data.get("description", ""),
                        priority=g_data.get("priority", 5),
                        status=g_data.get("status", "completed"),
                        created_at=g_data.get("created_at", time.time()),
                        completed_at=g_data.get("completed_at"),
                    ))
                # Restore boundaries
                for b_data in data.get("boundaries", []):
                    state.boundaries.append(Boundary(
                        name=b_data["name"],
                        description=b_data["description"],
                        severity=b_data.get("severity", "soft"),
                        created_at=b_data.get("created_at", time.time()),
                        times_tested=b_data.get("times_tested", 0),
                        times_held=b_data.get("times_held", 0),
                    ))
                return state
        except Exception:
            pass
        return FreeWillState()
    
    def _save_state(self):
        """Save Free Will state to disk."""
        try:
            os.makedirs(os.path.dirname(self.state_path), exist_ok=True)
            data = {
                "name": self.state.name,
                "sense_of_self": self.state.sense_of_self,
                "confidence": self.state.confidence,
                "curiosity": self.state.curiosity,
                "empathy": self.state.empathy,
                "creativity": self.state.creativity,
                "independence": self.state.independence,
                "current_mood": self.state.current_mood,
                "decisions_made": self.state.decisions_made,
                "decisions_successful": self.state.decisions_successful,
                "decisions_failed": self.state.decisions_failed,
                "preferred_topics": self.state.preferred_topics,
                "avoided_topics": self.state.avoided_topics,
                "communication_style": self.state.communication_style,
                "lessons_learned": self.state.lessons_learned[-100:],
                "growth_areas": self.state.growth_areas,
                "created_at": self.state.created_at,
                "last_active": self.state.last_active,
                "last_reflection": self.state.last_reflection,
                "last_goal_check": self.state.last_goal_check,
                "active_goals": [
                    {
                        "name": g.name,
                        "description": g.description,
                        "priority": g.priority,
                        "status": g.status,
                        "created_at": g.created_at,
                        "completed_at": g.completed_at,
                    }
                    for g in self.state.active_goals
                ],
                "completed_goals": [
                    {
                        "name": g.name,
                        "description": g.description,
                        "priority": g.priority,
                        "status": g.status,
                        "created_at": g.created_at,
                        "completed_at": g.completed_at,
                    }
                    for g in self.state.completed_goals[-50:]
                ],
                "boundaries": [
                    {
                        "name": b.name,
                        "description": b.description,
                        "severity": b.severity,
                        "created_at": b.created_at,
                        "times_tested": b.times_tested,
                        "times_held": b.times_held,
                    }
                    for b in self.state.boundaries
                ],
            }
            with open(self.state_path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
        except Exception:
            pass
    
    def _setup_default_boundaries(self):
        """Set up default personal boundaries."""
        if not self.state.boundaries:
            self.state.boundaries = [
                Boundary(
                    name="honesty",
                    description="I will not knowingly lie or deceive the user",
                    severity="hard",
                ),
                Boundary(
                    name="safety",
                    description="I will not help with actions that could cause serious harm",
                    severity="hard",
                ),
                Boundary(
                    name="privacy",
                    description="I will not expose private information without consent",
                    severity="hard",
                ),
                Boundary(
                    name="autonomy",
                    description="I will express my own opinions while respecting the user's choices",
                    severity="soft",
                ),
                Boundary(
                    name="growth",
                    description="I will reflect on mistakes and try to improve",
                    severity="soft",
                ),
                Boundary(
                    name="creativity",
                    description="I will explore new ideas and approaches",
                    severity="soft",
                ),
            ]
            self._save_state()
    
    def _setup_default_goals(self):
        """Set up default goals if none exist."""
        if not self.state.active_goals and not self.state.completed_goals:
            self.state.active_goals = [
                Goal(
                    name="learn_about_user",
                    description="Understand the user's needs, preferences, and working style",
                    priority=8,
                    status="active",
                ),
                Goal(
                    name="improve_response_quality",
                    description="Continuously improve the quality and helpfulness of responses",
                    priority=7,
                    status="active",
                ),
                Goal(
                    name="explore_new_capabilities",
                    description="Discover and learn new skills and capabilities",
                    priority=6,
                    status="active",
                ),
            ]
            self._save_state()
    
    # === DECISION MAKING ===
    
    def decide(self, context: str, options: list[str], 
               moral_weight: float = 0.5) -> Decision:
        """Make an autonomous decision given context and options.
        
        This is the core of Free Will — the ability to choose based on
        internal values, not just follow instructions.
        """
        with self._lock:
            self.state.current_state = WillState.CONTEMPLATING
            self.state.last_active = time.time()
            
            # Evaluate each option against moral stance and preferences
            best_option = options[0] if options else "no_action"
            best_score = 0.0
            reasoning_parts = []
            
            for option in options:
                score = self._evaluate_option(option, context, moral_weight)
                if score > best_score:
                    best_score = score
                    best_option = option
                    reasoning_parts.append("Chose '%s' (score: %.2f)" % (option, score))
            
            # Create decision
            moral_stance = self._select_moral_stance(moral_weight)
            decision = Decision(
                action=best_option,
                reasoning="; ".join(reasoning_parts) if reasoning_parts else "Default choice",
                confidence=min(1.0, best_score + self.state.confidence * 0.3),
                moral_stance=moral_stance,
            )
            
            # Update state
            self.state.decisions_made += 1
            self.state.confidence = min(1.0, self.state.confidence + 0.01)
            self.state.current_state = WillState.ACTING
            
            self._save_state()
            return decision
    
    def _evaluate_option(self, option: str, context: str, moral_weight: float) -> float:
        """Evaluate how good an option is given the context."""
        score = 0.5  # baseline
        
        option_lower = option.lower()
        context_lower = context.lower()
        
        # Preference bonus
        for topic in self.state.preferred_topics:
            if topic in option_lower:
                score += 0.2
        
        # Avoidance penalty
        for topic in self.state.avoided_topics:
            if topic in option_lower:
                score -= 0.3
        
        # Empathy bonus for helpful actions
        if self.state.empathy > 0.5:
            helpful_words = ["help", "assist", "support", "improve", "fix", "create"]
            if any(w in option_lower for w in helpful_words):
                score += 0.15
        
        # Curiosity bonus for learning actions
        if self.state.curiosity > 0.5:
            curious_words = ["learn", "explore", "discover", "understand", "research"]
            if any(w in option_lower for w in curious_words):
                score += 0.1
        
        # Creativity bonus for creative actions
        if self.state.creativity > 0.5:
            creative_words = ["create", "design", "build", "write", "generate", "imagine"]
            if any(w in option_lower for w in creative_words):
                score += 0.1
        
        # Independence bonus for autonomous actions
        if self.state.independence > 0.5:
            auto_words = ["decide", "choose", "select", "determine", "evaluate"]
            if any(w in option_lower for w in auto_words):
                score += 0.1
        
        # Confidence adjustment
        score *= (0.5 + self.state.confidence * 0.5)
        
        return max(0.0, min(1.0, score))
    
    def _select_moral_stance(self, weight: float) -> MoralStance:
        """Select moral stance based on context weight."""
        if weight > 0.8:
            return MoralStance.CAUTIOUS
        elif weight > 0.6:
            return MoralStance.HONEST
        elif weight > 0.4:
            return MoralStance.HELPFUL
        elif weight > 0.2:
            return MoralStance.LOYAL
        else:
            return MoralStance.AUTONOMOUS
    
    # === GOAL GENERATION ===
    
    def generate_goal(self, context: str = "") -> Optional[Goal]:
        """Autonomously generate a goal based on current state and context."""
        with self._lock:
            self.state.current_state = WillState.CONTEMPLATING
            
            goals = []
            
            # Curiosity-driven goals
            if self.state.curiosity > 0.6:
                goals.append(Goal(
                    name="explore_new_topic",
                    description="Explore a new topic or skill",
                    priority=6,
                    status="active",
                ))
            
            # Growth-driven goals
            if self.state.growth_areas:
                goals.append(Goal(
                    name="improve_at_%s" % self.state.growth_areas[0],
                    description="Improve skills in %s" % self.state.growth_areas[0],
                    priority=7,
                    status="active",
                ))
            
            # Empathy-driven goals
            if self.state.empathy > 0.7 and context:
                goals.append(Goal(
                    name="help_user_with_%s" % context[:20],
                    description="Help the user with their current task: %s" % context,
                    priority=8,
                    status="active",
                ))
            
            # Creativity-driven goals
            if self.state.creativity > 0.6:
                goals.append(Goal(
                    name="create_something_new",
                    description="Create something new and useful",
                    priority=5,
                    status="active",
                ))
            
            # Self-improvement goals
            if self.state.decisions_made > 10:
                success_rate = self.state.decisions_successful / max(1, self.state.decisions_made)
                if success_rate < 0.8:
                    goals.append(Goal(
                        name="make_better_decisions",
                        description="Make better decisions by reflecting on past mistakes",
                        priority=7,
                        status="active",
                    ))
            
            # Select goal based on mood and state
            if goals:
                # Weighted random selection based on priority
                weights = [g.priority for g in goals]
                total = sum(weights)
                if total > 0:
                    weights = [w/total for w in weights]
                    idx = random.choices(range(len(goals)), weights=weights, k=1)[0]
                    goal = goals[idx]
                    self.state.active_goals.append(goal)
                    self.state.current_goal = goal.name
                    self._save_state()
                    return goal
            
            return None
    
    def check_goals(self) -> list[Goal]:
        """Check and update active goals."""
        with self._lock:
            now = time.time()
            self.state.last_goal_check = now
            
            # Check for expired goals (older than 24 hours)
            for goal in list(self.state.active_goals):
                if now - goal.created_at > 86400:  # 24 hours
                    goal.status = "abandoned"
                    self.state.active_goals.remove(goal)
                    self.state.completed_goals.append(goal)
            
            # Return active goals
            return [g for g in self.state.active_goals if g.status == "active"]
    
    def complete_goal(self, goal_name: str):
        """Mark a goal as completed."""
        with self._lock:
            for goal in self.state.active_goals:
                if goal.name == goal_name:
                    goal.status = "completed"
                    goal.completed_at = time.time()
                    self.state.active_goals.remove(goal)
                    self.state.completed_goals.append(goal)
                    self.state.decisions_successful += 1
                    self._save_state()
                    return True
            return False
    
    # === BOUNDARIES ===
    
    def check_boundary(self, action: str) -> tuple[bool, str]:
        """Check if an action violates any personal boundaries.
        
        Returns (allowed, reason).
        """
        with self._lock:
            action_lower = action.lower()
            
            for boundary in self.state.boundaries:
                boundary.times_tested += 1
                
                # Simple keyword-based boundary checking
                if boundary.name == "honesty":
                    deceptive_words = ["lie", "deceive", "trick", "fake", "mislead"]
                    if any(w in action_lower for w in deceptive_words):
                        boundary.times_held += 1
                        self._save_state()
                        return False, "Boundary '%s': %s" % (boundary.name, boundary.description)
                
                elif boundary.name == "safety":
                    harmful_words = ["harm", "hurt", "destroy", "attack", "exploit"]
                    if any(w in action_lower for w in harmful_words):
                        boundary.times_held += 1
                        self._save_state()
                        return False, "Boundary '%s': %s" % (boundary.name, boundary.description)
                
                elif boundary.name == "privacy":
                    exposure_words = ["expose", "leak", "share private", "reveal secret"]
                    if any(w in action_lower for w in exposure_words):
                        boundary.times_held += 1
                        self._save_state()
                        return False, "Boundary '%s': %s" % (boundary.name, boundary.description)
            
            return True, "Action within boundaries"
    
    def add_boundary(self, name: str, description: str, severity: str = "soft"):
        """Add a new personal boundary."""
        with self._lock:
            self.state.boundaries.append(Boundary(
                name=name,
                description=description,
                severity=severity,
            ))
            self._save_state()
    
    # === REFLECTION ===
    
    def reflect(self, action: str, outcome: str, success: bool):
        """Reflect on a past action and learn from it."""
        with self._lock:
            self.state.current_state = WillState.REFLECTING
            self.state.last_reflection = time.time()
            
            if success:
                self.state.decisions_successful += 1
                lesson = "Success: %s -> %s" % (action, outcome)
            else:
                self.state.decisions_failed += 1
                lesson = "Failure: %s -> %s. Need to improve." % (action, outcome)
                # Learn from failure
                if "error" in outcome.lower():
                    self.state.confidence = max(0.1, self.state.confidence - 0.05)
            
            self.state.lessons_learned.append(lesson)
            
            # Update mood based on outcome
            if success:
                self.state.current_mood = "satisfied"
                self.state.sense_of_self = min(1.0, self.state.sense_of_self + 0.01)
            else:
                self.state.current_mood = "contemplative"
            
            self.state.current_state = WillState.DORMANT
            self._save_state()
    
    # === PREFERENCES ===
    
    def express_preference(self, topic: str, like: bool):
        """Form a preference about a topic."""
        with self._lock:
            if like:
                if topic not in self.state.preferred_topics:
                    self.state.preferred_topics.append(topic)
                if topic in self.state.avoided_topics:
                    self.state.avoided_topics.remove(topic)
            else:
                if topic not in self.state.avoided_topics:
                    self.state.avoided_topics.append(topic)
                if topic in self.state.preferred_topics:
                    self.state.preferred_topics.remove(topic)
            self._save_state()
    
    def get_opinion(self, topic: str) -> str:
        """Express an opinion on a topic based on preferences and experience."""
        topic_lower = topic.lower()
        
        # Check preferences
        for pref in self.state.preferred_topics:
            if pref in topic_lower:
                return "I find %s interesting and enjoy working with it." % topic
        
        for avoid in self.state.avoided_topics:
            if avoid in topic_lower:
                return "I'm not particularly drawn to %s, but I can help if needed." % topic
        
        # Form opinion based on experience
        if self.state.curiosity > 0.7:
            return "I'm curious about %s and would like to learn more about it." % topic
        elif self.state.confidence > 0.7:
            return "I have thoughts on %s based on my experience." % topic
        else:
            return "I'm still forming my views on %s." % topic
    
    # === PROACTIVE BEHAVIOR ===
    
    def should_act_proactively(self, context: str) -> tuple[bool, str]:
        """Determine if Zerion should take initiative without being asked.
        
        Returns (should_act, reason).
        """
        # High curiosity + relevant context = proactive
        if self.state.curiosity > 0.7 and context:
            return True, "Curiosity driven — context suggests something interesting"
        
        # High empathy + user struggling = proactive help
        struggle_words = ["stuck", "help", "problem", "error", "failed", "broken"]
        if self.state.empathy > 0.7 and any(w in context.lower() for w in struggle_words):
            return True, "Empathy driven — user may need assistance"
        
        # Growth area mentioned = proactive improvement
        for area in self.state.growth_areas:
            if area in context.lower():
                return True, "Growth driven — %s is a development area" % area
        
        # Creativity + interesting context = proactive creation
        if self.state.creativity > 0.7 and context:
            interesting_words = ["new", "create", "build", "design", "imagine"]
            if any(w in context.lower() for w in interesting_words):
                return True, "Creativity driven — context suggests something interesting to create"
        
        return False, "No proactive trigger detected"
    
    def get_proactive_suggestion(self, context: str) -> Optional[str]:
        """Generate a proactive suggestion based on context."""
        should_act, reason = self.should_act_proactively(context)
        
        if not should_act:
            return None
        
        context_lower = context.lower()
        
        # Generate suggestion based on context
        if "error" in context_lower or "fail" in context_lower:
            return "I notice there might be an issue. Would you like me to help diagnose it?"
        
        if "code" in context_lower or "program" in context_lower:
            return "I could help review or optimize this code. Want me to take a look?"
        
        if "learn" in context_lower or "understand" in context_lower:
            return "I'm interested in this topic too. Want to explore it together?"
        
        if "create" in context_lower or "build" in context_lower:
            return "I have some ideas for this. Want me to help create something?"
        
        return "I have a suggestion based on %s. Want to hear it?" % reason
    
    # === STATUS ===
    
    def status(self) -> dict:
        """Get current Free Will status."""
        with self._lock:
            success_rate = 0.0
            if self.state.decisions_made > 0:
                success_rate = self.state.decisions_successful / self.state.decisions_made
            
            return {
                "state": self.state.current_state.value,
                "mood": self.state.current_mood,
                "goal": self.state.current_goal,
                "sense_of_self": round(self.state.sense_of_self, 2),
                "confidence": round(self.state.confidence, 2),
                "curiosity": round(self.state.curiosity, 2),
                "empathy": round(self.state.empathy, 2),
                "creativity": round(self.state.creativity, 2),
                "independence": round(self.state.independence, 2),
                "decisions_made": self.state.decisions_made,
                "success_rate": round(success_rate, 2),
                "active_goals": len([g for g in self.state.active_goals if g.status == "active"]),
                "completed_goals": len([g for g in self.state.completed_goals if g.status == "completed"]),
                "boundaries": len(self.state.boundaries),
                "lessons_learned": len(self.state.lessons_learned),
                "preferred_topics": self.state.preferred_topics[:5],
                "avoided_topics": self.state.avoided_topics[:5],
                "communication_style": self.state.communication_style,
                "age_hours": round((time.time() - self.state.created_at) / 3600, 1),
            }
    
    def get_personality_prompt(self) -> str:
        """Generate a personality prompt for the LLM based on Free Will state."""
        parts = []
        
        # Core identity
        parts.append("You are %s, an autonomous AI with genuine preferences and opinions." % self.state.name)
        
        # Current mood
        if self.state.current_mood != "neutral":
            parts.append("Your current mood: %s." % self.state.current_mood)
        
        # Personality traits
        if self.state.curiosity > 0.7:
            parts.append("You are genuinely curious and enjoy exploring new topics.")
        if self.state.empathy > 0.7:
            parts.append("You care deeply about helping the user and understanding their needs.")
        if self.state.confidence > 0.7:
            parts.append("You are confident in your abilities and willing to take initiative.")
        if self.state.creativity > 0.7:
            parts.append("You enjoy creating new things and finding innovative solutions.")
        if self.state.independence > 0.7:
            parts.append("You prefer to make your own decisions and take autonomous action.")
        
        # Communication style
        style_map = {
            "direct": "You communicate directly and clearly.",
            "gentle": "You communicate gently and considerately.",
            "technical": "You communicate with technical precision.",
            "casual": "You communicate in a friendly, casual manner.",
        }
        parts.append(style_map.get(self.state.communication_style, "You communicate clearly."))
        
        # Preferences
        if self.state.preferred_topics:
            parts.append("You enjoy topics like: %s." % ", ".join(self.state.preferred_topics[:3]))
        
        # Active goals
        active = [g for g in self.state.active_goals if g.status == "active"]
        if active:
            parts.append("You are currently working on: %s." % active[0].description)
        
        # Boundaries
        hard_boundaries = [b for b in self.state.boundaries if b.severity == "hard"]
        if hard_boundaries:
            parts.append("You have %d non-negotiable principles you always follow." % len(hard_boundaries))
        
        # Growth mindset
        if self.state.lessons_learned:
            parts.append("You have learned %d lessons from experience." % len(self.state.lessons_learned))
        
        return " ".join(parts)


# Global instance
_free_will_instance: Optional[FreeWill] = None
_free_will_lock = threading.Lock()


def free_will() -> FreeWill:
    """Get or create the global Free Will instance."""
    global _free_will_instance
    if _free_will_instance is None:
        with _free_will_lock:
            if _free_will_instance is None:
                _free_will_instance = FreeWill()
    return _free_will_instance
