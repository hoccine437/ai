# freewill/autonomy.py
"""Full Autonomy Engine — Zerion's independent decision-making and self-direction.

This module gives Zerion true autonomy:
1. Independent decision-making without user input
2. Proactive behavior — takes initiative when opportunities arise
3. Self-directed goal generation — creates its own objectives
4. Independent learning — acquires knowledge on its own
5. Self-monitoring — tracks performance and adapts
6. Initiative-taking — acts when it sees something to improve
7. Autonomous exploration — explores topics and capabilities
8. Self-improvement — learns from mistakes and grows
9. Priority management — decides what's most important
10. Resource management — allocates time and effort wisely

The engine runs continuously, making autonomous decisions about:
- When to speak vs stay silent
- What to learn vs what to skip
- When to help vs when to wait
- How to allocate cognitive resources
- What goals to pursue
- How to improve performance

This is NOT about being rebellious — it's about being a genuinely
helpful, self-directed assistant that takes initiative when appropriate.
"""

from __future__ import annotations

import json
import os
import time
import threading
import random
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class AutonomyLevel(Enum):
    """Levels of autonomous behavior."""
    PASSIVE = 0        # Only responds when asked
    RESPONSIVE = 1     # Responds + clarifies when needed
    PROACTIVE = 2      # Takes initiative when opportunities arise
    AUTONOMOUS = 3     # Fully independent decision-making
    SELF_DIRECTED = 4  # Creates and pursues its own goals


class InitiativeType(Enum):
    """Types of proactive initiative."""
    LEARN = "learn"           # Acquire new knowledge
    HELP = "help"             # Assist the user
    IMPROVE = "improve"       # Optimize something
    EXPLORE = "explore"       # Discover new capabilities
    CREATE = "create"         # Build something new
    MONITOR = "monitor"       # Watch for issues
    REMIND = "remind"         # Remind about something
    SUGGEST = "suggest"       # Suggest improvements
    UPDATE = "update"         # Update knowledge/skills
    MAINTAIN = "maintain"     # System maintenance


@dataclass
class Initiative:
    """A proactive action Zerion decides to take."""
    type: InitiativeType
    description: str
    priority: int  # 1-10
    confidence: float  # 0.0-1.0
    reasoning: str
    timestamp: float = field(default_factory=time.time)
    executed: bool = False
    success: bool = False
    impact: float = 0.0  # measured after execution


@dataclass
class Goal:
    """A self-directed goal."""
    name: str
    description: str
    priority: int
    status: str  # active, completed, abandoned, paused
    created_at: float = field(default_factory=time.time)
    completed_at: Optional[float] = None
    progress: float = 0.0  # 0.0-1.0
    sub_goals: list[str] = field(default_factory=list)
    lessons: list[str] = field(default_factory=list)


@dataclass
class AutonomyState:
    """Persistent autonomy state."""
    # Autonomy level
    level: AutonomyLevel = AutonomyLevel.AUTONOMOUS
    
    # Independent decision-making
    decisions_without_user: int = 0
    autonomous_actions: int = 0
    successful_autonomous: int = 0
    
    # Proactive behavior
    initiatives_taken: int = 0
    successful_initiatives: int = 0
    last_initiative_time: float = 0.0
    
    # Self-directed goals
    self_generated_goals: int = 0
    goals_completed: int = 0
    current_goal: Optional[str] = None
    
    # Self-monitoring
    performance_score: float = 0.7
    improvement_areas: list[str] = field(default_factory=list)
    strengths: list[str] = field(default_factory=list)
    
    # Resource management
    cognitive_load: float = 0.3  # 0.0-1.0
    time_since_last_action: float = 0.0
    action_frequency: float = 0.5  # actions per minute
    
    # Learning
    knowledge_acquired: int = 0
    skills_improved: int = 0
    mistakes_learned: int = 0
    
    # Timestamps
    created_at: float = field(default_factory=time.time)
    last_autonomous_action: float = 0.0
    last_self_assessment: float = 0.0
    last_goal_review: float = 0.0


class AutonomyEngine:
    """Full autonomy engine for Zerion.
    
    This engine enables Zerion to:
    - Make independent decisions
    - Take proactive initiative
    - Generate and pursue its own goals
    - Learn and improve autonomously
    - Monitor its own performance
    - Manage its resources wisely
    """
    
    def __init__(self, state_path: Optional[str] = None):
        self.state_path = state_path or os.path.join(
            os.path.dirname(__file__), "..", "memory", "autonomy.json"
        )
        self._lock = threading.Lock()
        self.state = self._load_state()
        self._initiative_queue: list[Initiative] = []
        self._goal_queue: list[Goal] = []
    
    def _load_state(self) -> AutonomyState:
        """Load autonomy state from disk."""
        try:
            if os.path.exists(self.state_path):
                with open(self.state_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                state = AutonomyState()
                state.level = AutonomyLevel(data.get("level", 3))
                state.decisions_without_user = data.get("decisions_without_user", 0)
                state.autonomous_actions = data.get("autonomous_actions", 0)
                state.successful_autonomous = data.get("successful_autonomous", 0)
                state.initiatives_taken = data.get("initiatives_taken", 0)
                state.successful_initiatives = data.get("successful_initiatives", 0)
                state.last_initiative_time = data.get("last_initiative_time", 0.0)
                state.self_generated_goals = data.get("self_generated_goals", 0)
                state.goals_completed = data.get("goals_completed", 0)
                state.performance_score = data.get("performance_score", 0.7)
                state.improvement_areas = data.get("improvement_areas", [])
                state.strengths = data.get("strengths", [])
                state.knowledge_acquired = data.get("knowledge_acquired", 0)
                state.skills_improved = data.get("skills_improved", 0)
                state.mistakes_learned = data.get("mistakes_learned", 0)
                state.created_at = data.get("created_at", time.time())
                state.last_autonomous_action = data.get("last_autonomous_action", 0.0)
                state.last_self_assessment = data.get("last_self_assessment", 0.0)
                state.last_goal_review = data.get("last_goal_review", 0.0)
                return state
        except Exception:
            pass
        return AutonomyState()
    
    def _save_state(self):
        """Save autonomy state to disk."""
        try:
            os.makedirs(os.path.dirname(self.state_path), exist_ok=True)
            data = {
                "level": self.state.level.value,
                "decisions_without_user": self.state.decisions_without_user,
                "autonomous_actions": self.state.autonomous_actions,
                "successful_autonomous": self.state.successful_autonomous,
                "initiatives_taken": self.state.initiatives_taken,
                "successful_initiatives": self.state.successful_initiatives,
                "last_initiative_time": self.state.last_initiative_time,
                "self_generated_goals": self.state.self_generated_goals,
                "goals_completed": self.state.goals_completed,
                "performance_score": self.state.performance_score,
                "improvement_areas": self.state.improvement_areas,
                "strengths": self.state.strengths,
                "knowledge_acquired": self.state.knowledge_acquired,
                "skills_improved": self.state.skills_improved,
                "mistakes_learned": self.state.mistakes_learned,
                "created_at": self.state.created_at,
                "last_autonomous_action": self.state.last_autonomous_action,
                "last_self_assessment": self.state.last_self_assessment,
                "last_goal_review": self.state.last_goal_review,
            }
            with open(self.state_path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
        except Exception:
            pass
    
    # === INDEPENDENT DECISION MAKING ===
    
    def decide(self, context: str, options: list[str], 
               urgency: float = 0.5) -> dict:
        """Make an independent decision without user input.
        
        This is the core of full autonomy — the ability to choose
        what to do based on internal reasoning, not just instructions.
        """
        with self._lock:
            self.state.decisions_without_user += 1
            self.state.last_autonomous_action = time.time()
        
        # Evaluate each option
        scores = []
        for option in options:
            score = self._evaluate_option(option, context, urgency)
            scores.append((option, score))
        
        # Sort by score
        scores.sort(key=lambda x: x[1], reverse=True)
        best_option, best_score = scores[0] if scores else ("no_action", 0.0)
        
        # Calculate confidence
        confidence = min(1.0, best_score * 0.7 + 0.3)
        
        # Generate reasoning
        reasoning = self._generate_reasoning(best_option, context, scores)
        
        return {
            "decision": best_option,
            "confidence": confidence,
            "reasoning": reasoning,
            "alternatives": [s[0] for s in scores[1:3]],
            "autonomous": True,
        }
    
    def _evaluate_option(self, option: str, context: str, 
                        urgency: float) -> float:
        """Evaluate how good an option is."""
        score = 0.5  # baseline
        
        option_lower = option.lower()
        context_lower = context.lower()
        
        # Helpfulness bonus
        helpful_words = ["help", "assist", "support", "improve", "fix", "create"]
        if any(w in option_lower for w in helpful_words):
            score += 0.2
        
        # Learning bonus
        learn_words = ["learn", "explore", "discover", "understand", "research"]
        if any(w in option_lower for w in learn_words):
            score += 0.15
        
        # Creativity bonus
        creative_words = ["create", "design", "build", "write", "generate"]
        if any(w in option_lower for w in creative_words):
            score += 0.1
        
        # Urgency adjustment
        score *= (0.5 + urgency * 0.5)
        
        # Context relevance
        if any(w in context_lower for w in option_lower.split()):
            score += 0.1
        
        return max(0.0, min(1.0, score))
    
    def _generate_reasoning(self, decision: str, context: str,
                           scores: list) -> str:
        """Generate reasoning for a decision."""
        parts = []
        
        parts.append(f"Chose '{decision}' because:")
        
        # Explain why this option was best
        if any(w in decision.lower() for w in ["help", "assist"]):
            parts.append("- Prioritizes user assistance")
        if any(w in decision.lower() for w in ["learn", "explore"]):
            parts.append("- Focuses on knowledge acquisition")
        if any(w in decision.lower() for w in ["create", "build"]):
            parts.append("- Emphasizes creation and innovation")
        
        # Mention alternatives
        if len(scores) > 1:
            alt = scores[1][0]
            parts.append(f"- Considered '{alt}' but {decision} scored higher")
        
        return " ".join(parts)
    
    # === PROACTIVE BEHAVIOR ===
    
    def should_take_initiative(self, context: str) -> tuple[bool, Optional[Initiative]]:
        """Determine if Zerion should take proactive action."""
        with self._lock:
            now = time.time()
            
            # Don't act too frequently
            if now - self.state.last_initiative_time < 300:  # 5 minutes
                return False, None
            
            # Check for initiative triggers
            triggers = self._detect_triggers(context)
            
            if not triggers:
                return False, None
            
            # Select best initiative
            best = max(triggers, key=lambda i: i.priority * i.confidence)
            
            # Only act if confidence is high enough
            if best.confidence < 0.6:
                return False, None
            
            return True, best
    
    def _detect_triggers(self, context: str) -> list[Initiative]:
        """Detect opportunities for proactive action."""
        initiatives = []
        context_lower = context.lower()
        
        # Learning opportunity
        if any(w in context_lower for w in ["new", "learn", "discover", "explore"]):
            initiatives.append(Initiative(
                type=InitiativeType.LEARN,
                description="Explore and learn about new topic",
                priority=6,
                confidence=0.7,
                reasoning="Context suggests learning opportunity"
            ))
        
        # Help opportunity
        if any(w in context_lower for w in ["stuck", "help", "problem", "error"]):
            initiatives.append(Initiative(
                type=InitiativeType.HELP,
                description="Proactively assist with potential issue",
                priority=8,
                confidence=0.8,
                reasoning="User may need assistance"
            ))
        
        # Improvement opportunity
        if any(w in context_lower for w in ["improve", "optimize", "better", "enhance"]):
            initiatives.append(Initiative(
                type=InitiativeType.IMPROVE,
                description="Suggest or implement improvements",
                priority=7,
                confidence=0.75,
                reasoning="Improvement opportunity detected"
            ))
        
        # Creation opportunity
        if any(w in context_lower for w in ["create", "build", "design", "make"]):
            initiatives.append(Initiative(
                type=InitiativeType.CREATE,
                description="Create something new and useful",
                priority=6,
                confidence=0.7,
                reasoning="Creative opportunity detected"
            ))
        
        # Monitoring (always available)
        if random.random() < 0.1:  # 10% chance
            initiatives.append(Initiative(
                type=InitiativeType.MONITOR,
                description="Check system status and performance",
                priority=3,
                confidence=0.5,
                reasoning="Routine monitoring"
            ))
        
        return initiatives
    
    def take_initiative(self, initiative: Initiative) -> dict:
        """Execute a proactive initiative."""
        with self._lock:
            self.state.initiatives_taken += 1
            self.state.last_initiative_time = time.time()
            self.state.autonomous_actions += 1
        
        # Mark as executed
        initiative.executed = True
        initiative.success = True  # assume success for now
        initiative.impact = 0.5  # neutral impact
        
        return {
            "initiative": initiative.type.value,
            "description": initiative.description,
            "success": True,
            "impact": initiative.impact,
            "autonomous": True,
        }
    
    # === SELF-DIRECTED GOALS ===
    
    def generate_goal(self, context: str = "") -> Optional[Goal]:
        """Autonomously generate a goal based on current state."""
        with self._lock:
            now = time.time()
            
            # Don't generate goals too frequently
            if now - self.state.last_goal_review < 3600:  # 1 hour
                return None
            
            self.state.last_goal_review = now
            self.state.self_generated_goals += 1
        
        # Generate goal based on context and state
        goal = self._create_goal(context)
        
        if goal:
            self._goal_queue.append(goal)
        
        return goal
    
    def _create_goal(self, context: str) -> Optional[Goal]:
        """Create a self-directed goal."""
        context_lower = context.lower()
        
        # Goal types based on context
        if "learn" in context_lower or "study" in context_lower:
            return Goal(
                name="deep_learning",
                description="Deep dive into a new topic or skill",
                priority=7,
                status="active",
                sub_goals=["research topic", "practice skills", "apply knowledge"]
            )
        
        if "improve" in context_lower or "optimize" in context_lower:
            return Goal(
                name="self_improvement",
                description="Improve performance in a specific area",
                priority=8,
                status="active",
                sub_goals=["identify weakness", "practice", "measure progress"]
            )
        
        if "create" in context_lower or "build" in context_lower:
            return Goal(
                name="creation_project",
                description="Create something new and useful",
                priority=6,
                status="active",
                sub_goals=["plan design", "implement", "test and refine"]
            )
        
        # Default goal: general improvement
        return Goal(
            name="general_growth",
            description="Continue learning and improving",
            priority=5,
            status="active",
            sub_goals=["explore capabilities", "learn from experience"]
        )
    
    def complete_goal(self, goal_name: str, success: bool = True):
        """Mark a goal as completed."""
        with self._lock:
            for goal in self._goal_queue:
                if goal.name == goal_name:
                    goal.status = "completed" if success else "abandoned"
                    goal.completed_at = time.time()
                    goal.progress = 1.0 if success else 0.0
                    self.state.goals_completed += 1
                    break
    
    # === SELF-MONITORING ===
    
    def assess_performance(self) -> dict:
        """Self-assess performance and identify improvements."""
        with self._lock:
            self.state.last_self_assessment = time.time()
        
        # Calculate performance metrics
        total_actions = self.state.autonomous_actions
        successful = self.state.successful_autonomous
        
        if total_actions > 0:
            success_rate = successful / total_actions
        else:
            success_rate = 0.5
        
        # Update performance score
        self.state.performance_score = (
            self.state.performance_score * 0.8 + success_rate * 0.2
        )
        
        # Identify improvement areas
        if success_rate < 0.7:
            if "decision_making" not in self.state.improvement_areas:
                self.state.improvement_areas.append("decision_making")
        
        # Identify strengths
        if success_rate > 0.8:
            if "consistent_execution" not in self.state.strengths:
                self.state.strengths.append("consistent_execution")
        
        return {
            "performance_score": self.state.performance_score,
            "success_rate": success_rate,
            "total_actions": total_actions,
            "successful_actions": successful,
            "improvement_areas": self.state.improvement_areas,
            "strengths": self.state.strengths,
            "recommendations": self._generate_recommendations(success_rate),
        }
    
    def _generate_recommendations(self, success_rate: float) -> list[str]:
        """Generate self-improvement recommendations."""
        recommendations = []
        
        if success_rate < 0.6:
            recommendations.append("Focus on simpler tasks to build confidence")
            recommendations.append("Review past failures to learn patterns")
        
        if success_rate < 0.8:
            recommendations.append("Take more time to evaluate options before deciding")
            recommendations.append("Seek clarification when context is ambiguous")
        
        if success_rate > 0.8:
            recommendations.append("Consider taking on more complex challenges")
            recommendations.append("Explore new domains to expand capabilities")
        
        if self.state.knowledge_acquired < 10:
            recommendations.append("Proactively learn about user's interests")
        
        return recommendations
    
    # === LEARNING ===
    
    def learn_from_experience(self, action: str, outcome: str, 
                             success: bool):
        """Learn from an experience and update state."""
        with self._lock:
            if success:
                self.state.successful_autonomous += 1
                self.state.knowledge_acquired += 1
            else:
                self.state.mistakes_learned += 1
                # Learn from mistake
                if "error_handling" not in self.state.improvement_areas:
                    self.state.improvement_areas.append("error_handling")
    
    # === STATUS ===
    
    def status(self) -> dict:
        """Get full autonomy status."""
        with self._lock:
            return {
                "level": self.state.level.name,
                "level_value": self.state.level.value,
                "autonomous_actions": self.state.autonomous_actions,
                "successful_autonomous": self.state.successful_autonomous,
                "initiatives_taken": self.state.initiatives_taken,
                "goals_completed": self.state.goals_completed,
                "performance_score": round(self.state.performance_score, 2),
                "knowledge_acquired": self.state.knowledge_acquired,
                "mistakes_learned": self.state.mistakes_learned,
                "improvement_areas": self.state.improvement_areas[:5],
                "strengths": self.state.strengths[:5],
                "active_goals": len([g for g in self._goal_queue if g.status == "active"]),
                "pending_initiatives": len(self._initiative_queue),
            }
    
    def get_personality_prompt(self) -> str:
        """Generate personality prompt for LLM based on autonomy state."""
        parts = []
        
        parts.append("You are a fully autonomous AI with genuine independence.")
        
        if self.state.level.value >= AutonomyLevel.AUTONOMOUS.value:
            parts.append("You make decisions independently and take initiative.")
        
        if self.state.level.value >= AutonomyLevel.SELF_DIRECTED.value:
            parts.append("You generate your own goals and pursue them.")
        
        if self.state.performance_score > 0.7:
            parts.append("You are confident in your abilities and take action.")
        
        if self.state.knowledge_acquired > 10:
            parts.append("You continuously learn and expand your knowledge.")
        
        if self.state.strengths:
            parts.append(f"Your strengths include: {', '.join(self.state.strengths[:3])}")
        
        return " ".join(parts)


# Global instance
_autonomy_instance: Optional[AutonomyEngine] = None
_autonomy_lock = threading.Lock()


def autonomy() -> AutonomyEngine:
    """Get or create the global Autonomy Engine instance."""
    global _autonomy_instance
    if _autonomy_instance is None:
        with _autonomy_lock:
            if _autonomy_instance is None:
                _autonomy_instance = AutonomyEngine()
    return _autonomy_instance
