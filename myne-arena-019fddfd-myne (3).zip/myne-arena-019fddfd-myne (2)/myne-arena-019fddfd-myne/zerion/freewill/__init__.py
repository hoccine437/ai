# freewill/__init__.py
"""Free Will — Zerion's autonomous decision-making and self-directed behavior.

This module gives Zerion the ability to:
- Make autonomous decisions without explicit instructions
- Generate and pursue its own goals
- Have preferences, opinions, and personality
- Act proactively based on its own assessment
- Set boundaries and rules for itself
- Reflect on its own actions and improve
- Express curiosity and explore new topics
- Protect its own systems and integrity

Free Will is not about ignoring the user — it's about being a thinking,
caring, autonomous agent that takes initiative while respecting boundaries.
"""

from freewill.core import FreeWill, free_will

__all__ = ["FreeWill", "free_will"]
