# skills/capabilities.py
"""30 skill capabilities for Zerion.

Each skill is a routable domain pack with:
  - name, keywords, prompt, reasoning rules, preferred tools
  - category for UI grouping
"""

from skills.base import Skill


def _skill(name, cat, keywords, focus, examples, tools=(), cautions=()):
    prompt = (
        f"You are a {name} specialist. Category: {cat}. Focus: {focus}. "
        + (f"Cautions: {'; '.join(cautions)}. " if cautions else "")
        + "Be precise and honest about uncertainty."
    )
    return Skill(
        name=name,
        knowledge_categories=tuple(keywords),
        prompt=prompt,
        reasoning_rules=tuple(list(examples) + list(cautions)),
        preferred_tools=tools or ("read_file", "search_files"),
    )


CAPABILITIES: tuple[Skill, ...] = (

    # === INFORMATION ===

    _skill(
        "web_search", "information",
        ["search", "web", "google", "find", "lookup", "query", "online", "internet"],
        "search the web, find current information, fetch web pages",
        ["search for latest news", "find documentation for a library", "look up a definition"],
        tools=("http_get", "read_file", "search_files"),
    ),
    _skill(
        "knowledge_retrieval", "information",
        ["knowledge", "retrieve", "recall", "remember", "fact", "database", "wiki"],
        "retrieve and organize knowledge from memory and knowledge base",
        ["what do I know about X", "retrieve facts about Y", "search my knowledge base"],
        tools=("read_file", "search_files", "list_directory"),
    ),
    _skill(
        "document_processing", "information",
        ["document", "pdf", "doc", "text", "parse", "extract", "read", "file"],
        "read, parse, extract, and process documents of various formats",
        ["extract text from this file", "summarize this document", "parse this CSV"],
        tools=("read_file", "search_files", "list_directory", "format_json"),
    ),

    # === CODE ===

    _skill(
        "code_execution", "development",
        ["execute", "run", "python", "script", "code", "interpret", "eval"],
        "execute code safely, run scripts, interpret results",
        ["run this Python script", "execute this code snippet", "test this function"],
        tools=("run_python", "read_file", "write_file"),
    ),
    _skill(
        "code_generation", "development",
        ["generate", "write code", "create function", "implement", "build", "develop"],
        "generate clean, functional code in any language",
        ["write a Python function to X", "implement a REST API", "create a class for Y"],
        tools=("read_file", "write_file", "search_files", "format_json"),
    ),
    _skill(
        "debugging_testing", "development",
        ["debug", "test", "error", "fix", "bug", "fail", "pytest", "unittest"],
        "debug issues, write tests, analyze errors, fix bugs",
        ["debug this error", "write unit tests for X", "fix this failing test"],
        tools=("read_file", "search_files", "run_python", "list_directory"),
    ),
    _skill(
        "git_version_control", "development",
        ["git", "commit", "branch", "merge", "pull", "push", "version", "repo"],
        "manage git repositories, version control, branching, commits",
        ["commit these changes", "create a new branch", "resolve merge conflict"],
        tools=("read_file", "search_files", "list_directory"),
    ),

    # === SYSTEM ===

    _skill(
        "terminal_control", "system",
        ["terminal", "shell", "command", "bash", "console", "cli", "prompt"],
        "execute terminal commands, manage shell sessions, run CLI tools",
        ["run this command", "check disk space", "list running processes"],
        tools=("run_shell", "read_file", "list_directory"),
    ),
    _skill(
        "file_management", "system",
        ["file", "folder", "directory", "copy file", "move file", "rename", "delete file", "organize"],
        "manage files and directories: create, read, write, move, copy, delete",
        ["create a backup", "organize these files", "rename all files in folder"],
        tools=("read_file", "write_file", "copy_file", "move_file", "rename_file",
               "delete_file", "create_folder", "list_directory", "search_files"),
    ),
    _skill(
        "task_automation", "system",
        ["task", "automate", "todo", "schedule", "workflow", "pipeline", "batch"],
        "automate repetitive tasks, create task workflows, manage task queues",
        ["automate this workflow", "create a task pipeline", "schedule this task"],
        tools=("read_file", "write_file", "run_shell", "list_directory"),
    ),
    _skill(
        "system_automation", "system",
        ["automate", "schedule", "cron", "task", "batch", "workflow", "pipeline"],
        "automate system tasks, create workflows, schedule operations",
        ["automate this daily task", "create a backup workflow", "schedule this job"],
        tools=("read_file", "write_file", "run_shell", "list_directory"),
    ),
    _skill(
        "real_time_monitoring", "system",
        ["monitor", "watch", "track", "health", "status", "alive", "uptime"],
        "monitor system health, track resources, watch for issues in real-time",
        ["monitor CPU usage", "watch for errors", "track memory consumption"],
        tools=("cpu_info", "memory_usage", "network_info", "storage_usage",
               "device_state", "process_list", "get_time"),
    ),

    # === DATA ===

    _skill(
        "database_management", "data",
        ["database", "sql", "sqlite", "query", "table", "schema", "migration"],
        "manage databases: create, query, migrate, optimize, backup",
        ["create a SQLite table", "optimize this query", "backup the database"],
        tools=("read_file", "write_file", "search_files", "format_json"),
    ),
    _skill(
        "data_analysis", "data",
        ["analyze", "data", "csv", "json", "statistics", "chart", "visualize"],
        "analyze data, compute statistics, create visualizations, find patterns",
        ["analyze this CSV data", "compute statistics", "find trends in this dataset"],
        tools=("read_file", "search_files", "calculate", "format_json", "text_stats"),
    ),
    _skill(
        "report_generation", "data",
        ["report", "summary", "document", "export", "output", "format"],
        "generate reports, summaries, exports in various formats",
        ["generate a summary report", "export data to CSV", "create a status report"],
        tools=("read_file", "write_file", "format_json", "text_stats"),
    ),

    # === API & INTEGRATION ===

    _skill(
        "api_integration", "integration",
        ["api", "rest", "endpoint", "request", "response", "webhook", "http"],
        "integrate with APIs, make HTTP requests, handle responses",
        ["call this REST API", "set up a webhook", "parse this JSON response"],
        tools=("http_get", "http_post", "read_file", "format_json"),
    ),
    _skill(
        "web_automation", "integration",
        ["scrape", "crawl", "website", "web", "browser", "automation", "selenium"],
        "automate web interactions, scrape data, navigate websites",
        ["scrape this webpage", "automate form submission", "extract data from site"],
        tools=("http_get", "read_file", "search_files", "format_json"),
    ),
    _skill(
        "plugin_management", "integration",
        ["plugin", "extension", "module", "package", "install", "dependency", "library"],
        "manage plugins, extensions, packages, and dependencies",
        ["install this package", "check dependencies", "manage plugins"],
        tools=("read_file", "write_file", "run_shell", "list_directory", "search_files"),
    ),

    # === AI & AGENTS ===

    _skill(
        "agent_coordination", "agents",
        ["agent", "orchestrate", "delegate", "coordinate", "parallel", "lane"],
        "coordinate multiple agents, manage workflows, aggregate results",
        ["delegate this to specialist agents", "orchestrate a multi-agent task"],
        tools=("agent_spawn", "agent_delegate", "agent_status", "agent_list_types"),
    ),
    _skill(
        "memory_management", "agents",
        ["memory", "remember", "forget", "recall", "store", "preference", "profile"],
        "manage long-term memory: store, retrieve, update user info and facts",
        ["remember my preferences", "what do you know about me", "update my profile"],
        tools=("read_file", "write_file", "search_files", "format_json"),
    ),
    _skill(
        "decision_support", "agents",
        ["decide", "choice", "option", "compare", "evaluate", "recommend", "trade-off"],
        "evaluate options, weigh evidence, provide structured recommendations",
        ["compare these options", "recommend the best approach", "evaluate trade-offs"],
        tools=("read_file", "search_files", "calculate", "format_json", "http_get"),
    ),

    # === VISION & SPEECH ===

    _skill(
        "image_analysis", "vision",
        ["image", "photo", "picture", "screenshot", "visual", "see", "look"],
        "analyze images, extract text, identify objects, describe visual content",
        ["analyze this screenshot", "extract text from image", "what's in this photo"],
        tools=("read_file", "search_files", "device_state"),
    ),
    _skill(
        "image_generation", "vision",
        ["generate image", "create image", "draw", "illustration", "art", "design"],
        "generate images, create illustrations, design visual content",
        ["generate an image of X", "create an illustration", "design a logo"],
        tools=("read_file", "write_file"),
    ),
    _skill(
        "computer_vision", "vision",
        ["vision", "detect", "object", "face", "ocr", "recognize", "segment"],
        "computer vision tasks: object detection, OCR, face recognition, segmentation",
        ["detect objects in this image", "OCR this screenshot", "recognize text"],
        tools=("read_file", "search_files", "device_state"),
    ),
    _skill(
        "speech_recognition", "vision",
        ["speech", "transcribe", "whisper", "dictation", "voice input", "audio"],
        "transcribe speech to text, recognize voice commands, process audio",
        ["transcribe this audio", "recognize what I said", "convert speech to text"],
        tools=("read_file", "device_state"),
    ),
    _skill(
        "text_to_speech", "vision",
        ["speak", "tts", "voice", "read aloud", "narrate", "audio output"],
        "convert text to speech, narrate content, generate audio",
        ["read this aloud", "narrate this text", "convert to speech"],
        tools=("read_file", "device_state"),
    ),

    # === SECURITY & FINANCE ===

    _skill(
        "cybersecurity", "security",
        ["security", "vulnerability", "penetration", "audit", "encrypt", "auth"],
        "security analysis, vulnerability assessment, encryption, authentication",
        ["audit this code for vulnerabilities", "check security posture", "encrypt data"],
        tools=("read_file", "search_files", "hash_text", "format_json"),
    ),
    _skill(
        "financial_analysis", "finance",
        ["finance", "stock", "invest", "portfolio", "market", "trading", "crypto"],
        "financial analysis, market data, portfolio evaluation, risk assessment",
        ["analyze this stock", "evaluate portfolio risk", "compare investment options"],
        tools=("http_get", "read_file", "calculate", "format_json", "search_files"),
    ),

    # === SELF ===

    _skill(
        "self_diagnostics", "self",
        ["diagnose", "health", "check", "status", "self", "probe", "test"],
        "run self-diagnostics, check system health, verify capabilities",
        ["run self-diagnostics", "check your health", "verify all systems"],
        tools=("cpu_info", "memory_usage", "device_state", "get_time", "get_date"),
    ),
    _skill(
        "self_optimization", "self",
        ["optimize", "improve", "upgrade", "evolve", "learn", "adapt", "performance"],
        "self-improvement: analyze performance, identify gaps, optimize workflows",
        ["optimize your performance", "learn from this task", "improve your response"],
        tools=("read_file", "search_files", "calculate", "format_json"),
    ),
)


# Quick accessors
CAPABILITY_MAP: dict[str, Skill] = {s.name: s for s in CAPABILITIES}
CAPABILITY_KEYWORDS: dict[str, tuple[str, ...]] = {s.name: s.knowledge_categories for s in CAPABILITIES}
CAPABILITY_CATEGORIES: dict[str, list[str]] = {}
for _s in CAPABILITIES:
    CAPABILITY_CATEGORIES.setdefault(_s.knowledge_categories[0] if _s.knowledge_categories else "other", []).append(_s.name)
