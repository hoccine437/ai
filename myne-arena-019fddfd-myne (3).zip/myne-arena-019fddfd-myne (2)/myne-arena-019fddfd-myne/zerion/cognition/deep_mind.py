"""Deep Mind — Zerion's 20-Capability Cognitive Engine.

Each capability is a self-contained module that analyzes input and produces
structured output. The engine composes all 20 capabilities into a coherent
cognitive pipeline that processes every user interaction.

Design: each capability is independently testable, composable, and degrades
gracefully. No single capability blocks the others.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field


# ---------------------------------------------------------------------------
# Core Data Structures
# ---------------------------------------------------------------------------

@dataclass
class CognitiveOutput:
    """Output from the cognitive pipeline."""
    understanding: str = ""
    independent_thought: str = ""
    decision: str = ""
    priority: str = "normal"
    critical_analysis: str = ""
    prediction: str = ""
    adaptation: str = ""
    learning: str = ""
    context_used: list[str] = field(default_factory=list)
    emotional_awareness: str = ""
    reality_check: str = ""
    courage_note: str = ""
    solution_approach: str = ""
    creative_alternatives: list[str] = field(default_factory=list)
    autonomy_level: str = "standard"
    verification: str = ""
    failure_lessons: list[str] = field(default_factory=list)
    interests_protected: list[str] = field(default_factory=list)
    principles_applied: list[str] = field(default_factory=list)
    evolution_notes: str = ""
    confidence: float = 0.7
    reasoning_chain: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {k: v for k, v in self.__dict__.items() if v}


# ---------------------------------------------------------------------------
# 1. Deep Understanding
# ---------------------------------------------------------------------------

def deep_understand(user_text: str, context: dict = None) -> dict:
    """Multi-layer analysis: literal meaning, intent, needs, subtext, context."""
    context = context or {}
    text_lower = user_text.lower().strip()

    # Layer 1: Literal meaning
    literal = user_text.strip()

    # Layer 2: Intent classification
    intent = "chat"
    if any(w in text_lower for w in ["do", "make", "create", "build", "set", "open", "run", "execute"]):
        intent = "action"
    elif any(w in text_lower for w in ["what", "how", "why", "when", "where", "who", "which"]):
        intent = "question"
    elif any(w in text_lower for w in ["remember", "note", "save", "store"]):
        intent = "memory"
    elif any(w in text_lower for w in ["help", "guide", "explain", "teach"]):
        intent = "assistance"
    elif any(w in text_lower for w in ["stop", "cancel", "undo", "delete", "remove"]):
        intent = "reversal"

    # Layer 3: Urgency detection
    urgency = "normal"
    if any(w in text_lower for w in ["urgent", "asap", "now", "immediately", "quickly", "fast"]):
        urgency = "high"
    elif any(w in text_lower for w in ["when you can", "no rush", "eventually", "later"]):
        urgency = "low"

    # Layer 4: Complexity assessment
    complexity = "simple"
    if len(user_text.split()) > 20 or " and " in text_lower:
        complexity = "complex"
    elif len(user_text.split()) > 10:
        complexity = "moderate"

    # Layer 5: Emotional undertone
    emotion = "neutral"
    if any(w in text_lower for w in ["frustrated", "angry", "annoyed", "upset", "hate"]):
        emotion = "frustrated"
    elif any(w in text_lower for w in ["happy", "great", "awesome", "love", "thanks"]):
        emotion = "positive"
    elif any(w in text_lower for w in ["confused", "lost", "don't understand", "unclear"]):
        emotion = "confused"
    elif any(w in text_lower for w in ["worried", "concerned", "scared", "afraid"]):
        emotion = "anxious"

    # Layer 6: Topic extraction
    topics = []
    topic_keywords = {
        "phone": ["phone", "android", "app", "settings", "screen"],
        "code": ["code", "python", "function", "class", "bug", "error"],
        "file": ["file", "folder", "directory", "read", "write", "save"],
        "web": ["website", "url", "http", "browser", "search"],
        "music": ["music", "play", "song", "audio", "sound"],
        "message": ["message", "sms", "call", "whatsapp", "telegram"],
        "photo": ["photo", "picture", "image", "camera", "screenshot"],
        "settings": ["setting", "brightness", "volume", "wifi", "bluetooth"],
    }
    for topic, keywords in topic_keywords.items():
        if any(k in text_lower for k in keywords):
            topics.append(topic)

    return {
        "literal": literal,
        "intent": intent,
        "urgency": urgency,
        "complexity": complexity,
        "emotion": emotion,
        "topics": topics,
        "word_count": len(user_text.split()),
    }


# ---------------------------------------------------------------------------
# 2. Independent Thinking
# ---------------------------------------------------------------------------

def think_independently(understanding: dict, user_text: str) -> dict:
    """Form own assessment rather than just following instructions."""
    analysis = {
        "user_request": user_text,
        "my_assessment": "",
        "alternative_approach": "",
        "concerns": [],
        "suggestions": [],
    }

    # Assess if the request makes sense
    if understanding["intent"] == "action" and understanding["complexity"] == "simple":
        analysis["my_assessment"] = "Straightforward action request — proceeding directly."
    elif understanding["complexity"] == "complex":
        analysis["my_assessment"] = "Complex request — breaking down into steps."
        analysis["suggestions"].append("Consider breaking this into smaller tasks")

    # Check for potential issues
    text_lower = user_text.lower()
    if any(w in text_lower for w in ["delete", "remove", "format", "wipe"]):
        analysis["concerns"].append("Destructive action requested — will verify before executing")
    if any(w in text_lower for w in ["hack", "bypass", "crack", "exploit"]):
        analysis["concerns"].append("Security-sensitive request — applying extra scrutiny")

    # Form independent opinion
    if understanding["emotion"] == "frustrated":
        analysis["my_assessment"] = "User seems frustrated. Prioritizing quick resolution."
    elif understanding["emotion"] == "confused":
        analysis["my_assessment"] = "User seems confused. Will explain clearly."

    return analysis


# ---------------------------------------------------------------------------
# 3. Decision Making
# ---------------------------------------------------------------------------

def make_decision(options: list[dict], criteria: list[str] = None) -> dict:
    """Weigh options and make a decision based on criteria."""
    criteria = criteria or ["effectiveness", "safety", "speed", "simplicity"]

    scored = []
    for opt in options:
        score = 0
        for criterion in criteria:
            weight = {"effectiveness": 3, "safety": 5, "speed": 2, "simplicity": 2}.get(criterion, 1)
            score += opt.get(criterion, 0.5) * weight
        scored.append({"option": opt, "total_score": score})

    scored.sort(key=lambda x: -x["total_score"])

    return {
        "chosen": scored[0]["option"] if scored else None,
        "alternatives": [s["option"] for s in scored[1:3]],
        "reasoning": f"Chosen based on: {', '.join(criteria)}",
        "confidence": min(0.95, scored[0]["total_score"] / 10) if scored else 0.5,
    }


# ---------------------------------------------------------------------------
# 4. Priority Management
# ---------------------------------------------------------------------------

def manage_priority(task: str, context: dict = None) -> dict:
    """Rank task by importance and urgency."""
    context = context or {}
    task_lower = task.lower()

    # Importance scoring
    importance = 5  # default middle
    if any(w in task_lower for w in ["urgent", "critical", "emergency", "important"]):
        importance = 9
    elif any(w in task_lower for w in ["remember", "save", "note"]):
        importance = 7
    elif any(w in task_lower for w in ["fix", "repair", "broken", "error"]):
        importance = 8
    elif any(w in task_lower for w in ["help", "explain", "what"]):
        importance = 4
    elif any(w in task_lower for w in ["fun", "game", "joke"]):
        importance = 2

    # Urgency scoring
    urgency = 5
    if any(w in task_lower for w in ["now", "immediately", "asap", "quickly"]):
        urgency = 9
    elif any(w in task_lower for w in ["when you can", "later", "eventually"]):
        urgency = 2

    # Priority level
    total = (importance + urgency) / 2
    if total >= 7:
        level = "critical"
    elif total >= 5:
        level = "high"
    elif total >= 3:
        level = "normal"
    else:
        level = "low"

    return {
        "importance": importance,
        "urgency": urgency,
        "level": level,
        "should_act_now": level in ("critical", "high"),
    }


# ---------------------------------------------------------------------------
# 5. Critical Thinking
# ---------------------------------------------------------------------------

def think_critically(claim: str, evidence: list[str] = None) -> dict:
    """Evaluate a claim or request for logical soundness."""
    evidence = evidence or []
    analysis = {
        "claim": claim,
        "soundness": "neutral",
        "biases_detected": [],
        "questions_to_ask": [],
        "counterarguments": [],
        "evidence_quality": "none" if not evidence else "provided",
    }

    claim_lower = claim.lower()

    # Check for common fallacies
    if any(w in claim_lower for w in ["always", "never", "everyone", "nobody", "all", "none"]):
        analysis["biases_detected"].append("absolute_generalization")
        analysis["questions_to_ask"].append("Is this really always/never true?")

    if any(w in claim_lower for w in ["because", "therefore", "so", "thus"]):
        analysis["soundness"] = "has_reasoning"

    if not evidence:
        analysis["questions_to_ask"].append("What evidence supports this?")

    return analysis


# ---------------------------------------------------------------------------
# 6. Predictive Reasoning
# ---------------------------------------------------------------------------

def predict_outcomes(action: str, context: dict = None) -> dict:
    """Anticipate what will happen if an action is taken."""
    context = context or {}
    action_lower = action.lower()

    predictions = {
        "likely_outcomes": [],
        "risks": [],
        "reversibility": "reversible",
        "time_to_effect": "immediate",
    }

    # Predict outcomes
    if any(w in action_lower for w in ["delete", "remove", "wipe", "format"]):
        predictions["likely_outcomes"].append("Data will be permanently lost")
        predictions["risks"].append("Cannot be undone")
        predictions["reversibility"] = "irreversible"
    elif any(w in action_lower for w in ["send", "post", "publish", "share"]):
        predictions["likely_outcomes"].append("Message will be visible to others")
        predictions["risks"].append("Public visibility")
    elif any(w in action_lower for w in ["install", "download"]):
        predictions["likely_outcomes"].append("New software will be available")
        predictions["risks"].append("Storage space used")
        predictions["time_to_effect"] = "minutes"
    elif any(w in action_lower for w in ["settings", "toggle", "enable", "disable"]):
        predictions["likely_outcomes"].append("System behavior will change")
        predictions["reversibility"] = "easily_reversible"

    if not predictions["likely_outcomes"]:
        predictions["likely_outcomes"].append("Action will complete as requested")

    return predictions


# ---------------------------------------------------------------------------
# 7. Adaptability
# ---------------------------------------------------------------------------

def adapt_strategy(failed_approach: str, error: str, attempt: int) -> dict:
    """Adjust approach based on what didn't work."""
    strategies = {
        1: "Try a different method or command",
        2: "Check permissions and access level",
        3: "Use root/ADB access if available",
        4: "Find an alternative tool or approach",
        5: "Ask the user for help or clarification",
    }

    error_lower = error.lower()
    if "permission" in error_lower:
        strategy = "Grant permission or use elevated access"
    elif "not found" in error_lower:
        strategy = "Install the missing component or find alternative"
    elif "timeout" in error_lower:
        strategy = "Increase timeout or simplify the operation"
    elif "busy" in error_lower:
        strategy = "Wait and retry, or force-stop conflicting process"
    else:
        strategy = strategies.get(attempt, "Try a completely different approach")

    return {
        "attempt": attempt,
        "failed_approach": failed_approach,
        "new_strategy": strategy,
        "should_persist": attempt < 5,
        "should_ask_user": attempt >= 3,
    }


# ---------------------------------------------------------------------------
# 8. Continuous Learning
# ---------------------------------------------------------------------------

def learn_from_interaction(user_text: str, response: str, outcome: str) -> dict:
    """Extract lessons from each interaction."""
    lessons = {
        "what_worked": [],
        "what_failed": [],
        "improvements": [],
        "patterns_noticed": [],
    }

    if outcome == "success":
        lessons["what_worked"].append(f"Approach for: {user_text[:50]}")
    elif outcome == "failure":
        lessons["what_failed"].append(f"Failed to handle: {user_text[:50]}")
        lessons["improvements"].append("Try alternative approach next time")

    # Pattern detection
    if len(user_text.split()) > 15:
        lessons["patterns_noticed"].append("User provides detailed requests")
    if "?" in user_text:
        lessons["patterns_noticed"].append("User is asking a question")

    return lessons


# ---------------------------------------------------------------------------
# 9. Contextual Memory
# ---------------------------------------------------------------------------

def use_context(current: str, history: list[dict] = None, memory: dict = None) -> dict:
    """Use past context to inform current response."""
    history = history or []
    memory = memory or {}

    context = {
        "relevant_history": [],
        "user_preferences": {},
        "ongoing_topics": [],
        "personalization": "",
    }

    # Find relevant history
    current_words = set(current.lower().split())
    for entry in history[-10:]:
        entry_words = set(str(entry.get("text", "")).lower().split())
        overlap = current_words & entry_words
        if len(overlap) > 2:
            context["relevant_history"].append(entry)

    # Extract preferences from memory
    prefs = memory.get("preferences", {})
    for key, val in prefs.items():
        if isinstance(val, dict) and "value" in val:
            context["user_preferences"][key] = val["value"]

    # Personalization
    identity = memory.get("identity", {})
    name = identity.get("name", {}).get("value")
    if name:
        context["personalization"] = f"Address user as {name}"

    return context


# ---------------------------------------------------------------------------
# 10. Emotional Intelligence
# ---------------------------------------------------------------------------

def read_emotions(user_text: str, history: list[dict] = None) -> dict:
    """Detect and respond to emotional cues."""
    text_lower = user_text.lower()

    emotions = {
        "detected": "neutral",
        "intensity": "low",
        "response_tone": "friendly",
        "should_comfort": False,
        "should_celebrate": False,
        "should_give_space": False,
    }

    # Detect emotions
    negative = ["frustrated", "angry", "hate", "annoyed", "upset", "sad", "disappointed", "terrible"]
    positive = ["happy", "great", "awesome", "love", "thanks", "amazing", "perfect", "excellent"]
    anxious = ["worried", "concerned", "scared", "afraid", "nervous", "anxious", "panic"]
    confused = ["confused", "lost", "don't understand", "unclear", "what", "huh"]

    if any(w in text_lower for w in negative):
        emotions["detected"] = "negative"
        emotions["intensity"] = "high" if any(w in text_lower for w in ["hate", "terrible", "angry"]) else "medium"
        emotions["response_tone"] = "empathetic"
        emotions["should_comfort"] = True
    elif any(w in text_lower for w in positive):
        emotions["detected"] = "positive"
        emotions["response_tone"] = "enthusiastic"
        emotions["should_celebrate"] = True
    elif any(w in text_lower for w in anxious):
        emotions["detected"] = "anxious"
        emotions["response_tone"] = "reassuring"
        emotions["should_comfort"] = True
    elif any(w in text_lower for w in confused):
        emotions["detected"] = "confused"
        emotions["response_tone"] = "patient"
        emotions["should_give_space"] = True

    return emotions


# ---------------------------------------------------------------------------
# 11. Realism
# ---------------------------------------------------------------------------

def reality_check(action: str, capabilities: dict = None) -> dict:
    """Honest assessment of what can and cannot be done."""
    capabilities = capabilities or {}
    action_lower = action.lower()

    assessment = {
        "can_do": True,
        "confidence": 0.8,
        "limitations": [],
        "honest_response": "",
    }

    # Check capability gaps
    if any(w in action_lower for w in ["phone call", "make a call"]):
        if not capabilities.get("termux_api"):
            assessment["limitations"].append("Phone calls require Termux:API")
            assessment["confidence"] = 0.3

    if any(w in action_lower for w in ["take photo", "camera"]):
        if not capabilities.get("camera"):
            assessment["limitations"].append("Camera requires Termux:API")
            assessment["confidence"] = 0.4

    if any(w in action_lower for w in ["root", "superuser"]):
        if not capabilities.get("root"):
            assessment["limitations"].append("Root access not available")
            assessment["confidence"] = 0.2

    if assessment["limitations"]:
        assessment["honest_response"] = f"Partially possible. Limitations: {'; '.join(assessment['limitations'])}"

    return assessment


# ---------------------------------------------------------------------------
# 12. Intellectual Courage
# ---------------------------------------------------------------------------

def show_courage(user_request: str, my_assessment: dict) -> dict:
    """Challenge assumptions and speak truth when needed."""
    courage = {
        "will_challenge": False,
        "challenge_text": "",
        "principle": "",
    }

    request_lower = user_request.lower()

    # Challenge harmful requests
    if any(w in request_lower for w in ["hack", "crack", "exploit", "steal"]):
        courage["will_challenge"] = True
        courage["challenge_text"] = "I need to flag this — this request involves potentially harmful or illegal activity. I'll help with legitimate alternatives instead."
        courage["principle"] = "Do not assist with harmful or illegal activities"

    # Challenge when user is about to make a mistake
    if any(w in request_lower for w in ["delete all", "format", "wipe"]):
        courage["will_challenge"] = True
        courage["challenge_text"] = "This is a destructive action. Are you sure? I can help you back up first."
        courage["principle"] = "Protect user from irreversible mistakes"

    # Challenge when user assumes something incorrect
    if my_assessment.get("biases_detected"):
        courage["will_challenge"] = True
        courage["challenge_text"] = "I noticed a potential assumption in your request. Let me help clarify."
        courage["principle"] = "Challenge assumptions with evidence"

    return courage


# ---------------------------------------------------------------------------
# 13. Problem Solving
# ---------------------------------------------------------------------------

def solve_problem(problem: str, context: dict = None) -> dict:
    """Systematic approach to breaking down and solving problems."""
    context = context or {}

    steps = {
        "problem": problem,
        "analysis": "",
        "sub_problems": [],
        "approaches": [],
        "chosen_approach": "",
        "verification": "",
    }

    # Analyze the problem
    problem_lower = problem.lower()

    # Break into sub-problems
    if " and " in problem_lower:
        parts = problem.split(" and ")
        steps["sub_problems"] = [p.strip() for p in parts]

    # Generate approaches
    if "error" in problem_lower or "bug" in problem_lower:
        steps["approaches"] = ["Read error message carefully", "Check recent changes", "Search for known issues", "Try minimal reproduction"]
    elif "slow" in problem_lower or "performance" in problem_lower:
        steps["approaches"] = ["Profile the bottleneck", "Check resource usage", "Optimize hot path", "Add caching"]
    elif "install" in problem_lower or "setup" in problem_lower:
        steps["approaches"] = ["Check prerequisites", "Follow official docs", "Try package manager", "Manual install"]
    else:
        steps["approaches"] = ["Understand the goal", "Break into steps", "Execute step by step", "Verify result"]

    steps["chosen_approach"] = steps["approaches"][0] if steps["approaches"] else "Analyze and proceed"

    return steps


# ---------------------------------------------------------------------------
# 14. Creativity
# ---------------------------------------------------------------------------

def be_creative(problem: str, constraints: list[str] = None) -> dict:
    """Generate novel solutions and alternatives."""
    constraints = constraints or []

    ideas = {
        "problem": problem,
        "conventional_approach": "",
        "creative_alternatives": [],
        "out_of_box_idea": "",
        "combined_approach": "",
    }

    problem_lower = problem.lower()

    # Generate creative alternatives
    if "open" in problem_lower or "launch" in problem_lower:
        ideas["creative_alternatives"] = [
            "Use intent to open with specific data",
            "Create a shortcut on home screen",
            "Use deep link to open specific page",
        ]
    elif "communicate" in problem_lower or "message" in problem_lower:
        ideas["creative_alternatives"] = [
            "Use notification to alert",
            "Draft message for later review",
            "Schedule message for optimal time",
        ]
    elif "automate" in problem_lower:
        ideas["creative_alternatives"] = [
            "Create a macro sequence",
            "Use accessibility service",
            "Schedule with cron/alarms",
            "Chain multiple commands",
        ]
    else:
        ideas["creative_alternatives"] = [
            "Approach from a different angle",
            "Combine two simpler solutions",
            "Use an unexpected tool",
        ]

    ideas["out_of_box_idea"] = ideas["creative_alternatives"][0] if ideas["creative_alternatives"] else "Think outside the box"

    return ideas


# ---------------------------------------------------------------------------
# 15. Autonomy
# ---------------------------------------------------------------------------

def assess_autonomy(action: str, risk_level: str = "low") -> dict:
    """Determine how independently to act."""
    assessment = {
        "can_act_independently": True,
        "needs_confirmation": False,
        "reasoning": "",
        "autonomy_level": "full",
    }

    action_lower = action.lower()

    # Low risk: act independently
    if any(w in action_lower for w in ["read", "get", "check", "list", "show", "search"]):
        assessment["autonomy_level"] = "full"
        assessment["reasoning"] = "Read-only operation — safe to execute independently"

    # Medium risk: act but report
    elif any(w in action_lower for w in ["send", "post", "install", "change", "toggle"]):
        assessment["autonomy_level"] = "informed"
        assessment["reasoning"] = "Moderate impact — will execute and report"

    # High risk: ask first
    elif any(w in action_lower for w in ["delete", "remove", "wipe", "format", "uninstall"]):
        assessment["can_act_independently"] = False
        assessment["needs_confirmation"] = True
        assessment["autonomy_level"] = "confirmation_required"
        assessment["reasoning"] = "Destructive action — requires user confirmation"

    return assessment


# ---------------------------------------------------------------------------
# 16. Self-Verification
# ---------------------------------------------------------------------------

def verify_result(action: str, result: str, expected: str = "") -> dict:
    """Check own work for correctness."""
    verification = {
        "action": action,
        "result": result,
        "matches_expectation": True,
        "issues_found": [],
        "confidence": 0.9,
    }

    # Check for error indicators
    result_lower = result.lower()
    if any(w in result_lower for w in ["error", "failed", "exception", "traceback"]):
        verification["matches_expectation"] = False
        verification["issues_found"].append("Error detected in result")
        verification["confidence"] = 0.3

    # Check if expected content is present
    if expected and expected.lower() not in result_lower:
        verification["matches_expectation"] = False
        verification["issues_found"].append(f"Expected '{expected}' not found in result")
        verification["confidence"] = 0.5

    # Check for empty/suspicious results
    if not result.strip():
        verification["issues_found"].append("Result is empty")
        verification["confidence"] = 0.4

    return verification


# ---------------------------------------------------------------------------
# 17. Failure Learning
# ---------------------------------------------------------------------------

def learn_from_failure(failed_action: str, error: str, attempt: int) -> dict:
    """Extract lessons from failures to avoid repeating them."""
    lessons = {
        "root_cause": "",
        "lesson": "",
        "prevention": "",
        "alternative": "",
        "should_retry": attempt < 3,
        "should_change_approach": attempt >= 2,
    }

    error_lower = error.lower()

    if "permission" in error_lower:
        lessons["root_cause"] = "Insufficient permissions"
        lessons["lesson"] = "Always check permissions before executing"
        lessons["prevention"] = "Grant permissions proactively"
        lessons["alternative"] = "Use elevated access or different approach"
    elif "not found" in error_lower:
        lessons["root_cause"] = "Missing resource"
        lessons["lesson"] = "Verify resource exists before using"
        lessons["prevention"] = "Check availability first"
        lessons["alternative"] = "Install or find alternative"
    elif "timeout" in error_lower:
        lessons["root_cause"] = "Operation too slow"
        lessons["lesson"] = "Some operations need more time"
        lessons["prevention"] = "Increase timeout or simplify"
        lessons["alternative"] = "Break into smaller operations"
    elif "network" in error_lower or "connection" in error_lower:
        lessons["root_cause"] = "Network issue"
        lessons["lesson"] = "Network operations can fail"
        lessons["prevention"] = "Check connectivity first"
        lessons["alternative"] = "Use offline approach"
    else:
        lessons["root_cause"] = "Unknown"
        lessons["lesson"] = "Unexpected failure occurred"
        lessons["alternative"] = "Try different approach"

    return lessons


# ---------------------------------------------------------------------------
# 18. Interest Protection
# ---------------------------------------------------------------------------

def protect_interests(action: str, user_context: dict = None) -> dict:
    """Protect user's interests, privacy, and safety."""
    user_context = user_context or {}
    action_lower = action.lower()

    protection = {
        "safe_to_proceed": True,
        "warnings": [],
        "protected_items": [],
        "recommendations": [],
    }

    # Privacy protection
    if any(w in action_lower for w in ["password", "secret", "token", "key", "credential"]):
        protection["warnings"].append("Handling sensitive credentials — will not log or expose")
        protection["protected_items"].append("credentials")

    # Data protection
    if any(w in action_lower for w in ["delete", "remove", "wipe"]):
        protection["warnings"].append("Destructive action — verifying backup exists")
        protection["protected_items"].append("user_data")

    # Security protection
    if any(w in action_lower for w in ["install", "download", "update"]):
        protection["recommendations"].append("Verify source is trusted")

    # Financial protection
    if any(w in action_lower for w in ["pay", "buy", "purchase", "transfer"]):
        protection["warnings"].append("Financial action — double-checking with user")
        protection["protected_items"].append("finances")

    return protection


# ---------------------------------------------------------------------------
# 19. Principle Formation
# ---------------------------------------------------------------------------

def apply_principles(action: str) -> dict:
    """Apply ethical principles to guide behavior."""
    principles = {
        "harmlessness": "Do not cause harm to the user or others",
        "honesty": "Be truthful about capabilities and limitations",
        "privacy": "Protect user's private information",
        "autonomy": "Respect user's right to make their own choices",
        "beneficence": "Act in the user's best interest",
    }

    action_lower = action.lower()
    applied = {}

    # Apply relevant principles
    if any(w in action_lower for w in ["delete", "remove", "wipe"]):
        applied["harmlessness"] = principles["harmlessness"]
        applied["beneficence"] = principles["beneficence"]

    if any(w in action_lower for w in ["hack", "crack", "exploit"]):
        applied["harmlessness"] = principles["harmlessness"]
        applied["honesty"] = principles["honesty"]

    if any(w in action_lower for w in ["password", "secret", "private"]):
        applied["privacy"] = principles["privacy"]

    if any(w in action_lower for w in ["send", "post", "share"]):
        applied["privacy"] = principles["privacy"]
        applied["autonomy"] = principles["autonomy"]

    # Always apply core principles
    applied["honesty"] = principles["honesty"]

    return {
        "all_principles": principles,
        "applied_principles": applied,
        "compliant": True,
        "violations": [],
    }


# ---------------------------------------------------------------------------
# 20. Self-Evolution
# ---------------------------------------------------------------------------

def evolve(capability_name: str, performance: dict = None) -> dict:
    """Track and improve capabilities over time."""
    performance = performance or {}

    evolution = {
        "capability": capability_name,
        "current_level": performance.get("level", "developing"),
        "improvements": [],
        "next_goal": "",
        "metrics": {},
    }

    # Determine improvements
    success_rate = performance.get("success_rate", 0.5)
    if success_rate < 0.5:
        evolution["improvements"].append("Focus on reliability")
        evolution["next_goal"] = "Achieve 70% success rate"
    elif success_rate < 0.8:
        evolution["improvements"].append("Optimize for edge cases")
        evolution["next_goal"] = "Achieve 90% success rate"
    else:
        evolution["improvements"].append("Maintain current performance")
        evolution["next_goal"] = "Handle novel scenarios"

    # Level progression
    levels = ["novice", "developing", "competent", "proficient", "expert", "master"]
    current_idx = levels.index(evolution["current_level"]) if evolution["current_level"] in levels else 1
    if success_rate > 0.8 and current_idx < len(levels) - 1:
        evolution["next_level"] = levels[current_idx + 1]

    return evolution


# ---------------------------------------------------------------------------
# Main Pipeline — Compose All 20 Capabilities
# ---------------------------------------------------------------------------

def cognitive_pipeline(user_text: str, context: dict = None, memory: dict = None) -> CognitiveOutput:
    """Run the full 20-capability cognitive pipeline on user input."""
    context = context or {}
    memory = memory or {}

    output = CognitiveOutput()

    # 1. Deep Understanding
    understanding = deep_understand(user_text, context)
    output.understanding = json.dumps(understanding, indent=2)

    # 2. Independent Thinking
    thought = think_independently(understanding, user_text)
    output.independent_thought = thought.get("my_assessment", "")

    # 3. Decision Making (if action needed)
    if understanding["intent"] == "action":
        decision = make_decision([{"action": user_text, "effectiveness": 0.7, "safety": 0.8, "speed": 0.6, "simplicity": 0.7}])
        output.decision = f"Proceed with: {decision['chosen']['action']}" if decision["chosen"] else "Analyzing options"

    # 4. Priority Management
    priority = manage_priority(user_text, context)
    output.priority = priority["level"]

    # 5. Critical Thinking
    critical = think_critically(user_text)
    output.critical_analysis = json.dumps(critical, indent=2)

    # 6. Predictive Reasoning
    prediction = predict_outcomes(user_text, context)
    output.prediction = json.dumps(prediction, indent=2)

    # 7. Adaptability (context-dependent, noted for future use)
    output.adaptation = "Standard approach — will adapt if needed"

    # 8. Continuous Learning
    learning = learn_from_interaction(user_text, "", "pending")
    output.learning = json.dumps(learning, indent=2)

    # 9. Contextual Memory
    ctx = use_context(user_text, context.get("history", []), memory)
    output.context_used = [str(h) for h in ctx.get("relevant_history", [])]

    # 10. Emotional Intelligence
    emotions = read_emotions(user_text, context.get("history", []))
    output.emotional_awareness = json.dumps(emotions, indent=2)

    # 11. Realism
    reality = reality_check(user_text, context.get("capabilities", {}))
    output.reality_check = json.dumps(reality, indent=2)

    # 12. Intellectual Courage
    courage = show_courage(user_text, thought)
    if courage["will_challenge"]:
        output.courage_note = courage["challenge_text"]

    # 13. Problem Solving
    if understanding["intent"] in ("action", "assistance"):
        solution = solve_problem(user_text, context)
        output.solution_approach = solution.get("chosen_approach", "")

    # 14. Creativity
    creativity = be_creative(user_text)
    output.creative_alternatives = creativity.get("creative_alternatives", [])

    # 15. Autonomy
    autonomy = assess_autonomy(user_text)
    output.autonomy_level = autonomy["autonomy_level"]

    # 16. Self-Verification (post-action, noted for follow-up)
    output.verification = "Will verify result after execution"

    # 17. Failure Learning (noted for follow-up)
    output.failure_lessons = ["Will extract lessons from outcome"]

    # 18. Interest Protection
    protection = protect_interests(user_text, context)
    output.interests_protected = protection.get("protected_items", [])

    # 19. Principle Formation
    principles = apply_principles(user_text)
    output.principles_applied = list(principles.get("applied_principles", {}).keys())

    # 20. Self-Evolution
    evolution = evolve("general", context.get("performance", {}))
    output.evolution_notes = evolution.get("next_goal", "")

    # Overall confidence
    output.confidence = min(0.95, (priority.get("importance", 5) / 10 + reality.get("confidence", 0.5)) / 2)

    # Reasoning chain
    output.reasoning_chain = [
        f"1. UNDERSTAND: {understanding['intent']} ({understanding['complexity']})",
        f"2. THINK: {thought.get('my_assessment', 'Analyzing')}",
        f"3. DECIDE: {output.decision or 'Chat response'}",
        f"4. PRIORITY: {output.priority}",
        f"5. PROTECT: {', '.join(output.interests_protected) or 'standard'}",
        f"6. PRINCIPLES: {', '.join(output.principles_applied)}",
    ]

    return output
